"""Build a ZIP with one top-level gyogan_camera/ module folder.

Keep __init__.py, the manifest and every supporting module inside that folder.
The archive filename may change with the release; the internal folder is fixed.
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parent
package = root / 'gyogan_camera'
output = root / 'dist' / 'gyogan_camera-0.1.21.zip'
output.parent.mkdir(exist_ok=True)
with ZipFile(output, 'w', ZIP_DEFLATED) as archive:
    for path in sorted(package.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
            archive.write(path, path.relative_to(root).as_posix())
print(output)
