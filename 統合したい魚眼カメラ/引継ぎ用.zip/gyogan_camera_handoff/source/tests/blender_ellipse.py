"""Elliptical-warp regressions in an isolated Blender 5.2 process.

Run with --background --factory-startup --python-exit-code 1 --python this_file.
The signed 0.1.6 implementation is a frozen compatibility oracle. Non-default
ellipses are checked by conjugating that old circular warp with an XY scale,
independently of the new node graph and its Python reference implementation.
"""

import importlib.util
import json
import math
import sys
import traceback
from pathlib import Path

import bpy
from mathutils import Matrix, Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
from test_paths import output_path
REPORT = output_path('ellipse_result.json')
FIXTURE = output_path('ellipse_fixture.blend')
LEGACY_FIXTURE = output_path('ellipse_legacy_fixture.blend')
sys.dont_write_bytecode = True
from blender_center import (addon, refresh, positions, error, make_mesh,
                            make_empty, make_rig, bone_points)

spec = importlib.util.spec_from_file_location(
    'gyogan_legacy_v016_fixture', ROOT / 'tests' / 'fixtures' / 'legacy_v016_nodes.py')
legacy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)

# The frozen 0.1.6 math stays unchanged. Its center-presence Object comparison
# requires Blender 5.2, so only construction of that helper uses the equivalent
# compatibility implementation when building a legacy fixture on older Blender.
if not addon.nodes.supports_object_compare():
    def legacy_center_slope(graph, inverse, near, center):
        slopes = addon.nodes._center_slope(graph, inverse, near, center, scene=bpy.context.scene)
        # This helper uses the current compatibility subgraph, which already
        # includes cursor selection. Only the surrounding ellipse math is old.
        graph.tree['gyogan_cursor_version'] = addon.nodes.CURSOR_VERSION
        return slopes
    legacy._center_slope = legacy_center_slope


def expected(scene, points, center=None):
    """Normalize XY, apply the frozen circular warp, then restore XY units."""
    graph = refresh(scene)
    settings = scene.gyogan
    camera = scene.camera.evaluated_get(graph)
    matrix = camera.matrix_world.normalized()
    inverse = matrix.inverted()
    anchor = inverse @ center.evaluated_get(graph).matrix_world.translation if center else None
    frame = camera.data.view_frame(scene=scene)
    half_width = (max(v.x / -v.z for v in frame) - min(v.x / -v.z for v in frame)) / 2
    result = []
    for world_point in points:
        point = inverse @ world_point
        offset = Vector((0., 0., 0.))
        if anchor is not None and -anchor.z > settings.near_distance:
            fade = min(1., max(0., (-anchor.z - settings.near_distance) / settings.near_distance))
            fade = fade * fade * (3. - 2. * fade)
            offset.x = -point.z * anchor.x / -anchor.z * fade
            offset.y = -point.z * anchor.y / -anchor.z * fade
        local = point - offset
        normalized = (local.x / settings.ellipse_x, local.y / settings.ellipse_y, local.z)
        old = legacy.camera_space_reference(normalized, settings.strength, settings.fov,
                                            settings.zoom, settings.near_distance, half_width)
        result.append(matrix @ (Vector((old[0] * settings.ellipse_x,
                                        old[1] * settings.ellipse_y, old[2])) + offset))
    return result


def replace_legacy_mesh(scene, target):
    tree = legacy.build_mesh_group('楕円検証・旧版メッシュ', scene)
    tree[addon.OWNER] = target.token
    previous = target.node_group
    modifier = next(addon.find_modifier(target.source, record) for record in target.modifiers
                    if record.kind == 'NODES')
    modifier.node_group = target.node_group = tree
    if previous.users == 0:
        bpy.data.node_groups.remove(previous)
    return tree


def replace_legacy_armature(scene, target):
    tree = bpy.data.node_groups.new('楕円検証・旧版人物座標変形', 'GeometryNodeTree')
    tree.interface.new_socket(name='Point', in_out='INPUT', socket_type='NodeSocketVector')
    tree.interface.new_socket(name='Point', in_out='OUTPUT', socket_type='NodeSocketVector')
    graph = legacy.Graph(tree)
    result = legacy.CameraWarp(graph, scene, space='ORIGINAL').apply(
        graph.node('NodeGroupInput').outputs['Point'])
    graph.connect(result, graph.node('NodeGroupOutput'), 'Point')
    tree[addon.OWNER] = target.token
    tree['gyogan_role'] = 'armature_warp'
    previous = set()
    for node in target.node_group.nodes:
        if node.bl_idname != 'GeometryNodeGroup' or not node.node_tree:
            continue
        if node.node_tree.get('gyogan_role') != 'armature_warp':
            continue
        inputs = [(link.from_socket, link.to_socket.name) for link in node.inputs[0].links]
        outputs = [(link.from_socket.name, link.to_socket) for link in node.outputs[0].links]
        previous.add(node.node_tree)
        node.node_tree = tree
        for source, name in inputs:
            target.node_group.links.new(source, node.inputs[name])
        for name, destination in outputs:
            target.node_group.links.new(node.outputs[name], destination)
    for old in previous:
        if old.users == 0:
            bpy.data.node_groups.remove(old)
    return tree


def topology(tree):
    return (set(node.as_pointer() for node in tree.nodes),
            {(link.from_socket.as_pointer(), link.to_socket.as_pointer()) for link in tree.links},
            {curve.data_path for curve in tree.animation_data.drivers} if tree.animation_data else set())


def run():
    if not bpy.app.background:
        raise RuntimeError('楕円の検証は専用のバックグラウンドプロセスで実行してください')
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if not hasattr(bpy.types.Scene, 'gyogan'):
        addon.register()
    checks, exception = [], None

    def check(name, condition, **details):
        checks.append(dict(test=name, passed=bool(condition), **details))

    def compare(name, actual, reference, tolerance=4.0e-4):
        difference = error(actual, reference)
        check(name, difference < tolerance, max_error=difference)

    try:
        scene = bpy.context.scene
        scene.name = '楕円・専用数値検証'
        settings = scene.gyogan
        check('default_ellipse_is_circular', settings.ellipse_x == settings.ellipse_y == 1.)
        check('ellipse_rna_limits_are_positive', all(
            settings.bl_rna.properties[name].hard_min == .1
            or abs(settings.bl_rna.properties[name].hard_min - .1) < 1.e-7
            for name in ('ellipse_x', 'ellipse_y'))
            and all(settings.bl_rna.properties[name].hard_max == 5. for name in ('ellipse_x', 'ellipse_y')))
        settings.ellipse_x, settings.ellipse_y = 2., .4
        reset_result = bpy.ops.gyogan.reset_ellipse()
        check('ellipse_reset_operator_restores_circle', reset_result == {'FINISHED'}
              and settings.ellipse_x == settings.ellipse_y == 1.)
        camera = bpy.data.objects.new('楕円検証・正面カメラ', bpy.data.cameras.new('楕円検証・カメラデータ'))
        scene.collection.objects.link(camera)
        camera.location = (0, -10, 2)
        camera.rotation_euler.x = math.pi / 2
        camera.data.lens = 28
        scene.camera = settings.camera = camera
        scene.render.resolution_x, scene.render.resolution_y = 1280, 720
        settings.subdivision = 'NONE'
        settings.near_distance = .05
        refresh(scene)
        points = [(0, 0, -6), (4, 0, -6), (0, 4, -6), (-4, 0, -6), (0, -4, -6),
                  (2, 3, -6), (3, 2, -6), (2, -3, -6), (-2, 3, -6),
                  (.2, .2, -.025), (.2, .2, -.075), (1, 1, .5), (2, 2, -12),
                  (1, .5, -6), (1.e-7, 0, -6), (0, 1.e-7, -6)]
        grid = make_mesh(scene, '楕円検証・数値点群', points, [(0, 1, 2), (0, 3, 4)])
        grid.matrix_world = camera.matrix_world.copy()
        raw_grid = [tuple(vertex.co) for vertex in grid.data.vertices]
        original_grid = positions(scene, grid)
        target = addon.setup_mesh(scene, grid)
        anchor = make_empty(scene, '楕円検証・中心', (1, .5, -6))
        inverse = camera.matrix_world.normalized().inverted()
        for strength in (-5., -.5, 0., .5, 1., 5.):
            settings.strength = strength
            compare('circular_matches_frozen_' + str(strength), positions(scene, grid), expected(scene, original_grid))
        circular = positions(scene, grid)
        for axes in ((.4, 2.), (2., .4), (.1, 5.), (5., .1)):
            settings.ellipse_x, settings.ellipse_y = axes
            differences = []
            for strength in (-5., -.5, 1., 5.):
                settings.strength = strength
                differences.append(error(positions(scene, grid), expected(scene, original_grid)))
            check('elliptical_formula_' + str(axes), max(differences) < 4.0e-4, max_error=max(differences))
        settings.ellipse_x, settings.ellipse_y, settings.strength = 2., .4, 2.
        wide = [inverse @ point for point in positions(scene, grid)]
        settings.ellipse_x, settings.ellipse_y = .4, 2.
        tall = [inverse @ point for point in positions(scene, grid)]
        check('axis_swap_rotates_deformation', (Vector((wide[1].y, wide[1].x, wide[1].z)) - tall[2]).length < 2.e-5
              and (Vector((wide[5].y, wide[5].x, wide[5].z)) - tall[6]).length < 2.e-5)
        check('larger_axis_reduces_positive_compression', abs(wide[1].x) > abs(tall[1].x) + .01
              and abs(tall[2].y) > abs(wide[2].y) + .01)
        check('ellipse_is_symmetric_about_each_axis', abs(wide[1].x + wide[3].x) < 1.e-5
              and abs(wide[2].y + wide[4].y) < 1.e-5)
        compare('optical_axis_and_near_protection_unchanged',
                [positions(scene, grid)[i] for i in (0, 9, 11)], [original_grid[i] for i in (0, 9, 11)], 2.e-6)
        compare('central_scale_independent_of_ellipse', positions(scene, grid)[14:], circular[14:], 2.e-6)
        settings.center_object = anchor
        for strength in (-5., -.5, 1., 5.):
            settings.strength = strength
            compare('ellipse_with_offset_center_' + str(strength), positions(scene, grid), expected(scene, original_grid, anchor))
        compare('ellipse_center_stays_fixed', positions(scene, grid)[13:14], original_grid[13:14], 2.e-6)
        anchor.location = camera.matrix_world @ Vector((.2, -.1, .075 * -1))
        compare('ellipse_center_near_fade', positions(scene, grid), expected(scene, original_grid, anchor))
        anchor.location = camera.matrix_world @ Vector((1., .5, -6.))
        settings.strength = 0.
        compare('ellipse_zero_restores_original_mesh', positions(scene, grid), original_grid, 2.e-6)
        settings.strength = -2.
        settings.enabled = False
        compare('ellipse_off_restores_original_mesh', positions(scene, grid), original_grid, 2.e-6)
        settings.enabled = True

        rig, body = make_rig(scene)
        raw_body = [tuple(vertex.co) for vertex in body.data.vertices]
        source_skin = positions(scene, body)
        source_pose = bone_points(scene, rig)
        source_matrices = {bone.name: tuple(tuple(row) for row in bone.matrix_basis) for bone in rig.pose.bones}
        rig_target = addon.setup_armature(scene, rig)
        output = rig_target.outputs[0].output
        for axes, strength in (((2., .4), 3.), ((.4, 2.), -3.), ((.1, 5.), -.5)):
            settings.ellipse_x, settings.ellipse_y = axes
            settings.strength = strength
            compare('ellipse_armature_heads_tails_' + str((axes, strength)),
                    bone_points(scene, rig_target.output_rig), expected(scene, source_pose, anchor))
            check('ellipse_armature_skin_deforms_' + str((axes, strength)), error(positions(scene, output), source_skin) > .01)
        compare('ellipse_preserves_source_skin', positions(scene, body), source_skin, 1.e-6)
        settings.strength = 0.
        compare('ellipse_zero_restores_output_skin', positions(scene, output), source_skin)
        check('ellipse_preserves_source_raw_data_and_pose', raw_grid == [tuple(v.co) for v in grid.data.vertices]
              and raw_body == [tuple(v.co) for v in body.data.vertices]
              and source_matrices == {bone.name: tuple(tuple(row) for row in bone.matrix_basis) for bone in rig.pose.bones})

        # Genuine 0.1.6 graphs must be upgraded in place by the add-on's normal
        # entry point, including the shared subgroup inside the rig calculator.
        settings.ellipse_x = settings.ellipse_y = 1.
        old_mesh = replace_legacy_mesh(scene, target)
        old_leaf = replace_legacy_armature(scene, rig_target)
        trees = (old_mesh, old_leaf)
        before = {}
        for strength in (-5., -.5, 1., 5.):
            settings.strength = strength
            before[strength] = (positions(scene, grid), positions(scene, output))
        tree_ids = [tree.as_pointer() for tree in trees]
        node_ids = [topology(tree)[0] for tree in trees]
        driver_ids = [{curve.as_pointer() for curve in tree.animation_data.drivers} for tree in trees]
        interfaces = [[(item.name, item.identifier) for item in tree.interface.items_tree] for tree in trees]
        modifier_uid = grid.modifiers[-1].persistent_uid
        output_ids = (output.as_pointer(), output.data.as_pointer(), rig_target.output_rig.data.as_pointer())
        addon.upgrade_saved_warps(scene)
        check('ellipse_migration_preserves_tree_nodes_drivers_and_interface',
              tree_ids == [tree.as_pointer() for tree in trees]
              and all(saved.issubset(topology(tree)[0]) for saved, tree in zip(node_ids, trees))
              and all(saved.issubset({curve.as_pointer() for curve in tree.animation_data.drivers})
                      for saved, tree in zip(driver_ids, trees))
              and interfaces == [[(item.name, item.identifier) for item in tree.interface.items_tree] for tree in trees]
              and all(tree.get('gyogan_ellipse_version') == 1 for tree in trees))
        check('ellipse_migration_preserves_owned_output_references', grid.modifiers[-1].persistent_uid == modifier_uid
              and output_ids == (output.as_pointer(), output.data.as_pointer(), rig_target.output_rig.data.as_pointer())
              and body.modifiers[0].object == rig)
        migrated = [topology(tree) for tree in trees]
        addon.upgrade_saved_warps(scene)
        check('ellipse_migration_idempotent', migrated == [topology(tree) for tree in trees])
        for strength, saved in before.items():
            settings.strength = strength
            compare('ellipse_migration_keeps_circular_mesh_' + str(strength), positions(scene, grid), saved[0], 1.e-7)
            compare('ellipse_migration_keeps_circular_skin_' + str(strength), positions(scene, output), saved[1], 1.e-7)
        settings.ellipse_x, settings.ellipse_y = 2.5, .35
        compare('ellipse_migrated_mesh_supports_new_axes', positions(scene, grid), expected(scene, original_grid, anchor))
        compare('ellipse_migrated_armature_supports_new_axes', bone_points(scene, rig_target.output_rig), expected(scene, source_pose, anchor))

        scratch = legacy.build_mesh_group('楕円検証・失敗復元', scene)
        scratch[addon.OWNER] = 'ellipse-regression-scratch'
        snapshot = topology(scratch)
        original_node = addon.nodes.Graph.node
        calls = 0

        def fail_during_build(graph, *args, **kwargs):
            nonlocal calls
            calls += 1
            if calls == 4:
                raise RuntimeError('楕円移行の途中失敗を検証')
            return original_node(graph, *args, **kwargs)

        failed = False
        try:
            addon.nodes.Graph.node = fail_during_build
            addon.nodes.upgrade_ellipse_group(scratch, scene)
        except RuntimeError:
            failed = True
        finally:
            addon.nodes.Graph.node = original_node
        check('ellipse_migration_failure_rolls_back', failed and snapshot == topology(scratch)
              and not scratch.get('gyogan_ellipse_version'))
        for node in scratch.nodes:
            if node.bl_idname == 'ShaderNodeVectorMath' and node.operation == 'LENGTH':
                node.operation = 'DISTANCE'
        snapshot = topology(scratch)
        failed = False
        try:
            addon.nodes.upgrade_ellipse_group(scratch, scene)
        except ValueError:
            failed = True
        check('edited_legacy_graph_rejected_without_mutation', failed and snapshot == topology(scratch)
              and not scratch.get('gyogan_ellipse_version'))
        bpy.data.node_groups.remove(scratch)

        old_mesh = replace_legacy_mesh(scene, target)
        old_leaf = replace_legacy_armature(scene, rig_target)
        group_names = [tree.name for tree in (old_mesh, old_leaf)]
        names = dict(grid=grid.name, rig=rig.name, body=body.name, output=output.name, anchor=anchor.name)
        bpy.ops.wm.save_as_mainfile(filepath=str(LEGACY_FIXTURE), check_existing=False)
        bpy.ops.wm.open_mainfile(filepath=str(LEGACY_FIXTURE))
        scene, settings = bpy.context.scene, bpy.context.scene.gyogan
        grid, rig, body, output, anchor = [bpy.data.objects[names[key]] for key in ('grid', 'rig', 'body', 'output', 'anchor')]
        rig_target = next(item for item in settings.targets if item.source == rig)
        check('saved_legacy_ellipse_auto_migration', all(bpy.data.node_groups[name].get('gyogan_ellipse_version') == 1 for name in group_names)
              and grid.modifiers[-1].persistent_uid == modifier_uid)
        compare('saved_legacy_ellipse_mesh_matches_formula', positions(scene, grid), expected(scene, original_grid, anchor))
        compare('saved_legacy_ellipse_armature_matches_formula', bone_points(scene, rig_target.output_rig), expected(scene, source_pose, anchor))

        for frame, x, y, strength in ((1, 1., 1., 1.), (5, 2.5, .35, -.5), (9, .2, 3., -5.)):
            settings.ellipse_x, settings.ellipse_y, settings.strength = x, y, strength
            for path in ('ellipse_x', 'ellipse_y', 'strength'):
                settings.keyframe_insert(path, frame=frame)
            anchor.location.x = frame * .1
            anchor.keyframe_insert('location', frame=frame)
            rig.pose.bones['根元'].rotation_euler.z = frame * .07
            rig.pose.bones['根元'].keyframe_insert('rotation_euler', frame=frame)
        animated = {}
        frame_errors = []
        for frame in (1, 5, 7, 9):
            scene.frame_set(frame)
            mesh, skin = positions(scene, grid), positions(scene, output)
            animated[frame] = (mesh, skin, settings.ellipse_x, settings.ellipse_y)
            frame_errors.extend((error(mesh, expected(scene, original_grid, anchor)),
                                 error(bone_points(scene, rig_target.output_rig), expected(scene, bone_points(scene, rig), anchor))))
        check('ellipse_animation_evaluates_live_mesh_and_bones', max(frame_errors) < 4.e-4, max_error=max(frame_errors))
        check('ellipse_animation_changes_result', error(animated[1][0], animated[9][0]) > .1)
        scene.frame_set(5)
        bpy.ops.wm.save_as_mainfile(filepath=str(FIXTURE), check_existing=False)
        bpy.ops.wm.open_mainfile(filepath=str(FIXTURE))
        scene, settings = bpy.context.scene, bpy.context.scene.gyogan
        grid, rig, body, output, anchor = [bpy.data.objects[names[key]] for key in ('grid', 'rig', 'body', 'output', 'anchor')]
        for frame in (9, 1, 7, 5):
            scene.frame_set(frame)
            saved = animated[frame]
            check('ellipse_animation_survives_save_' + str(frame), error(positions(scene, grid), saved[0]) < 1.e-7
                  and error(positions(scene, output), saved[1]) < 1.e-7
                  and abs(settings.ellipse_x - saved[2]) < 1.e-7 and abs(settings.ellipse_y - saved[3]) < 1.e-7)
        settings.center_object = None
        compare('saved_ellipse_cleared_center_uses_optical_axis', positions(scene, grid), expected(scene, original_grid))
        settings.enabled = False
        compare('saved_ellipse_off_restores_mesh', positions(scene, grid), original_grid, 2.e-6)
        check('saved_ellipse_off_restores_visibility', not body.hide_get() and not body.hide_render
              and output.hide_get() and output.hide_render)
        tokens = {item.token for item in settings.targets}
        while settings.targets:
            addon.remove_target(scene, len(settings.targets) - 1)
        leftovers = [block.name for kind in ('objects', 'meshes', 'armatures', 'node_groups', 'collections')
                     for block in getattr(bpy.data, kind) if block.get(addon.OWNER) in tokens]
        check('ellipse_cleanup_preserves_source_data', not leftovers and not grid.modifiers
              and raw_grid == [tuple(v.co) for v in grid.data.vertices]
              and raw_body == [tuple(v.co) for v in body.data.vertices]
              and len(body.modifiers) == 1 and body.modifiers[0].object == rig, leftovers=leftovers)
    except Exception:
        exception = traceback.format_exc()
        print(exception)
    finally:
        passed = bool(checks) and all(item['passed'] for item in checks) and exception is None
        report = dict(blender=bpy.app.version_string, passed=passed, checks=checks, exception=exception)
        REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        print('GYOGAN_ELLIPSE_RESULTS=' + json.dumps(report, ensure_ascii=False))
    if not passed:
        raise AssertionError('楕円の検証に失敗しました: ' + str(REPORT))


if __name__ == '__main__':
    run()
