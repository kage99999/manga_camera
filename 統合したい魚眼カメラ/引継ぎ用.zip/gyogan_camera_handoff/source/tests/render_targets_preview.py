"""Read-only visual verification using the user's A_テスト用人物 asset.

Only run in a separate background Blender. The working .blend is opened for
reading, never saved. Generated images and JSON use the test output directory.
"""

from array import array
import hashlib
import json
import math
import sys
from pathlib import Path

import bpy
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tests'))
from test_paths import output_path
import gyogan_camera as addon


def run():
    if not bpy.app.background:
        raise RuntimeError('人物の見た目確認は専用バックグラウンドプロセスで実行してください')
    addon.register()
    bpy.ops.wm.open_mainfile(filepath=str(ROOT / '魚眼テスト用.blend'), load_ui=False)
    for loaded_scene in bpy.data.scenes:
        loaded_scene.gyogan.enabled = False
    scene = next(scene for scene in bpy.data.scenes if scene.objects.get('A_テスト用人物'))
    bpy.context.window.scene = scene
    if scene.gyogan_dolly.active:
        addon.dolly.restore(scene)
    bpy.ops.gyogan.remove_all()
    settings = scene.gyogan
    settings.effect_scope = 'MANUAL'
    rig = scene.objects['A_テスト用人物']
    bodies = [scene.objects[name] for name in ('Beta_Surface', 'Beta_Joints')]
    original = {body.name: [tuple(vertex.co) for vertex in body.data.vertices] for body in bodies}
    for obj in scene.objects:
        if obj.type == 'MESH':
            obj.hide_render = obj not in bodies
            obj.color = (.20, .48, .68, 1.)
    for body in bodies:
        body.hide_set(False)
    bpy.context.view_layer.update()
    graph = bpy.context.evaluated_depsgraph_get()
    points = [body.evaluated_get(graph).matrix_world @ Vector(point)
              for body in bodies for point in body.evaluated_get(graph).bound_box]
    low = Vector(tuple(min(point[axis] for point in points) for axis in range(3)))
    high = Vector(tuple(max(point[axis] for point in points) for axis in range(3)))
    center = (low + high) * .5
    camera = bpy.data.objects.new('範囲確認・正面カメラ', bpy.data.cameras.new('範囲確認・カメラデータ'))
    scene.collection.objects.link(camera)
    camera.rotation_euler = (math.pi / 2., 0., 0.)
    camera.data.lens = 25.
    scene.render.resolution_x, scene.render.resolution_y = 960, 720
    scene.render.resolution_percentage = 100
    half_width = camera.data.sensor_width / (2. * camera.data.lens)
    distance = max((high.x - low.x) / (2. * half_width * .65),
                   (high.z - low.z) / (2. * half_width * .75 * .65), 1.)
    camera.location = (center.x, center.y - distance, center.z)
    scene.camera = settings.camera = camera
    settings.center_object = None
    settings.strength = 1.
    settings.fov = math.radians(110.)
    settings.zoom = 1.3
    settings.ellipse_x = settings.ellipse_y = 1.
    settings.near_distance = .01
    settings.subdivision = 'NONE'
    settings.mode = 'ARMATURE'
    scene.render.engine = 'BLENDER_WORKBENCH'
    scene.render.image_settings.file_format = 'PNG'
    scene.display.shading.light = 'STUDIO'
    scene.display.shading.color_type = 'OBJECT'
    scene.display.shading.show_shadows = True
    scene.display.shading.show_cavity = True
    scene.display.shading.background_type = 'WORLD'
    if scene.world is None:
        scene.world = bpy.data.worlds.new('範囲確認・背景')
    scene.world.color = (.08, .08, .08)
    checks, images = [], []
    for enabled, scope, name in ((False, 'CAMERA', '元の人物'),
                                 (True, 'CAMERA', 'カメラ範囲・自動で人物を変形'),
                                 (True, 'MANUAL', '手動登録なし・元の人物')):
        settings.enabled = enabled
        settings.effect_scope = scope
        for _ in range(3):
            scene.update_tag()
            bpy.context.view_layer.update()
            addon.targets.reconcile(scene, prepare=True)
        active = [target.source.name for target in settings.targets if target.source and target.active]
        checks.append(dict(test=name, passed=(rig.name in active) if enabled and scope == 'CAMERA'
                           else (not any(target.active for target in settings.targets)), active=active))
        path = output_path('targets_preview_' + str(len(images)) + '.png')
        scene.render.filepath = str(path)
        bpy.ops.render.render(write_still=True)
        rendered_image = bpy.data.images.load(str(path), check_existing=False)
        try:
            pixels = array('f', [0.]) * len(rendered_image.pixels)
            rendered_image.pixels.foreach_get(pixels)
            digest = hashlib.sha256(pixels).hexdigest()
        finally:
            bpy.data.images.remove(rendered_image)
        images.append(dict(label=name, path=str(path), active=active, pixel_sha256=digest))
    checks.append(dict(test='元の人物データを保持', passed=all(
        original[body.name] == [tuple(vertex.co) for vertex in body.data.vertices] for body in bodies)))
    checks.append(dict(test='カメラ範囲で実際のレンダーが変化',
                       passed=images[0]['pixel_sha256'] != images[1]['pixel_sha256']))
    checks.append(dict(test='手動登録なしへ戻すと元のレンダーに復帰',
                       passed=images[0]['pixel_sha256'] == images[2]['pixel_sha256']))
    result = dict(blender=bpy.app.version_string, passed=all(check['passed'] for check in checks),
                  images=images, checks=checks)
    output_path('targets_preview_result.json').write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print('GYOGAN_TARGETS_PREVIEW=' + json.dumps(result, ensure_ascii=False))
    if not result['passed']:
        raise AssertionError('人物の適用範囲の見た目確認に失敗しました')


if __name__ == '__main__':
    run()
