"""Dynamic target scopes in an isolated Blender process.

Run with --background --factory-startup --python-exit-code 1. Only small
numeric meshes and the established two-bone fixture are created here. The
camera membership oracle uses strength zero and plainly separated geometry;
the nonlinear bounds implementation has its own geometric regression suite.
"""

import json
import math
import sys
import traceback
from pathlib import Path

import bpy
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
from test_paths import output_path
from blender_center import addon, bone_points, error, make_mesh, make_rig, positions, refresh

REPORT = output_path('targets_result.json')
FIXTURE = output_path('targets_fixture.blend')


def square(scene, name, location=(0., 0., 0.), half_size=.25):
    obj = make_mesh(scene, name,
                    [(-half_size, -half_size, 0.), (half_size, -half_size, 0.),
                     (half_size, half_size, 0.), (-half_size, half_size, 0.)],
                    [(0, 1, 2, 3)])
    obj.location = location
    return obj


def settle(scene, prepare=True):
    for _ in range(3):
        refresh(scene)
        addon.targets.reconcile(scene, prepare=prepare)
    refresh(scene)


def record(scene, source, kind='MESH'):
    return next((target for target in scene.gyogan.targets
                 if target.source == source and target.kind == kind), None)


def active(scene):
    return {(target.source.name, target.kind) for target in scene.gyogan.targets
            if target.source and target.active}


def manual(scene):
    return {(target.source.name, target.kind) for target in scene.gyogan.manual_targets
            if target.source}


def identity(target):
    if target is None:
        return None
    return (target.token, target.node_group.as_pointer() if target.node_group else None,
            target.output_rig.as_pointer() if target.output_rig else None,
            target.calculator.as_pointer() if target.calculator else None,
            tuple(modifier.uid for modifier in target.modifiers),
            tuple(output.output.as_pointer() for output in target.outputs if output.output))


def fish_modifiers(scene, obj):
    target = record(scene, obj)
    return [modifier for saved in target.modifiers
            if (modifier := addon.find_modifier(obj, saved)) is not None] if target else []


def original_positions(obj):
    return [obj.matrix_world @ vertex.co for vertex in obj.data.vertices]


def owned_ids(tokens):
    return [block.name for kind in ('objects', 'meshes', 'armatures', 'node_groups', 'collections')
            for block in getattr(bpy.data, kind) if block.get(addon.OWNER) in tokens]


def select_only(obj):
    for current in bpy.context.selected_objects:
        current.select_set(False)
    obj.hide_set(False)
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj


def run():
    if not bpy.app.background:
        raise RuntimeError('適用範囲の検証は専用のバックグラウンドプロセスで実行してください')
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if not hasattr(bpy.types.Scene, 'gyogan'):
        addon.register()
    checks, exception = [], None

    def check(name, condition, **details):
        checks.append(dict(test=name, passed=bool(condition), **details))

    def same_vertices(name, obj, expected, tolerance=1.e-6):
        difference = error(positions(bpy.context.scene, obj), expected)
        check(name, difference < tolerance, max_error=difference)

    try:
        scene = bpy.context.scene
        scene.name = '適用範囲・専用検証'
        settings = scene.gyogan
        camera = bpy.data.objects.new('範囲検証・カメラ', bpy.data.cameras.new('範囲検証・カメラデータ'))
        scene.collection.objects.link(camera)
        camera.location = (0., 0., 10.)
        camera.data.lens = 50.
        scene.camera = settings.camera = camera
        scene.render.resolution_x = scene.render.resolution_y = 800
        settings.subdivision = 'NONE'
        settings.effect_scope = 'MANUAL'
        scene.render.use_lock_interface = False
        settings.mode = 'MESH'
        settings.strength = 1.
        # Keep x=20 unambiguously outside even after positive fisheye bending.
        # At the default 140 degrees this source legitimately enters the frame.
        settings.fov = math.radians(90.)
        inside = square(scene, '範囲検証・中央', (1., 0., 0.))
        outside = square(scene, '範囲検証・手動の画面外', (20., 0., 0.))
        behind = square(scene, '範囲検証・カメラ後方', (0., 0., 20.))
        # For 36 mm sensor, 50 mm lens, square aspect, this intersects the
        # right edge at depth 10 while its origin lies outside the frame.
        partial = square(scene, '範囲検証・端に一部だけ', (3.7, 0., 0.))
        wire = make_mesh(scene, '範囲検証・面のない対象外', [(0., 0., 0.)], [])
        raw_meshes = {obj.name: [tuple(vertex.co) for vertex in obj.data.vertices]
                      for obj in (inside, outside, behind, partial, wire)}
        refresh(scene)
        original_outside = original_positions(outside)
        addon.setup_mesh(scene, outside)
        settle(scene)
        check('manual_registration_keeps_explicit_source', manual(scene) == {(outside.name, 'MESH')})
        check('manual_does_not_implicitly_register_scene', active(scene) == {(outside.name, 'MESH')})
        check('manual_outside_camera_is_actually_deformed',
              error(positions(scene, outside), original_outside) > .01)

        settings.strength = 0.
        settings.effect_scope = 'CAMERA'
        settle(scene)
        check('automatic_scope_locks_render_before_job_starts', scene.render.use_lock_interface
              and settings.render_lock_owned and not settings.render_lock_original)
        check('camera_automatically_prepares_visible_mesh', (inside.name, 'MESH') in active(scene))
        check('camera_partial_intersection_included', (partial.name, 'MESH') in active(scene))
        check('camera_excludes_previous_manual_outside', (outside.name, 'MESH') not in active(scene))
        check('camera_excludes_camera_back_side', (behind.name, 'MESH') not in active(scene))
        check('camera_preserves_manual_registry', manual(scene) == {(outside.name, 'MESH')})
        check('camera_inactive_manual_modifiers_disabled', all(
            not modifier.show_viewport and not modifier.show_render for modifier in fish_modifiers(scene, outside)))
        same_vertices('camera_outside_returns_to_original_geometry', outside, original_outside)
        central_identity = identity(record(scene, inside))
        outside_identity = identity(record(scene, outside))

        camera.location.x = 20.
        settle(scene)
        check('camera_move_automatically_enters_previous_manual', (outside.name, 'MESH') in active(scene))
        check('camera_move_automatically_releases_previous_inside', (inside.name, 'MESH') not in active(scene))
        check('camera_move_reuses_preexisting_manual_setup', identity(record(scene, outside)) == outside_identity)
        camera.location.x = 0.
        settle(scene)
        check('camera_reentry_reuses_cached_generated_ids', identity(record(scene, inside)) == central_identity)
        check('camera_reentry_does_not_duplicate_mesh_modifier', len(fish_modifiers(scene, inside)) == 1)

        # Exercise the dependency notification -> registered timer callback
        # route rather than the explicit reconciliation helper used elsewhere.
        camera.location.x = 20.
        refresh(scene)
        check('camera_navigation_queues_automatic_update', scene.as_pointer() in addon.targets._dirty)
        for _ in range(3):
            addon.targets._tick()
            refresh(scene)
        check('timer_updates_camera_membership_without_manual_registration',
              (outside.name, 'MESH') in active(scene) and (inside.name, 'MESH') not in active(scene))
        check('automatic_update_timer_remains_registered', bpy.app.timers.is_registered(addon.targets._tick))
        camera.location.x = 0.
        for _ in range(3):
            refresh(scene)
            addon.targets._tick()

        settings.strength = 1.
        settle(scene)
        check('camera_active_mesh_is_actually_deformed',
              error(positions(scene, inside), original_positions(inside)) > .01)
        same_vertices('camera_nonzero_strength_keeps_outside_original', outside, original_outside)
        settings.strength = 0.
        settings.effect_scope = 'MANUAL'
        settle(scene)
        check('manual_scope_restores_original_render_lock', not scene.render.use_lock_interface
              and not settings.render_lock_owned)
        check('manual_return_restores_only_manual_membership', active(scene) == {(outside.name, 'MESH')})
        check('manual_return_suspends_camera_generated_mesh', all(
            not modifier.show_viewport and not modifier.show_render for modifier in fish_modifiers(scene, inside)))

        collection = bpy.data.collections.new('範囲検証・手動追加コレクション')
        child = bpy.data.collections.new('範囲検証・子コレクション')
        scene.collection.children.link(collection)
        collection.children.link(child)
        grouped = square(scene, '範囲検証・コレクションから追加', (-20., 0., 0.))
        scene.collection.objects.unlink(grouped)
        child.objects.link(grouped)
        settings.scope = 'COLLECTION'
        settings.target_collection = collection
        result = bpy.ops.gyogan.add_targets()
        settle(scene)
        check('collection_add_uses_same_manual_registry', result == {'FINISHED'}
              and manual(scene) == {(outside.name, 'MESH'), (grouped.name, 'MESH')})
        check('collection_add_includes_nested_collection', (grouped.name, 'MESH') in active(scene))

        settings.effect_scope = 'SCENE'
        settle(scene)
        expected_scene = {(obj.name, 'MESH') for obj in (inside, outside, behind, partial, grouped)}
        check('scene_scope_prepares_all_supported_objects_without_add', active(scene) == expected_scene,
              actual=sorted(active(scene)))
        check('scene_scope_does_not_change_manual_registry', manual(scene) == {
            (outside.name, 'MESH'), (grouped.name, 'MESH')})
        check('unsupported_mesh_has_no_generated_mutations', record(scene, wire) is None and not wire.modifiers)
        status = getattr(settings, 'auto_status', '')
        check('unsupported_mesh_has_japanese_reason', bool(status) and ('面' in status or '対象外' in status),
              status=status)
        newly_added = square(scene, '範囲検証・後から追加', (30., 0., 0.))
        settle(scene)
        check('scene_scope_discovers_new_object', (newly_added.name, 'MESH') in active(scene))
        removed_token = record(scene, newly_added).token
        bpy.data.objects.remove(newly_added, do_unlink=True)
        settle(scene)
        check('deleted_auto_source_releases_its_generated_ids', not owned_ids({removed_token}))
        check('deleted_auto_source_does_not_leave_null_target', all(target.source for target in settings.targets))

        # Build both camera positions before animation, then verify the actual
        # frame handler changes membership without calling the manager in the
        # assertion loop. Nonsequential frame access must give identical sets.
        settings.effect_scope = 'CAMERA'
        camera.location.x = 0.
        camera.keyframe_insert('location', frame=1)
        camera.location.x = 20.
        camera.keyframe_insert('location', frame=10)
        settle(scene)
        for frame, included, excluded in ((1, inside, outside), (10, outside, inside),
                                          (1, inside, outside), (10, outside, inside),
                                          (1, inside, outside)):
            scene.frame_set(frame)
            refresh(scene)
            check('frame_handler_membership_' + str(len(checks)),
                  (included.name, 'MESH') in active(scene) and (excluded.name, 'MESH') not in active(scene),
                  frame=frame, actual=sorted(active(scene)))
        check('animation_preserves_original_manual_registry', manual(scene) == {
            (outside.name, 'MESH'), (grouped.name, 'MESH')})
        camera.animation_data_clear()
        camera.location.x = 0.
        settle(scene)

        settings.enabled = False
        check('preview_off_restores_original_render_lock', not scene.render.use_lock_interface
              and not settings.render_lock_owned)
        before_off = len(settings.targets)
        off_added = square(scene, '範囲検証・停止中に追加', (0., 1., 0.))
        settle(scene)
        check('preview_off_does_not_prepare_new_targets', len(settings.targets) == before_off
              and record(scene, off_added) is None)
        check('preview_off_disables_all_generated_mesh_modifiers', all(
            not modifier.show_viewport and not modifier.show_render
            for target in settings.targets if target.kind == 'MESH'
            for saved in target.modifiers
            if (modifier := addon.find_modifier(target.source, saved))))
        same_vertices('preview_off_preserves_original_shape', inside, original_positions(inside))
        settings.enabled = True
        settle(scene)
        check('preview_on_discovers_object_added_while_off', (off_added.name, 'MESH') in active(scene))

        before_save_manual = manual(scene)
        before_save_tokens = {target.source.name: target.token for target in settings.targets if target.source}
        before_save_active = active(scene)
        bpy.ops.wm.save_as_mainfile(filepath=str(FIXTURE))
        bpy.ops.wm.open_mainfile(filepath=str(FIXTURE), load_ui=False)
        scene, settings = bpy.context.scene, bpy.context.scene.gyogan
        camera = scene.camera
        inside, outside, grouped = [scene.objects[name] for name in (
            '範囲検証・中央', '範囲検証・手動の画面外', '範囲検証・コレクションから追加')]
        settle(scene)
        check('reload_preserves_camera_scope', settings.effect_scope == 'CAMERA')
        check('reload_preserves_render_lock_snapshot', scene.render.use_lock_interface
              and settings.render_lock_owned and not settings.render_lock_original)
        check('reload_preserves_independent_manual_registry', manual(scene) == before_save_manual)
        check('reload_preserves_cache_ownership_tokens', before_save_tokens == {
            target.source.name: target.token for target in settings.targets if target.source})
        check('reload_restores_correct_camera_membership', active(scene) == before_save_active)
        camera.location.x = 20.
        settle(scene)
        check('reload_keeps_camera_movement_live', (outside.name, 'MESH') in active(scene)
              and (inside.name, 'MESH') not in active(scene))
        for name, raw in raw_meshes.items():
            check('source_vertices_unchanged_' + name,
                  raw == [tuple(vertex.co) for vertex in scene.objects[name].data.vertices])

        # Real animation rendering must prepare an object that first enters
        # the camera on a later frame, before evaluation of that frame starts.
        camera.location.x = 0.
        scene.frame_set(1)
        camera.keyframe_insert('location', frame=1)
        camera.location.x = -40.
        camera.keyframe_insert('location', frame=2)
        scene.frame_set(2)
        check('render_fixture_camera_keys_move_to_later_source', abs(camera.location.x + 40.) < 1.e-6)
        scene.frame_set(1)
        late = square(scene, '範囲検証・レンダー後半で入る', (-40., 0., 0.))
        settle(scene)
        check('render_later_frame_source_is_not_prepared_before_render', record(scene, late) is None)
        render_frames = []
        render_cameras = []

        def observe_render(render_scene, *_args):
            render_frames.append((render_scene.frame_current, sorted(active(render_scene))))
            render_cameras.append(dict(frame=render_scene.frame_current,
                                       camera_x=render_scene.camera.location.x,
                                       camera_world_x=render_scene.camera.matrix_world.translation.x,
                                       status=render_scene.gyogan.auto_status))

        scene.render.engine = 'BLENDER_WORKBENCH'
        scene.render.resolution_x = scene.render.resolution_y = 64
        scene.render.resolution_percentage = 100
        scene.render.image_settings.file_format = 'PNG'
        scene.render.filepath = str(output_path('targets_animation_'))
        scene.frame_start, scene.frame_end = 1, 2
        bpy.app.handlers.render_post.append(observe_render)
        try:
            bpy.ops.render.render(animation=True)
        finally:
            bpy.app.handlers.render_post.remove(observe_render)
        render_sets = {frame: set(entries) for frame, entries in render_frames}
        check('real_animation_render_updates_membership_for_both_frames',
              1 in render_sets and 2 in render_sets
              and (inside.name, 'MESH') in render_sets[1]
              and (late.name, 'MESH') not in render_sets[1]
              and (inside.name, 'MESH') not in render_sets[2]
              and (late.name, 'MESH') in render_sets[2], frames=render_frames, cameras=render_cameras)
        check('real_render_preflight_prepares_later_source', record(scene, late) is not None)
        check('real_render_finishes_and_releases_render_guard', scene.as_pointer() not in addon.targets._rendering)
        camera.animation_data_clear()
        camera.location.x = 0.
        scene.frame_set(1)
        settle(scene)

        tokens = {target.token for target in settings.targets}
        result = bpy.ops.gyogan.remove_all()
        settle(scene)
        check('remove_all_disables_automatic_recreation', result == {'FINISHED'}
              and not settings.enabled and not settings.targets)
        check('remove_all_clears_manual_descriptors', not settings.manual_targets)
        check('remove_all_removes_only_generated_ids', not owned_ids(tokens))
        check('remove_all_keeps_scene_source_objects', all(name in scene.objects for name in raw_meshes))

        # Automatic mode changes can prepare a rig whose body was manually
        # registered earlier. The descriptor must survive cache replacement,
        # and the original body must never receive two fisheye operations.
        settings.effect_scope = 'MANUAL'
        settings.mode = 'MESH'
        camera.location.x = 0.
        settings.strength = 1.
        settings.enabled = True
        rig, body = make_rig(scene)
        raw_body = [tuple(vertex.co) for vertex in body.data.vertices]
        source_pose = bone_points(scene, rig)
        addon.setup_mesh(scene, body)
        settle(scene)
        check('mesh_mode_registers_character_body', (body.name, 'MESH') in manual(scene)
              and (body.name, 'MESH') in active(scene))
        settings.effect_scope = 'SCENE'
        settings.mode = 'ARMATURE'
        settle(scene)
        check('automatic_armature_mode_replaces_mesh_without_double_deformation',
              active(scene) == {(rig.name, 'ARMATURE')})
        check('automatic_mode_switch_keeps_manual_body_descriptor', manual(scene) == {(body.name, 'MESH')})
        check('armature_mode_disables_original_body_fisheye', all(
            not modifier.show_viewport and not modifier.show_render for modifier in fish_modifiers(scene, body)))
        rig_target = record(scene, rig, 'ARMATURE')
        output = rig_target.outputs[0].output
        check('armature_mode_uses_own_output_and_hides_original', body.hide_render and not output.hide_render)
        check('armature_mode_does_not_modify_original_rig_pose', error(bone_points(scene, rig), source_pose) < 1.e-6)
        settings.strength = 0.
        settings.effect_scope = 'CAMERA'
        camera.location.x = 20.
        settle(scene)
        check('character_leaving_camera_restores_source_visibility', (rig.name, 'ARMATURE') not in active(scene)
              and not body.hide_render and not body.hide_get())
        body.hide_render = True
        body.hide_set(True)
        camera.location.x = 0.
        settle(scene)
        check('user_hiding_inactive_character_excludes_reentry', (rig.name, 'ARMATURE') not in active(scene)
              and body.hide_render and body.hide_get() and output.hide_render and output.hide_get())
        settings.enabled = False
        settle(scene)
        check('preview_off_preserves_user_hidden_inactive_character', body.hide_render and body.hide_get())
        settings.enabled = True
        settle(scene)
        check('preview_on_preserves_user_hidden_inactive_character', (rig.name, 'ARMATURE') not in active(scene)
              and body.hide_render and body.hide_get())
        body.hide_render = False
        body.hide_set(False)
        settings.strength = 1.
        settle(scene)
        check('user_unhiding_inactive_character_allows_reentry', (rig.name, 'ARMATURE') in active(scene)
              and not output.hide_render and not output.hide_get())
        settings.effect_scope = 'SCENE'
        settings.strength = 1.
        settle(scene)
        old_rig_token = record(scene, rig, 'ARMATURE').token
        extra_skin = body.copy()
        extra_skin.name = '範囲検証・後から追加したウェイトメッシュ'
        scene.collection.objects.link(extra_skin)
        extra_skin.hide_render = False
        extra_skin.hide_set(False)
        settle(scene)
        rig_target = record(scene, rig, 'ARMATURE')
        check('new_character_skin_rebuilds_cached_outputs', rig_target is not None
              and {saved.source for saved in rig_target.outputs} == {body, extra_skin})
        check('new_character_skin_releases_obsolete_owned_ids', not owned_ids({old_rig_token}))
        check('new_character_skin_is_deformed_with_rig', extra_skin.hide_render and extra_skin.hide_get()
              and all(not saved.output.hide_render for saved in rig_target.outputs))
        old_rig_token = rig_target.token
        bpy.data.objects.remove(extra_skin, do_unlink=True)
        settle(scene)
        rig_target = record(scene, rig, 'ARMATURE')
        check('deleted_character_skin_rebuilds_without_null_output', rig_target is not None
              and len(rig_target.outputs) == 1 and rig_target.outputs[0].source == body)
        check('deleted_character_skin_releases_obsolete_owned_ids', not owned_ids({old_rig_token}))
        settings.effect_scope = 'CAMERA'
        root_bone = next(bone for bone in rig.pose.bones if not bone.parent)
        saved_bone_location = root_bone.location.copy()
        root_bone.location.x = 0.
        root_bone.keyframe_insert('location', frame=1)
        root_bone.location.x = 40.
        root_bone.keyframe_insert('location', frame=2)
        scene.frame_set(1)
        settle(scene)
        character_identity = identity(record(scene, rig, 'ARMATURE'))
        character_render_frames = []

        def observe_animated_character(render_scene, *_args):
            character_render_frames.append((render_scene.frame_current,
                                            (rig.name, 'ARMATURE') in active(render_scene)))

        scene.render.filepath = str(output_path('targets_animated_character_'))
        bpy.app.handlers.render_post.append(observe_animated_character)
        try:
            bpy.ops.render.render(animation=True)
        finally:
            bpy.app.handlers.render_post.remove(observe_animated_character)
        check('render_camera_membership_follows_original_animated_bones',
              character_render_frames == [(1, True), (2, False)], frames=character_render_frames)
        check('animated_bones_keep_cached_character_identity',
              identity(record(scene, rig, 'ARMATURE')) == character_identity)
        rig.animation_data_clear()
        root_bone.location = saved_bone_location
        scene.frame_set(1)
        settings.effect_scope = 'SCENE'
        settle(scene)
        settings.mode = 'MESH'
        settle(scene)
        check('return_automatic_mesh_mode_activates_body_without_rig', (body.name, 'MESH') in active(scene)
              and (rig.name, 'ARMATURE') not in active(scene))
        check('return_mesh_mode_restores_original_body_visibility', not body.hide_render and not body.hide_get())
        rig_target = record(scene, rig, 'ARMATURE')
        check('return_mesh_mode_hides_or_releases_rig_output', rig_target is None or all(
            saved.output is None or (saved.output.hide_render and saved.output.hide_get())
            for saved in rig_target.outputs))
        settings.mode = 'ARMATURE'
        settle(scene)
        check('return_automatic_armature_mode_activates_rig', active(scene) == {(rig.name, 'ARMATURE')})
        check('all_mode_switches_preserve_original_body_vertices', raw_body == [tuple(v.co) for v in body.data.vertices])
        check('all_automatic_mode_switches_preserve_manual_descriptor', manual(scene) == {(body.name, 'MESH')})
        settings.subdivision = 'SIMPLE'
        settings.render_levels = 4
        settings.face_limit = 1000
        settings.effect_scope = 'MANUAL'
        settle(scene)
        check('failed_manual_cache_rebuild_preserves_descriptor', manual(scene) == {(body.name, 'MESH')})
        check('failed_manual_cache_rebuild_rolls_back_partial_target', record(scene, body) is None)
        check('failed_manual_cache_rebuild_restores_source_visibility', not body.hide_render and not body.hide_get())
        check('failed_manual_cache_rebuild_has_japanese_reason', '上限' in settings.auto_status,
              status=settings.auto_status)
        settings.face_limit = 2000000
        settings.subdivision = 'NONE'
        settle(scene)
        check('changed_settings_retry_failed_manual_cache_rebuild', record(scene, body) is not None
              and (body.name, 'MESH') in active(scene))
        check('manual_return_restores_registered_body_despite_add_mode', active(scene) == {(body.name, 'MESH')})
        check('manual_return_restores_character_body_visibility', not body.hide_render and not body.hide_get())
        tokens = {target.token for target in settings.targets}
        bpy.ops.gyogan.remove_all()
        settle(scene)
        check('armature_cleanup_restores_source_visibility', not body.hide_render and not body.hide_get())
        check('armature_cleanup_preserves_original_armature_modifier', len(body.modifiers) == 1
              and body.modifiers[0].type == 'ARMATURE' and body.modifiers[0].object == rig)
        check('armature_cleanup_releases_all_generated_ids', not owned_ids(tokens))
        check('armature_cleanup_does_not_recreate_targets', not settings.targets and not settings.manual_targets)

        settings.mode = 'MESH'
        settings.strength = 0.
        settings.effect_scope = 'CAMERA'
        settings.enabled = True
        settle(scene)
        select_only(inside)
        bpy.ops.object.mode_set(mode='EDIT')
        edited_new = square(scene, '範囲検証・編集中の追加', (0., 1., 0.))
        for _ in range(3):
            refresh(scene)
            addon.targets._tick()
        check('edit_mode_defers_new_target_preparation', record(scene, edited_new) is None)
        check('automatic_update_does_not_leave_user_edit_mode', inside.mode == 'EDIT')
        bpy.ops.object.mode_set(mode='OBJECT')
        for _ in range(3):
            refresh(scene)
            addon.targets._tick()
        check('return_to_object_mode_prepares_deferred_target', (edited_new.name, 'MESH') in active(scene))

        animated = square(scene, '範囲検証・元モディファイアで移動', (0., -1., 0.))
        displacement = animated.modifiers.new('元の移動モディファイア', 'DISPLACE')
        displacement.direction = 'X'
        displacement.mid_level = 0.
        displacement.strength = 0.
        displacement.keyframe_insert('strength', frame=1)
        displacement.strength = 20.
        displacement.keyframe_insert('strength', frame=2)
        scene.frame_set(1)
        settle(scene)
        proxy_pointer = record(scene, animated).bounds_object.as_pointer()
        moving_render_frames = []

        def observe_animated_modifier(render_scene, *_args):
            moving_render_frames.append((render_scene.frame_current,
                                         (animated.name, 'MESH') in active(render_scene)))

        scene.render.filepath = str(output_path('targets_animated_modifier_'))
        bpy.app.handlers.render_post.append(observe_animated_modifier)
        try:
            bpy.ops.render.render(animation=True)
        finally:
            bpy.app.handlers.render_post.remove(observe_animated_modifier)
        check('render_camera_membership_follows_original_animated_modifier',
              moving_render_frames == [(1, True), (2, False)], frames=moving_render_frames)
        check('animated_modifier_keeps_cached_proxy_identity',
              record(scene, animated).bounds_object.as_pointer() == proxy_pointer)
        animated.animation_data_clear()
        displacement.strength = 0.
        scene.frame_set(1)
        settle(scene)

        # Undo invalidates all RNA handles. Reacquire scene and sources after
        # the native operator, then let the queued timer repair membership.
        settings.effect_scope = 'MANUAL'
        select_only(inside)
        bpy.ops.gyogan.add_targets()
        settle(scene)
        before_undo_manual = manual(scene)
        before_undo_active = active(scene)
        bpy.ops.ed.undo_push(message='適用範囲・手動登録')
        settings.effect_scope = 'CAMERA'
        camera.location.x = 20.
        settle(scene)
        bpy.ops.ed.undo_push(message='適用範囲・カメラへ変更')
        undo_result = bpy.ops.ed.undo()
        scene, settings = bpy.context.scene, bpy.context.scene.gyogan
        for _ in range(3):
            refresh(scene)
            addon.targets._tick()
        check('native_undo_restores_scope_and_manual_registry', undo_result == {'FINISHED'}
              and settings.effect_scope == 'MANUAL' and manual(scene) == before_undo_manual)
        check('native_undo_restores_active_membership', active(scene) == before_undo_active)
        check('native_undo_resumes_automatic_updates', not addon.targets._suspended)
        scene.render.use_lock_interface = True
        settings.effect_scope = 'CAMERA'
        settle(scene)
        check('automatic_scope_preserves_preexisting_render_lock_snapshot', settings.render_lock_owned
              and settings.render_lock_original and scene.render.use_lock_interface)
        settings.effect_scope = 'MANUAL'
        settle(scene)
        check('manual_scope_preserves_preexisting_true_render_lock', scene.render.use_lock_interface
              and not settings.render_lock_owned)
        scene.render.use_lock_interface = False
        settings.effect_scope = 'CAMERA'
        settle(scene)
        addon.unregister()
        check('addon_unregister_restores_original_render_lock', not scene.render.use_lock_interface)
    except Exception:
        exception = traceback.format_exc()
        print(exception)
    finally:
        passed = bool(checks) and all(item['passed'] for item in checks) and exception is None
        report = dict(blender=bpy.app.version_string, passed=passed, checks=checks, exception=exception)
        REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        print('GYOGAN_TARGETS_RESULTS=' + json.dumps(report, ensure_ascii=False))
    if not passed:
        raise AssertionError('適用範囲の検証に失敗しました: ' + str(REPORT))


if __name__ == '__main__':
    run()
