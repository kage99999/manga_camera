"""3D-cursor centers, migration and persistence in an isolated Blender process.

Run with --background --factory-startup --python-exit-code 1. This fixture uses
only a small grid and two numeric test bones; it never opens user work files.
"""

import json
import math
import sys
import traceback
from pathlib import Path

import bpy
from mathutils import Matrix, Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
from test_paths import output_path
from blender_center import (addon, bone_points, error, make_empty, make_mesh,
                            make_rig, positions, refresh)
from blender_targets import active, record, select_only, settle

REPORT = output_path('cursor_result.json')
FIXTURE = output_path('cursor_fixture.blend')


def legacy_center_slope(graph, camera_inverse, near_distance, center_object,
                        scene=None, settings_path='gyogan'):
    """Frozen 0.1.18 center topology: no cursor or explicit default modes."""
    g = graph
    epsilon = 1.e-8
    source = g.node('GeometryNodeSwitch', '魚眼の中心オブジェクト')
    source.input_type = 'OBJECT'
    source.inputs['Switch'].default_value = False
    source.inputs['False'].default_value = center_object
    source['gyogan_role'] = 'center_object'
    info = g.node('GeometryNodeObjectInfo', '中心のワールド位置（形状を参照しない）')
    info.transform_space = 'ORIGINAL'
    g.connect(source.outputs[0], info, 'Object')
    center = g.transform(camera_inverse, info.outputs['Location'])
    x, y, z = g.separate(center)
    depth = g.math('MULTIPLY', z, -1.)
    threshold = g.math('MAXIMUM', near_distance, epsilon)
    in_front = g.math('GREATER_THAN', depth, threshold)
    if addon.nodes.supports_object_compare():
        exists = g.node('FunctionNodeCompare', '中心オブジェクトの存在確認')
        exists.data_type = 'OBJECT'
        exists.operation = 'NOT_EQUAL'
        g.connect(source.outputs[0], exists, 0)
        exists.inputs[1].default_value = None
        exists_output = exists.outputs[0]
    else:
        exists_output = g.driven_value(scene, settings_path + '.center_exists',
                                      '中心オブジェクトの存在確認（互換）')
        exists_output.node['gyogan_role'] = 'center_exists'
    valid = g.node('FunctionNodeBooleanMath', '存在する前方の中心のみ有効')
    valid.operation = 'AND'
    g.connect(exists_output, valid, 0)
    g.connect(in_front, valid, 1)
    safe_depth = g.math('MAXIMUM', depth, epsilon)
    fade = g.math('DIVIDE', g.math('SUBTRACT', depth, threshold), threshold)
    fade = g.math('MINIMUM', g.math('MAXIMUM', fade, 0.), 1.)
    fade = g.math('MULTIPLY', g.math('MULTIPLY', fade, fade),
                  g.math('SUBTRACT', 3., g.math('MULTIPLY', fade, 2.)))
    slope = g.xyz(g.math('MULTIPLY', g.math('DIVIDE', x, safe_depth), fade),
                  g.math('MULTIPLY', g.math('DIVIDE', y, safe_depth), fade), 0.)
    slope = g.switch(valid.outputs[0], (0., 0., 0.), slope, input_type='VECTOR')
    sx, sy, _ = g.separate(slope)
    return sx, sy


def oracle(scene, points, world_center=None):
    """Numeric projection with an explicit world anchor, independent of mode."""
    settings = scene.gyogan
    camera = scene.camera.evaluated_get(refresh(scene))
    matrix = camera.matrix_world.normalized()
    inverse = matrix.inverted()
    frame = camera.data.view_frame(scene=scene)
    half_width = (max(v.x / -v.z for v in frame) - min(v.x / -v.z for v in frame)) / 2.
    center = inverse @ world_center if world_center is not None else None
    return [matrix @ Vector(addon.nodes.camera_space_reference(
        inverse @ point, settings.strength, settings.fov, settings.zoom,
        settings.near_distance, half_width, center_point=center,
        ellipse_x=settings.ellipse_x, ellipse_y=settings.ellipse_y)) for point in points]


def center_inputs(scene):
    tokens = {target.token for target in scene.gyogan.targets}
    return [node.inputs['False'].default_value for tree in bpy.data.node_groups
            if tree.get(addon.OWNER) in tokens for node in tree.nodes
            if node.get('gyogan_role') == 'center_object']


def untagged_positions(obj):
    """Evaluate UI cursor movement without artificially dirtying the scene."""
    bpy.context.view_layer.update()
    evaluated = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
    mesh = evaluated.to_mesh()
    try:
        return [evaluated.matrix_world @ vertex.co for vertex in mesh.vertices]
    finally:
        evaluated.to_mesh_clear()


def untagged_bone_points(rig):
    bpy.context.view_layer.update()
    evaluated = rig.evaluated_get(bpy.context.evaluated_depsgraph_get())
    result = []
    for name in ('根元', '先端'):
        bone = evaluated.pose.bones[name]
        matrix = evaluated.matrix_world @ bone.matrix
        result.extend((matrix.translation, matrix @ Vector((0., bone.bone.length, 0.))))
    return result


def snap_cursor_to_selected():
    """Use the actual Shift+S operation, which bypasses RNA update callbacks."""
    area = next(area for area in bpy.context.screen.areas if area.type == 'VIEW_3D')
    region = next(region for region in area.regions if region.type == 'WINDOW')
    with bpy.context.temp_override(area=area, region=region):
        return bpy.ops.view3d.snap_cursor_to_selected()


def legacy_groups(scene, grid_target, rig_target):
    """Build genuine pre-cursor leaves while preserving the surrounding rig."""
    builder = addon.nodes._center_slope
    addon.nodes._center_slope = legacy_center_slope
    try:
        mesh_tree = addon.nodes.build_mesh_group('カーソル検証・旧メッシュ', scene)
        arm_tree = bpy.data.node_groups.new('カーソル検証・旧人物座標', 'GeometryNodeTree')
        arm_tree.interface.new_socket(name='Point', in_out='INPUT', socket_type='NodeSocketVector')
        arm_tree.interface.new_socket(name='Point', in_out='OUTPUT', socket_type='NodeSocketVector')
        graph = addon.nodes.Graph(arm_tree)
        point = graph.node('NodeGroupInput').outputs['Point']
        result = addon.nodes.CameraWarp(graph, scene, space='ORIGINAL').apply(point)
        graph.connect(result, graph.node('NodeGroupOutput'), 'Point')
    finally:
        addon.nodes._center_slope = builder
    arm_tree['gyogan_role'] = 'armature_warp'
    for tree, target in ((mesh_tree, grid_target), (arm_tree, rig_target)):
        tree[addon.OWNER] = target.token
        if 'gyogan_cursor_version' in tree:
            del tree['gyogan_cursor_version']
    old_mesh = grid_target.node_group
    for modifier in grid_target.source.modifiers:
        if modifier.type == 'NODES' and modifier.node_group == old_mesh:
            modifier.node_group = mesh_tree
    grid_target.node_group = mesh_tree
    previous = {old_mesh}
    for node in rig_target.node_group.nodes:
        if node.bl_idname != 'GeometryNodeGroup' or not node.node_tree:
            continue
        if node.node_tree.get('gyogan_role') != 'armature_warp':
            continue
        inputs = [(link.from_socket, link.to_socket.name) for link in node.inputs[0].links]
        outputs = [(link.from_socket.name, link.to_socket) for link in node.outputs[0].links]
        previous.add(node.node_tree)
        node.node_tree = arm_tree
        for source, name in inputs:
            rig_target.node_group.links.new(source, node.inputs[name])
        for name, destination in outputs:
            rig_target.node_group.links.new(node.outputs[name], destination)
    for tree in previous:
        if tree.users == 0:
            bpy.data.node_groups.remove(tree)
    return mesh_tree, arm_tree


def run():
    if not bpy.app.background:
        raise RuntimeError('3Dカーソルの検証は専用のバックグラウンドプロセスで実行してください')
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if not hasattr(bpy.types.Scene, 'gyogan'):
        addon.register()
    checks, exception = [], None

    def check(name, condition, **details):
        checks.append(dict(test=name, passed=bool(condition), **details))

    def compare(name, actual, expected, tolerance=2.e-4):
        difference = error(actual, expected)
        check(name, difference < tolerance, max_error=difference)

    try:
        scene = bpy.context.scene
        scene.name = '3Dカーソル・専用検証'
        settings = scene.gyogan
        camera = bpy.data.objects.new('カーソル検証・カメラ', bpy.data.cameras.new('カーソル検証・カメラ'))
        scene.collection.objects.link(camera)
        camera.location, camera.rotation_euler.x, camera.data.lens = (0., -10., 2.), math.pi / 2., 28.
        scene.camera = settings.camera = camera
        scene.render.resolution_x, scene.render.resolution_y = 1280, 720
        settings.effect_scope, settings.subdivision = 'MANUAL', 'NONE'
        refresh(scene)
        grid = make_mesh(scene, 'カーソル検証・格子',
                         [(x, y, .3*x) for y in (-1., 0., 1.) for x in (-2., 0., 2.)],
                         [(a, a+1, a+4, a+3) for a in (0, 1, 3, 4)])
        grid.matrix_world = camera.matrix_world @ Matrix.Translation((2., 0., -6.))
        original_grid = positions(scene, grid)
        raw_grid = [tuple(v.co) for v in grid.data.vertices]
        grid_target = addon.setup_mesh(scene, grid)
        rig, body = make_rig(scene)
        raw_body = [tuple(v.co) for v in body.data.vertices]
        source_pose = bone_points(scene, rig)
        rig_target = addon.setup_armature(scene, rig)
        output = rig_target.outputs[0].output
        check('legacy_default_mode_is_object_with_no_center', settings.center_mode == 'OBJECT'
              and settings.center_object is None)
        compare('legacy_unset_mesh_stays_optical_axis', positions(scene, grid), oracle(scene, original_grid))
        anchor = make_empty(scene, 'カーソル検証・中心', (2., .6, -6.))
        refresh(scene)
        settings.center_object = anchor
        object_mesh = positions(scene, grid)
        object_bones = bone_points(scene, rig_target.output_rig)
        object_skin = positions(scene, output)
        scene.cursor.location = anchor.matrix_world.translation
        object_ids = {obj.as_pointer() for obj in scene.objects}
        settings.center_mode = 'CURSOR'
        compare('cursor_mesh_equals_object_at_same_location', positions(scene, grid), object_mesh)
        compare('cursor_bones_equal_object_at_same_location', bone_points(scene, rig_target.output_rig), object_bones)
        compare('cursor_skin_equals_object_at_same_location', positions(scene, output), object_skin)
        check('cursor_keeps_dormant_object_pointer', settings.center_object == anchor)
        check('cursor_disconnects_object_from_generated_graphs', center_inputs(scene)
              and all(value is None for value in center_inputs(scene)))
        check('cursor_requires_no_new_scene_object', object_ids == {obj.as_pointer() for obj in scene.objects})

        group_identity = {tree.as_pointer(): (len(tree.nodes), len(tree.links))
                          for tree in bpy.data.node_groups if tree.get(addon.OWNER)}
        anchor.location += Vector((20., 20., 20.))
        compare('dormant_object_movement_has_no_influence', positions(scene, grid), object_mesh)
        scene.cursor.location = camera.matrix_world @ Vector((-1.5, .5, -5.))
        immediate_mesh = untagged_positions(grid)
        immediate_bones = untagged_bone_points(rig_target.output_rig)
        compare('cursor_move_updates_mesh_without_timer_or_explicit_scene_tag', immediate_mesh,
                oracle(scene, original_grid, scene.cursor.location))
        compare('cursor_move_updates_bones_without_timer_or_explicit_scene_tag', immediate_bones,
                oracle(scene, source_pose, scene.cursor.location))
        check('cursor_move_changes_result', error(positions(scene, grid), object_mesh) > .01)
        check('cursor_move_preserves_node_group_identity_and_topology', group_identity == {
            tree.as_pointer(): (len(tree.nodes), len(tree.links)) for tree in bpy.data.node_groups
            if tree.get(addon.OWNER)})

        # Native cursor tools do not dirty drivers like RNA assignment does.
        # Simulate the existing timer's next tick, without manually tagging the
        # scene between the operator and evaluation of the resulting geometry.
        anchor.location = camera.matrix_world @ Vector((1.25, -.75, -7.))
        select_only(anchor)
        refresh(scene)
        addon.targets._tick()
        before_native = untagged_positions(grid)
        native_result = snap_cursor_to_selected()
        addon.targets._tick()
        native_mesh = untagged_positions(grid)
        native_bones = untagged_bone_points(rig_target.output_rig)
        check('native_cursor_snap_operator_finishes', native_result == {'FINISHED'})
        compare('native_cursor_snap_timer_updates_mesh', native_mesh,
                oracle(scene, original_grid, scene.cursor.location))
        compare('native_cursor_snap_timer_updates_bones', native_bones,
                oracle(scene, source_pose, scene.cursor.location))
        check('native_cursor_snap_changes_deformation', error(native_mesh, before_native) > .01)
        check('stationary_cursor_requires_no_repeated_refresh', not addon.targets.refresh_cursor(scene)
              and not addon.targets.refresh_cursor(scene))

        # Rendering may start before the next timer tick. Its initialization
        # must consume the latest native cursor move before evaluation too.
        anchor.location = camera.matrix_world @ Vector((-1.25, .75, -7.))
        refresh(scene)
        addon.targets._tick()
        snap_cursor_to_selected()
        try:
            addon.targets._render_init(scene)
            render_mesh = untagged_positions(grid)
            render_bones = untagged_bone_points(rig_target.output_rig)
            compare('render_init_flushes_native_cursor_mesh', render_mesh,
                    oracle(scene, original_grid, scene.cursor.location))
            compare('render_init_flushes_native_cursor_bones', render_bones,
                    oracle(scene, source_pose, scene.cursor.location))
        finally:
            addon.targets._render_done(scene)
        settings.center_object = None
        compare('cursor_works_without_object_pointer', positions(scene, grid),
                oracle(scene, original_grid, scene.cursor.location))
        settings.center_object = anchor
        settings.center_mode = 'DEFAULT'
        compare('explicit_default_ignores_both_centers', positions(scene, grid), oracle(scene, original_grid))
        check('default_keeps_dormant_object_pointer', settings.center_object == anchor)
        check('default_disconnects_object_from_generated_graphs', all(value is None for value in center_inputs(scene)))
        settings.center_mode = 'OBJECT'
        compare('object_mode_restores_dormant_anchor', positions(scene, grid), oracle(scene, original_grid, anchor.matrix_world.translation))
        settings.center_mode = 'CURSOR'
        for label, point in (('behind', (3., 2., 1.)), ('at_camera', (0., 0., 0.)),
                             ('inside_near', (1., 1., -.05)), ('near_fade', (.1, .04, -.15))):
            scene.cursor.location = camera.matrix_world @ Vector(point)
            compare('cursor_' + label + '_mesh_fallback', positions(scene, grid),
                    oracle(scene, original_grid, scene.cursor.location))
            compare('cursor_' + label + '_bone_fallback', bone_points(scene, rig_target.output_rig),
                    oracle(scene, source_pose, scene.cursor.location))
        scene.cursor.location = camera.matrix_world @ Vector((1.4, -.6, -6.))
        settings.strength, settings.ellipse_x, settings.ellipse_y = -1.4, .7, 1.8
        compare('cursor_negative_elliptical_mesh', positions(scene, grid), oracle(scene, original_grid, scene.cursor.location))
        compare('cursor_negative_elliptical_bones', bone_points(scene, rig_target.output_rig), oracle(scene, source_pose, scene.cursor.location))
        settings.strength = 0.
        compare('cursor_zero_strength_preserves_mesh', positions(scene, grid), original_grid)
        compare('cursor_zero_strength_preserves_pose', bone_points(scene, rig_target.output_rig), source_pose)
        settings.strength = 1.
        settings.enabled = False
        compare('cursor_preview_off_restores_mesh', positions(scene, grid), original_grid)
        check('cursor_preview_off_restores_source_visibility', not body.hide_get() and not body.hide_render
              and output.hide_get() and output.hide_render)
        settings.enabled = True
        settings.ellipse_x = settings.ellipse_y = 1.
        second_camera = bpy.data.objects.new('カーソル検証・別カメラ', bpy.data.cameras.new('カーソル検証・別カメラ'))
        scene.collection.objects.link(second_camera)
        second_camera.location, second_camera.rotation_euler, second_camera.data.lens = (.6, -10., 2.), camera.rotation_euler, 35.
        settings.camera = second_camera
        refresh(scene)
        check('cursor_camera_switch_synchronizes_active_camera', scene.camera == second_camera)
        compare('cursor_reprojects_through_new_camera_mesh', positions(scene, grid), oracle(scene, original_grid, scene.cursor.location))
        compare('cursor_reprojects_through_new_camera_bones', bone_points(scene, rig_target.output_rig), oracle(scene, source_pose, scene.cursor.location))
        settings.camera = camera

        # A tiny boundary fixture has a clear inside/outside oracle. Reconcile
        # is exactly the worker invoked by the automatic scope timer.
        probe = make_mesh(scene, 'カーソル検証・枠判定',
                          [(-.01, -.01, 0.), (.01, -.01, 0.), (.01, .01, 0.), (-.01, .01, 0.)],
                          [(0, 1, 2, 3)])
        probe.matrix_world = camera.matrix_world @ Matrix.Translation((6., 0., -6.))
        settings.effect_scope, settings.mode = 'CAMERA', 'MESH'
        scene.cursor.location = camera.matrix_world @ Vector((0., 0., -6.))
        settle(scene)
        first_active = (probe.name, 'MESH') in active(scene)
        scene.cursor.location = camera.matrix_world @ Vector((6., 0., -6.))
        settle(scene)
        second_active = (probe.name, 'MESH') in active(scene)
        check('cursor_move_refreshes_automatic_camera_membership', first_active and not second_active,
              first=first_active, second=second_active)
        settings.effect_scope = 'MANUAL'
        settle(scene)

        scene.cursor.location = camera.matrix_world @ Vector((1.4, -.6, -6.))
        cursor_id = addon.presets.save_active(scene).uuid
        object_id = addon.presets.create(scene, duplicate=True).uuid
        settings.center_mode = 'OBJECT'
        addon.presets.save_active(scene)
        cursor_position = tuple(scene.cursor.location)
        addon.presets.activate(scene, cursor_id)
        settle(scene)
        check('preset_restores_cursor_mode', settings.center_mode == 'CURSOR')
        check('preset_does_not_restore_cursor_location', tuple(scene.cursor.location) == cursor_position)
        old_preset = next(item for item in settings.presets if item.uuid == object_id)
        old_values = json.loads(old_preset.settings_json)
        old_values.pop('center_mode')
        old_preset.settings_json = json.dumps(old_values)
        addon.presets.activate(scene, object_id)
        settle(scene)
        check('old_preset_missing_mode_migrates_to_object', settings.center_mode == 'OBJECT')
        check('old_preset_keeps_center_reference', settings.center_object == anchor)
        addon.presets.activate(scene, cursor_id)
        scene.cursor.location.x += .25
        moved_cursor = tuple(scene.cursor.location)
        addon.presets.activate(scene, object_id)
        addon.presets.activate(scene, cursor_id)
        settle(scene)
        check('switching_presets_keeps_shared_cursor_position', tuple(scene.cursor.location) == moved_cursor)

        # Freeze old graph topology, then upgrade in place for both mesh and rig.
        settings.center_mode = 'OBJECT'
        anchor.location = camera.matrix_world @ Vector((1., .2, -6.))
        refresh(scene)
        grid_target, rig_target = record(scene, grid), record(scene, rig, 'ARMATURE')
        # The automatic MESH scope may replace the shared skin's cached mode;
        # reacquire its ARMATURE output after returning to manual registration.
        output = rig_target.outputs[0].output
        old_trees = legacy_groups(scene, grid_target, rig_target)
        before_upgrade = positions(scene, grid), positions(scene, output)
        old_ids = [tree.as_pointer() for tree in old_trees]
        old_nodes = [{node.as_pointer() for node in tree.nodes} for tree in old_trees]
        for tree in old_trees:
            addon.nodes.upgrade_cursor_group(tree, scene)
        check('legacy_upgrade_preserves_mesh_and_rig_group_ids', old_ids == [tree.as_pointer() for tree in old_trees])
        check('legacy_upgrade_preserves_existing_nodes', all(nodes.issubset({node.as_pointer() for node in tree.nodes})
              for tree, nodes in zip(old_trees, old_nodes)))
        compare('legacy_upgrade_preserves_object_center_mesh_result', positions(scene, grid), before_upgrade[0], 1.e-6)
        compare('legacy_upgrade_preserves_object_center_skin_result', positions(scene, output), before_upgrade[1], 1.e-6)
        node_counts = [len(tree.nodes) for tree in old_trees]
        for tree in old_trees:
            addon.nodes.upgrade_cursor_group(tree, scene)
        check('legacy_upgrade_is_idempotent', node_counts == [len(tree.nodes) for tree in old_trees])
        settings.center_mode = 'CURSOR'
        compare('upgraded_mesh_uses_cursor', positions(scene, grid), oracle(scene, original_grid, scene.cursor.location))
        compare('upgraded_armature_uses_cursor', bone_points(scene, rig_target.output_rig), oracle(scene, source_pose, scene.cursor.location))

        names = {key: obj.name for key, obj in dict(grid=grid, rig=rig, body=body, output=output, anchor=anchor).items()}
        saved = positions(scene, grid), positions(scene, output)
        saved_cursor = tuple(scene.cursor.location)
        bpy.ops.wm.save_as_mainfile(filepath=str(FIXTURE), check_existing=False)
        bpy.ops.wm.open_mainfile(filepath=str(FIXTURE))
        scene, settings = bpy.context.scene, bpy.context.scene.gyogan
        grid, rig, body, output, anchor = [scene.objects[names[key]] for key in ('grid', 'rig', 'body', 'output', 'anchor')]
        settle(scene)
        check('save_reload_keeps_cursor_mode_and_position', settings.center_mode == 'CURSOR'
              and tuple(scene.cursor.location) == saved_cursor)
        check('save_reload_keeps_dormant_object_reference', settings.center_object == anchor)
        compare('save_reload_preserves_cursor_mesh', positions(scene, grid), saved[0])
        compare('save_reload_preserves_cursor_skin', positions(scene, output), saved[1])
        select_only(grid)
        bpy.ops.ed.undo_push(message='カーソル中心・変更前')
        settings.center_mode = 'DEFAULT'
        scene.cursor.location.x += 2.
        bpy.ops.ed.undo_push(message='カーソル中心・変更後')
        undo_result = bpy.ops.ed.undo()
        scene, settings = bpy.context.scene, bpy.context.scene.gyogan
        grid, rig, body, output, anchor = [scene.objects[names[key]] for key in ('grid', 'rig', 'body', 'output', 'anchor')]
        settle(scene)
        check('native_undo_restores_cursor_mode', undo_result == {'FINISHED'}
              and settings.center_mode == 'CURSOR')
        # Blender owns the cursor position's Undo policy; this addon must use
        # whatever scene cursor Blender supplies after restoring addon mode.
        compare('native_undo_uses_current_scene_cursor', positions(scene, grid),
                oracle(scene, original_grid, scene.cursor.location))
        anchor.location = scene.camera.matrix_world @ Vector((-.7, -.3, -6.))
        select_only(anchor)
        refresh(scene)
        addon.targets._tick()
        snap_cursor_to_selected()
        addon.targets._tick()
        resumed_mesh = untagged_positions(grid)
        compare('native_cursor_timer_resumes_after_undo', resumed_mesh,
                oracle(scene, original_grid, scene.cursor.location))
        check('native_cursor_cache_is_idle_after_undo_refresh', not addon.targets.refresh_cursor(scene))
        scene.cursor.location.x += .4
        compare('cursor_remains_live_after_undo', positions(scene, grid), oracle(scene, original_grid, scene.cursor.location))
        settings.enabled = False
        compare('saved_cursor_off_restores_original_mesh', positions(scene, grid), original_grid)
        check('cursor_source_raw_mesh_data_unchanged', raw_grid == [tuple(v.co) for v in grid.data.vertices]
              and raw_body == [tuple(v.co) for v in body.data.vertices])
        while settings.targets:
            addon.remove_target(scene, len(settings.targets) - 1)
        check('cursor_remove_preserves_original_rig_and_modifiers', not grid.modifiers
              and len(body.modifiers) == 1 and body.modifiers[0].object == rig)
    except Exception:
        exception = traceback.format_exc()
        print(exception)
    finally:
        passed = bool(checks) and all(item['passed'] for item in checks) and exception is None
        report = dict(blender=bpy.app.version_string, passed=passed, checks=checks, exception=exception)
        REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        print('GYOGAN_CURSOR_RESULTS=' + json.dumps(report, ensure_ascii=False))
    if not passed:
        raise AssertionError('3Dカーソルの検証に失敗しました: ' + str(REPORT))


if __name__ == '__main__':
    run()
