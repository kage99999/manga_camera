"""Live subdivision regression checks in an isolated Blender process.

The evaluated face counts are the public result: a single quad must acquire
enough vertices before the fisheye modifier to bend smoothly. Original mesh,
shape keys, user modifiers and animation remain untouched throughout.
"""

import json
import math
import sys
import traceback
from pathlib import Path

import bpy

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
from test_paths import output_path
from blender_center import addon, make_mesh, refresh
from blender_targets import square, settle, record, fish_modifiers, select_only, owned_ids

REPORT = output_path('subdivision_result.json')
FIXTURE = output_path('subdivision_pending.blend')


def subdivision(scene, source):
    return next((modifier for modifier in fish_modifiers(scene, source)
                 if modifier.type == 'SUBSURF'), None)


def face_count(scene, source):
    evaluated = source.evaluated_get(refresh(scene))
    mesh = evaluated.to_mesh()
    try:
        return len(mesh.polygons)
    finally:
        evaluated.to_mesh_clear()


def modifier_state(modifier):
    return (modifier.persistent_uid, modifier.subdivision_type, modifier.levels,
            modifier.render_levels, modifier.show_viewport, modifier.show_render)


def original_mesh(source):
    return (tuple(tuple(vertex.co) for vertex in source.data.vertices),
            tuple(tuple(face.vertices) for face in source.data.polygons),
            tuple((block.name, tuple(tuple(vertex.co) for vertex in block.data))
                  for block in source.data.shape_keys.key_blocks)
            if source.data.shape_keys else ())


def before_fisheye(scene, source):
    modifiers = list(source.modifiers)
    extra = subdivision(scene, source)
    target = record(scene, source)
    fish = next((modifier for modifier in modifiers
                 if modifier.type == 'NODES' and modifier.node_group == target.node_group), None)
    return extra is not None and fish is not None and modifiers.index(extra) < modifiers.index(fish)


def grid(scene, name, size=10):
    vertices = [(x / size, y / size, 0.)
                for y in range(size + 1) for x in range(size + 1)]
    faces = [(y * (size + 1) + x, y * (size + 1) + x + 1,
              (y + 1) * (size + 1) + x + 1, (y + 1) * (size + 1) + x)
             for y in range(size) for x in range(size)]
    return make_mesh(scene, name, vertices, faces)


def run():
    if not bpy.app.background:
        raise RuntimeError('追加分割の検証は専用のバックグラウンドプロセスで実行してください')
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if not hasattr(bpy.types.Scene, 'gyogan'):
        addon.register()
    checks, exception = [], None

    def check(name, condition, **details):
        checks.append(dict(test=name, passed=bool(condition), **details))

    def faces(name, scene, source, expected):
        actual = face_count(scene, source)
        check(name, actual == expected, expected=expected, actual=actual)

    try:
        scene = bpy.context.scene
        scene.name = '追加分割・専用検証'
        settings = scene.gyogan
        camera = bpy.data.objects.new('分割検証・カメラ', bpy.data.cameras.new('分割検証・カメラ'))
        scene.collection.objects.link(camera)
        camera.location = (0., 0., 10.)
        scene.camera = settings.camera = camera
        scene.render.resolution_x = scene.render.resolution_y = 200
        settings.effect_scope = 'MANUAL'
        settings.subdivision = 'SIMPLE'
        settings.viewport_levels = settings.render_levels = 1
        settings.fov = math.radians(90.)
        settings.strength = 1.
        plate = square(scene, '分割検証・平板', (.5, .5, 0.), half_size=1.5)
        plate.shape_key_add(name='Basis')
        shape = plate.shape_key_add(name='元の形状キー')
        shape.data[2].co.z = .2
        shape.value = .3
        source_mesh = original_mesh(plate)
        original_data = plate.data.as_pointer()
        original_keys = plate.data.shape_keys.as_pointer()
        target = addon.setup_mesh(scene, plate)
        token, node = target.token, target.node_group.as_pointer()
        settle(scene)
        extra = subdivision(scene, plate)
        uid = extra.persistent_uid
        faces('single_quad_starts_with_four_evaluated_faces', scene, plate, 4)
        check('initial_subdivision_precedes_fisheye', before_fisheye(scene, plate))

        # A pre-existing per-object choice is not overwritten by navigation or
        # migration; only an explicit settings change requests synchronization.
        extra.levels = 2
        settle(scene)
        check('ordinary_updates_preserve_existing_per_object_level', extra.levels == 2)
        settings.viewport_levels = 3
        for _ in range(3):
            refresh(scene)
            addon.targets._tick()
        extra = subdivision(scene, plate)
        faces('panel_level_three_changes_existing_quad_to_64_faces', scene, plate, 64)
        check('timer_preserves_existing_modifier_identity', extra.persistent_uid == uid)
        check('timer_preserves_existing_warp_graph_and_target', record(scene, plate).token == token
              and record(scene, plate).node_group.as_pointer() == node)
        check('viewport_change_does_not_change_render_level', extra.render_levels == 1)
        settings.render_levels = 4
        settle(scene)
        check('render_level_is_updated_independently', extra.render_levels == 4 and extra.levels == 3)
        settings.viewport_levels = 0
        settle(scene)
        faces('zero_viewport_subdivision_restores_one_face', scene, plate, 1)
        settings.viewport_levels = 2
        settings.render_levels = 2
        settings.subdivision = 'CATMULL_CLARK'
        settle(scene)
        faces('smooth_mode_updates_existing_modifier_geometry', scene, plate, 16)
        check('smooth_mode_applies_without_reregistration', extra.subdivision_type == 'CATMULL_CLARK'
              and extra.persistent_uid == uid)
        settings.subdivision = 'NONE'
        settle(scene)
        faces('none_disables_additional_faces', scene, plate, 1)
        check('none_keeps_owned_modifier_for_reuse', subdivision(scene, plate).persistent_uid == uid)
        check('none_disables_viewport_and_render', not extra.show_viewport and not extra.show_render)
        settings.enabled = False
        settings.enabled = True
        settle(scene)
        faces('preview_cycle_does_not_reenable_none_subdivision', scene, plate, 1)
        settings.subdivision = 'SIMPLE'
        settle(scene)
        faces('simple_reuses_cached_subdivision', scene, plate, 16)
        check('simple_restores_both_visibility_flags', extra.show_viewport and extra.show_render)
        check('mode_changes_keep_subdivision_before_fisheye', before_fisheye(scene, plate))
        check('all_live_changes_preserve_source_vertices_faces_and_keys', original_mesh(plate) == source_mesh)
        check('all_live_changes_preserve_mesh_and_key_ids', plate.data.as_pointer() == original_data
              and plate.data.shape_keys.as_pointer() == original_keys)

        settings.enabled = False
        settings.viewport_levels = 3
        settle(scene)
        check('preview_off_still_accepts_new_subdivision_level', extra.levels == 3)
        check('preview_off_keeps_subdivision_disabled', not extra.show_viewport and not extra.show_render)
        faces('preview_off_preserves_original_geometry', scene, plate, 1)
        settings.enabled = True
        settle(scene)
        faces('preview_on_uses_the_latest_level', scene, plate, 64)
        settings.effect_scope = 'CAMERA'
        camera.location.x = 50.
        settle(scene)
        check('camera_departure_deactivates_cached_target', not record(scene, plate).active)
        settings.viewport_levels = 1
        settle(scene)
        check('offscreen_cached_target_gets_new_level', extra.levels == 1 and not extra.show_viewport)
        faces('offscreen_object_keeps_its_original_one_face', scene, plate, 1)
        camera.location.x = 0.
        settle(scene)
        faces('camera_reentry_uses_changed_cached_level', scene, plate, 4)
        check('camera_reentry_keeps_original_target_and_modifier', record(scene, plate).token == token
              and subdivision(scene, plate).persistent_uid == uid)
        settings.effect_scope = 'MANUAL'
        settle(scene)

        # Registration with NONE has no extra modifier yet. Enabling it later
        # must insert it before the warp and preserve unrelated stack entries.
        settings.subdivision = 'NONE'
        settle(scene)
        bare = square(scene, '分割検証・後から分割', (-1., 0., 0.))
        addon.setup_mesh(scene, bare)
        post = bare.modifiers.new('ユーザーの後段処理', 'DISPLACE')
        post.strength = 0.
        post_uid = post.persistent_uid
        check('none_registration_has_no_owned_subdivision', subdivision(scene, bare) is None)
        settings.subdivision = 'SIMPLE'
        settle(scene)
        faces('enabling_subdivision_updates_previously_bare_target', scene, bare, 4)
        check('new_subdivision_is_inserted_before_warp', before_fisheye(scene, bare))
        check('adding_subdivision_preserves_user_post_modifier', bare.modifiers[-1].persistent_uid == post_uid
              and bare.modifiers[-1].strength == 0.)
        user_plate = square(scene, '分割検証・既存の分割あり', (0., -1., 0.))
        user = user_plate.modifiers.new('ユーザーの既存分割', 'SUBSURF')
        user.subdivision_type = 'CATMULL_CLARK'
        user.levels = 2
        user.render_levels = 3
        user_state = modifier_state(user)
        addon.setup_mesh(scene, user_plate)
        settings.viewport_levels = 2
        settle(scene)
        check('existing_user_subdivision_is_not_changed', modifier_state(user) == user_state)
        check('existing_user_subdivision_is_not_duplicated', subdivision(scene, user_plate) is None
              and sum(mod.type == 'SUBSURF' for mod in user_plate.modifiers) == 1)

        # The limit applies to each source. A rejected target retains all its
        # old modifier settings while inexpensive targets can still update.
        dense = grid(scene, '分割検証・上限対象')
        settings.viewport_levels = settings.render_levels = 1
        settle(scene)
        addon.setup_mesh(scene, dense)
        dense_extra = subdivision(scene, dense)
        dense_state = modifier_state(dense_extra)
        settings.face_limit = 1000
        settings.viewport_levels = settings.render_levels = 3
        settle(scene)
        check('over_budget_target_preserves_previous_complete_state', modifier_state(dense_extra) == dense_state)
        faces('over_budget_target_keeps_previous_geometry', scene, dense, 400)
        faces('over_budget_neighbor_does_not_block_small_target', scene, plate, 64)
        check('over_budget_target_reports_japanese_reason', '上限' in settings.subdivision_status
              and dense.name in settings.subdivision_status, status=settings.subdivision_status)
        settings.viewport_levels = settings.render_levels = 0
        settle(scene)
        faces('reducing_requested_levels_retries_previous_failure', scene, dense, 100)
        settings.viewport_levels = settings.render_levels = 2
        settle(scene)
        faces('limit_still_blocks_excessive_new_request', scene, dense, 100)
        settings.face_limit = 2000000
        settle(scene)
        faces('raising_face_limit_retries_previous_failure', scene, dense, 1600)

        # Do not replace the user's edit mode or attempt structural updates
        # while edit data is authoritative.
        select_only(plate)
        bpy.ops.object.mode_set(mode='EDIT')
        settings.viewport_levels = 3
        for _ in range(2):
            addon.targets._tick()
        check('edit_mode_is_not_changed_by_live_update', plate.mode == 'EDIT')
        check('edit_mode_defers_subdivision_changes', extra.levels == 2 and settings.subdivision_pending)
        bpy.ops.object.mode_set(mode='OBJECT')
        for _ in range(3):
            refresh(scene)
            addon.targets._tick()
        faces('return_to_object_mode_flushes_pending_level', scene, plate, 64)
        check('successful_flush_clears_pending_flag', not settings.subdivision_pending)

        # Render immediately after editing the UI: the normal timer has not
        # run yet. Inspect the actual RENDER dependency graph, so checking a
        # stored modifier value alone cannot hide a stale rendered mesh.
        settings.viewport_levels = 0
        settle(scene)
        scene.render.engine = 'BLENDER_WORKBENCH'
        scene.render.resolution_x = scene.render.resolution_y = 32
        scene.render.resolution_percentage = 100
        scene.render.image_settings.file_format = 'PNG'
        scene.render.filepath = str(output_path('subdivision_immediate_render.png'))
        scene.frame_start = scene.frame_end = scene.frame_current
        scene.render.use_lock_interface = False
        settings.render_levels = 3
        check('immediate_render_begins_before_timer_flush', settings.subdivision_pending
              and extra.render_levels == 2)
        check('pending_manual_update_locks_render_before_launch', scene.render.use_lock_interface
              and settings.render_lock_owned and not settings.render_lock_original)
        rendered_counts, render_pre_state = [], []

        def observe_render_geometry(_scene, depsgraph):
            if depsgraph.mode == 'RENDER':
                evaluated = plate.evaluated_get(depsgraph)
                rendered_counts.append(len(evaluated.data.polygons))

        def observe_render_pre(render_scene):
            render_pre_state.append((render_scene.gyogan.subdivision_pending,
                                     subdivision(render_scene, plate).render_levels,
                                     render_scene.render.use_lock_interface))

        bpy.app.handlers.depsgraph_update_post.append(observe_render_geometry)
        bpy.app.handlers.frame_change_post.append(observe_render_geometry)
        bpy.app.handlers.render_pre.append(observe_render_pre)
        try:
            bpy.ops.render.render(animation=True, write_still=True)
        finally:
            bpy.app.handlers.depsgraph_update_post.remove(observe_render_geometry)
            bpy.app.handlers.frame_change_post.remove(observe_render_geometry)
            bpy.app.handlers.render_pre.remove(observe_render_pre)
        check('render_init_flushes_pending_settings_before_render_pre', render_pre_state == [(False, 3, True)],
              observed=render_pre_state)
        check('immediate_render_evaluates_64_faces_at_render_level_three',
              bool(rendered_counts) and all(count == 64 for count in rendered_counts), observed=rendered_counts)
        faces('render_level_does_not_change_viewport_geometry', scene, plate, 1)
        check('completed_render_restores_previous_interface_lock', not scene.render.use_lock_interface
              and not settings.render_lock_owned)

        keyed = square(scene, '分割検証・追加分割のキーあり')
        settings.viewport_levels = settings.render_levels = 1
        settle(scene)
        addon.setup_mesh(scene, keyed)
        keyed_extra = subdivision(scene, keyed)
        keyed_extra.keyframe_insert('levels', frame=1)
        action_pointer = keyed.animation_data.action.as_pointer()
        keyed_state = modifier_state(keyed_extra)
        driven = square(scene, '分割検証・追加分割のドライバーあり')
        addon.setup_mesh(scene, driven)
        driven_extra = subdivision(scene, driven)
        driver = driven_extra.driver_add('render_levels')
        driver.driver.expression = '1'
        refresh(scene)
        driver_pointer = driver.as_pointer()
        driven_state = modifier_state(driven_extra)
        settings.viewport_levels = settings.render_levels = 2
        settle(scene)
        check('owned_subdivision_keyframes_protect_entire_modifier', modifier_state(keyed_extra) == keyed_state)
        check('owned_subdivision_driver_protects_entire_modifier', modifier_state(driven_extra) == driven_state)
        check('live_update_preserves_user_action_identity', keyed.animation_data.action.as_pointer() == action_pointer)
        check('live_update_preserves_user_driver_identity_and_expression', driver.as_pointer() == driver_pointer
              and driver.driver.expression == '1')
        check('protected_subdivision_reports_reason', bool(settings.subdivision_status)
              and keyed.name in settings.subdivision_status, status=settings.subdivision_status)
        faces('animated_neighbor_does_not_block_ordinary_target', scene, plate, 16)
        settings.subdivision = 'NONE'
        settle(scene)
        check('none_does_not_disable_keyed_owned_subdivision', modifier_state(keyed_extra) == keyed_state)
        check('none_does_not_disable_driven_owned_subdivision', modifier_state(driven_extra) == driven_state)
        # The user explicitly removes their animation so normal cleanup and
        # subsequent global changes no longer need to skip these targets.
        keyed.animation_data_clear()
        driven.animation_data_clear()
        settings.subdivision = 'SIMPLE'
        settle(scene)

        # Saving while an update is deferred preserves the request. The reload
        # handler and timer must resume it without a second settings edit.
        select_only(plate)
        bpy.ops.object.mode_set(mode='EDIT')
        settings.viewport_levels = 3
        check('save_fixture_has_pending_request', settings.subdivision_pending)
        plate_name, user_plate_name = plate.name, user_plate.name
        all_tokens = {target.token for target in settings.targets}
        bpy.ops.wm.save_as_mainfile(filepath=str(FIXTURE))
        bpy.ops.wm.open_mainfile(filepath=str(FIXTURE))
        scene, settings = bpy.context.scene, bpy.context.scene.gyogan
        plate, user_plate = bpy.data.objects[plate_name], bpy.data.objects[user_plate_name]
        if bpy.context.object and bpy.context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        for _ in range(3):
            refresh(scene)
            addon.targets._tick()
        faces('reload_resumes_saved_pending_subdivision', scene, plate, 64)
        check('reload_keeps_original_geometry_and_shape_keys', original_mesh(plate) == source_mesh)
        check('reload_keeps_target_identity', record(scene, plate).token == token)
        check('reload_finishes_pending_request', not settings.subdivision_pending)

        select_only(plate)
        bpy.ops.ed.undo_push(message='追加分割・レベル３')
        settings.viewport_levels = 1
        settle(scene)
        faces('pre_undo_change_reduces_faces', scene, plate, 4)
        bpy.ops.ed.undo_push(message='追加分割・レベル１')
        undo_result = bpy.ops.ed.undo()
        scene, settings = bpy.context.scene, bpy.context.scene.gyogan
        plate, user_plate = bpy.data.objects[plate_name], bpy.data.objects[user_plate_name]
        for _ in range(3):
            refresh(scene)
            addon.targets._tick()
        check('native_undo_restores_panel_level', undo_result == {'FINISHED'} and settings.viewport_levels == 3)
        faces('native_undo_restores_evaluated_subdivision', scene, plate, 64)
        check('native_undo_preserves_source_data', original_mesh(plate) == source_mesh)
        settings.viewport_levels = 2
        settle(scene)
        faces('live_updates_continue_after_undo', scene, plate, 16)
        bpy.ops.gyogan.remove_all()
        settle(scene)
        check('removal_leaves_original_mesh_and_shape_keys', original_mesh(plate) == source_mesh)
        check('removal_removes_owned_modifiers', len(plate.modifiers) == 0)
        check('removal_preserves_user_subdivision', len(user_plate.modifiers) == 1
              and user_plate.modifiers[0].name == 'ユーザーの既存分割'
              and modifier_state(user_plate.modifiers[0]) == user_state)
        check('removal_releases_generated_ids', not owned_ids(all_tokens))
        check('removal_does_not_recreate_targets', not settings.targets and not settings.manual_targets)
    except Exception:
        exception = traceback.format_exc()
        print(exception)
    finally:
        passed = bool(checks) and all(item['passed'] for item in checks) and exception is None
        report = dict(blender=bpy.app.version_string, passed=passed, checks=checks, exception=exception)
        REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        print('GYOGAN_SUBDIVISION_RESULTS=' + json.dumps(report, ensure_ascii=False))
    if not passed:
        raise AssertionError('追加分割の検証に失敗しました: ' + str(REPORT))


if __name__ == '__main__':
    run()
