"""Persistence and recovery integration checks in an isolated Blender process.

Run: Blender 5.2 --background --factory-startup --python tests/blender_persistence.py
This intentionally resets its process to an empty file and reopens its own test
file. Do not execute this script through MCP or in an interactive user session.
"""

import json
import math
import sys
import traceback
from pathlib import Path

import bpy
from mathutils import Vector


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
from test_paths import output_path
BLEND_PATH = output_path('persistence_fixture.blend')
REPORT_PATH = output_path('persistence_result.json')
sys.path.insert(0, str(ROOT))
sys.dont_write_bytecode = True
import gyogan_camera as addon


def refresh(scene):
    scene.update_tag()
    bpy.context.view_layer.update()
    return bpy.context.evaluated_depsgraph_get()


def positions(scene, obj):
    evaluated = obj.evaluated_get(refresh(scene))
    mesh = evaluated.to_mesh()
    try:
        return [evaluated.matrix_world @ vertex.co for vertex in mesh.vertices]
    finally:
        evaluated.to_mesh_clear()


def position_error(a, b):
    if len(a) != len(b):
        return float("inf")
    return max(((p - q).length for p, q in zip(a, b)), default=0.0)


def make_mesh(scene, name, vertices, faces, collection=None):
    mesh = bpy.data.meshes.new(name + " Data")
    mesh.from_pydata(vertices, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    (collection or scene.collection).objects.link(obj)
    return obj


def owned_ids(tokens):
    return [item.name for kind in ("objects", "meshes", "armatures", "node_groups", "collections")
            for item in getattr(bpy.data, kind) if item.get(addon.OWNER) in tokens]


def emulate_legacy_projection(tree):
    """Persist the old effective warp topology for an actual load_post upgrade."""
    theta = next(node for node in tree.nodes
                 if node.bl_idname == 'ShaderNodeMath' and node.operation == 'ARCTAN2')
    radius = next(node.outputs['Value'] for node in tree.nodes
                  if node.bl_idname == 'ShaderNodeVectorMath' and node.operation == 'LENGTH')
    numerator = next(link.to_node for link in theta.outputs[0].links
                     if link.to_node.bl_idname == 'ShaderNodeMath' and link.to_node.operation == 'MULTIPLY')
    division = next(link.to_node for link in numerator.outputs[0].links
                    if link.to_node.bl_idname == 'ShaderNodeMath' and link.to_node.operation == 'DIVIDE')
    denominator = division.inputs[1].links[0].from_node
    assert denominator.bl_idname == 'ShaderNodeMath' and denominator.operation == 'MAXIMUM'
    tree.links.new(radius, theta.inputs[0])
    tree.links.new(radius, denominator.inputs[0])
    on_axis = next(node for node in tree.nodes
                   if node.bl_idname == 'ShaderNodeMath' and node.operation == 'LESS_THAN')
    tree.links.new(radius, on_axis.inputs[0])
    if 'gyogan_projection_version' in tree:
        del tree['gyogan_projection_version']
    tree.update_tag()


def run():
    if not bpy.app.background:
        raise RuntimeError("Run this destructive fixture only in a separate background Blender process")
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if not hasattr(bpy.types.Scene, "gyogan"):
        addon.register()
    results = []
    exception = None

    def check(name, condition, **details):
        results.append({"test": name, "passed": bool(condition), **details})

    try:
        scene = bpy.context.scene
        scene.name = "Gyogan Persistence Fixture"
        scene.render.resolution_x, scene.render.resolution_y = 1280, 720
        first_layer = scene.view_layers[0]
        first_layer.name = "Originally Visible"
        second_layer = scene.view_layers.new("Originally Hidden")
        camera = bpy.data.objects.new("Persistence Camera", bpy.data.cameras.new("Persistence Camera Data"))
        scene.collection.objects.link(camera)
        camera.data.lens = 32.0
        scene.camera = scene.gyogan.camera = camera
        settings = scene.gyogan
        settings.subdivision = "SIMPLE"
        settings.viewport_levels = settings.render_levels = 0
        settings.strength = 0.0

        grid = make_mesh(scene, "Persistence Grid",
                         [(2, -1, -6), (4, -1, -6), (4, 1, -6), (2, 1, -6)],
                         [(0, 1, 2, 3)])
        original_modifier = grid.modifiers.new("User Original Triangulation", "TRIANGULATE")
        original_modifier.show_render = False
        original_modifier_uid = original_modifier.persistent_uid
        baseline_grid = positions(scene, grid)
        mesh_target = addon.setup_mesh(scene, grid)
        mesh_token = mesh_target.token
        for index, record in enumerate(mesh_target.modifiers):
            addon.find_modifier(grid, record).name = f"Renamed generated modifier {index}"

        armature_data = bpy.data.armatures.new("Persistence Source Skeleton")
        rig = bpy.data.objects.new("Persistence Source Rig", armature_data)
        scene.collection.objects.link(rig)
        bpy.context.view_layer.objects.active = rig
        rig.select_set(True)
        bpy.ops.object.mode_set(mode="EDIT")
        root = armature_data.edit_bones.new("Root")
        root.head, root.tail = (0, 0, 0), (0, 1, 0)
        tip = armature_data.edit_bones.new("Tip")
        tip.head, tip.tail = (0, 1, 0), (0, 2, 0)
        tip.parent, tip.use_connect = root, True
        bpy.ops.object.mode_set(mode="OBJECT")
        rig.location = (2, -1, -6)
        body = make_mesh(scene, "Persistence Body",
                         [(x, y, z) for y in (0.0, 1.0, 2.0)
                          for x, z in ((-0.2, -0.2), (0.2, -0.2), (0.2, 0.2), (-0.2, 0.2))],
                         [(4*j+i, 4*j+(i+1)%4, 4*(j+1)+(i+1)%4, 4*(j+1)+i)
                          for j in range(2) for i in range(4)])
        body.location = rig.location.copy()
        groups = [body.vertex_groups.new(name=name) for name in ("Root", "Tip")]
        for vertex in body.data.vertices:
            amount = vertex.co.y / 2.0
            groups[0].add([vertex.index], 1.0 - amount, "REPLACE")
            groups[1].add([vertex.index], amount, "REPLACE")
        original_armature_modifier = body.modifiers.new("User Original Skin", "ARMATURE")
        original_armature_modifier.object = rig
        original_armature_uid = original_armature_modifier.persistent_uid
        baseline_body_data = [tuple(vertex.co) for vertex in body.data.vertices]
        body.hide_set(True, view_layer=second_layer)

        hidden_collection = bpy.data.collections.new("User Render Hidden Clothes")
        scene.collection.children.link(hidden_collection)
        hidden_collection.hide_render = True
        garment = body.copy()
        garment.name = "Persistence Hidden Garment"
        hidden_collection.objects.link(garment)
        rig_target = addon.setup_armature(scene, rig)
        rig_token = rig_target.token
        output_name = next(record.output.name for record in rig_target.outputs if record.source == body)
        output_rig_name = rig_target.output_rig.name
        # Force iteration order to encounter the nested group before its parent.
        for group in bpy.data.node_groups:
            if group.get(addon.OWNER) == rig_token:
                group.name = ("AA Renamed nested warp" if group.get("gyogan_role") == "armature_warp"
                              else "ZZ Renamed parent calculation")

        for frame, strength, angle in ((1, 0.0, 0.0), (11, 2.5, 0.35), (21, 0.25, -0.25)):
            settings.strength = strength
            settings.keyframe_insert(data_path="strength", frame=frame)
            rig.pose.bones["Root"].rotation_mode = "XYZ"
            rig.pose.bones["Root"].rotation_euler.z = angle
            rig.pose.bones["Root"].keyframe_insert(data_path="rotation_euler", frame=frame)
        scene.frame_set(11)
        refresh(scene)
        legacy_groups = {}
        for group in bpy.data.node_groups:
            if (group.get(addon.OWNER) in {mesh_token, rig_token}
                    and group.get('gyogan_role') in {'mesh_warp', 'armature_warp'}):
                emulate_legacy_projection(group)
                legacy_groups[group.get('gyogan_role')] = group.name
        check("legacy_mesh_and_armature_saved_for_migration",
              set(legacy_groups) == {'mesh_warp', 'armature_warp'}
              and all('gyogan_projection_version' not in bpy.data.node_groups[name]
                      for name in legacy_groups.values()), groups=legacy_groups)
        bpy.ops.wm.save_as_mainfile(filepath=str(BLEND_PATH), check_existing=False)
        bpy.ops.wm.open_mainfile(filepath=str(BLEND_PATH), load_ui=False)

        # All source and output handles must be reacquired after reopening.
        scene = bpy.context.scene
        settings = scene.gyogan
        grid = bpy.data.objects["Persistence Grid"]
        rig = bpy.data.objects["Persistence Source Rig"]
        body = bpy.data.objects["Persistence Body"]
        garment = bpy.data.objects["Persistence Hidden Garment"]
        camera = settings.camera
        first_layer = scene.view_layers["Originally Visible"]
        second_layer = scene.view_layers["Originally Hidden"]
        mesh_target = next(target for target in settings.targets if target.kind == "MESH")
        rig_target = next(target for target in settings.targets if target.kind == "ARMATURE")
        output = bpy.data.objects[output_name]
        output_rig = bpy.data.objects[output_rig_name]
        graph = refresh(scene)
        migrated_versions = {role: bpy.data.node_groups[name].get('gyogan_projection_version')
                             for role, name in legacy_groups.items()}
        check("load_post_upgrades_mesh_and_armature_automatically",
              migrated_versions == {'mesh_warp': 2, 'armature_warp': 2}, versions=migrated_versions)
        drivers = [curve for group in bpy.data.node_groups if group.get(addon.OWNER) in {mesh_token, rig_token}
                   and group.animation_data for curve in group.animation_data.drivers]
        check("save_reopen_metadata_and_drivers",
              len(settings.targets) == 2 and len(drivers) >= 8
              and all(curve.is_valid for curve in drivers)
              and all(addon.find_modifier(grid, record) is not None for record in mesh_target.modifiers)
              and settings.camera == scene.camera and body.hide_render and len(rig_target.outputs) == 2,
              driver_count=len(drivers), target_count=len(settings.targets))

        frame_corners = camera.data.view_frame(scene=scene)
        half_width = (max(point.x / -point.z for point in frame_corners)
                      - min(point.x / -point.z for point in frame_corners)) * 0.5
        mesh_errors, bone_errors = [], []
        snapshots = {}
        replay_errors = []
        expected_strengths = {1: 0.0, 11: 2.5, 21: 0.25}
        strengths_ok = True
        for frame in (1, 11, 21, 11, 1, 21):
            scene.frame_set(frame)
            graph = refresh(scene)
            strength = settings.strength
            strengths_ok = strengths_ok and abs(strength - expected_strengths[frame]) < 1.0e-6
            expected = [Vector(addon.nodes.camera_space_reference(
                point, strength, settings.fov, settings.zoom, settings.near_distance, half_width))
                        for point in baseline_grid]
            actual = positions(scene, grid)
            mesh_errors.append(position_error(actual, expected))
            source_eval, output_eval = rig.evaluated_get(graph), output_rig.evaluated_get(graph)
            heads = []
            for bone in source_eval.pose.bones:
                original_head = source_eval.matrix_world @ bone.matrix.translation
                wanted_head = Vector(addon.nodes.camera_space_reference(
                    original_head, strength, settings.fov, settings.zoom, settings.near_distance, half_width))
                actual_head = output_eval.matrix_world @ output_eval.pose.bones[bone.name].matrix.translation
                heads.append(actual_head.copy())
                bone_errors.append((actual_head - wanted_head).length)
            if frame in snapshots:
                replay_errors.append(position_error(heads, snapshots[frame]))
            else:
                snapshots[frame] = heads
        check("keyed_mesh_projection_nonsequential_frames", strengths_ok and max(mesh_errors) < 3.0e-5,
              max_error=max(mesh_errors), frames=[1, 11, 21, 11, 1, 21], strengths=expected_strengths)
        check("keyed_output_bones_nonsequential_frames",
              max(bone_errors) < 5.0e-5 and max(replay_errors) < 1.0e-6
              and position_error(snapshots[1], snapshots[11]) > 0.1,
              max_head_error=max(bone_errors), max_replay_error=max(replay_errors))

        hidden_collection = bpy.data.collections["User Render Hidden Clothes"]
        garment_output = next(record.output for record in rig_target.outputs if record.source == garment)
        check("source_collection_render_visibility_inherited",
              hidden_collection.hide_render and set(garment_output.users_collection) == set(garment.users_collection)
              and hidden_collection in garment_output.users_collection and not garment_output.hide_render)

        first_layer.name = "User renamed visible layer"
        second_layer.name = "User renamed hidden layer"
        settings.enabled = False
        disabled_error = position_error(positions(scene, grid), baseline_grid)
        generated_modifiers = [addon.find_modifier(grid, record) for record in mesh_target.modifiers]
        check("disable_restores_renamed_layer_and_modifiers",
              disabled_error < 1.0e-6 and not body.hide_get(view_layer=first_layer)
              and body.hide_get(view_layer=second_layer) and not body.hide_render
              and output.hide_render
              and all(not modifier.show_viewport and not modifier.show_render for modifier in generated_modifiers)
              and grid.modifiers[0].persistent_uid == original_modifier_uid
              and grid.modifiers[0].show_viewport and not grid.modifiers[0].show_render,
              disabled_error=disabled_error)
        settings.enabled = True

        generated_collection = rig_target.collection
        generated_collection_name = generated_collection.name
        user_collection = bpy.data.collections.new("User nested collection")
        generated_collection.children.link(user_collection)
        user_object = make_mesh(scene, "User nested object", [(0, 0, 0), (1, 0, 0), (0, 1, 0)],
                                [(0, 1, 2)], collection=user_collection)
        while settings.targets:
            addon.remove_target(scene, len(settings.targets) - 1)
        remaining = owned_ids({mesh_token, rig_token})
        check("renamed_nested_node_groups_cleanup", not remaining, leftover=remaining)
        surviving_collection = bpy.data.collections.get(generated_collection_name)
        check("user_nested_collection_survives_cleanup",
              surviving_collection is not None and addon.OWNER not in surviving_collection
              and user_collection.name in surviving_collection.children
              and user_object.name in scene.objects and user_object.name in user_collection.objects)
        check("remove_restores_sources_and_original_modifiers",
              not body.hide_get(view_layer=first_layer) and body.hide_get(view_layer=second_layer)
              and not body.hide_render and hidden_collection.hide_render
              and len(grid.modifiers) == 1 and grid.modifiers[0].persistent_uid == original_modifier_uid
              and len(body.modifiers) == 1 and body.modifiers[0].persistent_uid == original_armature_uid
              and body.modifiers[0].object == rig
              and [tuple(vertex.co) for vertex in body.data.vertices] == baseline_body_data)

        # Recovery must work after manual deletion of only some generated IDs.
        settings.enabled = True
        partial = addon.setup_armature(scene, rig)
        partial_token = partial.token
        deleted_output = next(record.output for record in partial.outputs if record.source == body)
        bpy.data.objects.remove(deleted_output, do_unlink=True)
        bpy.data.objects.remove(partial.calculator, do_unlink=True)
        addon.remove_target(scene, 0)
        partial_leftovers = owned_ids({partial_token})
        check("partial_generated_deletion_cleanup",
              not partial_leftovers and not settings.targets and not body.hide_render
              and not body.hide_get(view_layer=first_layer) and body.hide_get(view_layer=second_layer),
              leftover=partial_leftovers)

        # Disabling the extension restores display while retaining metadata so
        # re-enabling it can remove the previously generated data safely.
        settings.enabled = True
        addon.setup_mesh(scene, grid)
        addon.setup_armature(scene, rig)
        reload_tokens = {target.token for target in settings.targets}
        addon.unregister()
        unregister_restored = not body.hide_render and not body.hide_get(view_layer=first_layer)
        addon.register()
        settings = scene.gyogan
        metadata_retained = len(settings.targets) == 2 and not settings.enabled
        while settings.targets:
            addon.remove_target(scene, len(settings.targets) - 1)
        reload_leftovers = owned_ids(reload_tokens)
        check("unregister_reregister_preserves_restoration",
              unregister_restored and metadata_retained and not reload_leftovers
              and len(grid.modifiers) == 1 and len(body.modifiers) == 1
              and body.modifiers[0].object == rig and not body.hide_render
              and body.hide_get(view_layer=second_layer), leftover=reload_leftovers)
    except Exception:
        exception = traceback.format_exc()
        print(exception)
    finally:
        passed = bool(results) and all(result["passed"] for result in results) and exception is None
        report = {"blender": bpy.app.version_string, "checks": results, "passed": passed,
                  "fixture": str(BLEND_PATH), "exception": exception}
        REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        print("GYOGAN_PERSISTENCE_RESULTS=" + json.dumps(report, ensure_ascii=False))
    if not passed:
        raise AssertionError("Persistence/recovery checks failed; inspect " + str(REPORT_PATH))


if __name__ == "__main__":
    run()
