"""Frozen regression fixture: actual pre-center strength-v2 node implementation.

Captured from the working implementation on 2026-09-21, before the center-object
change. Keep this fixture unchanged when developing production nodes.py so the
upgrade tests continue to exercise old topology instead of an emulated new graph.

The functions in this module only create node groups. They never modify source
mesh coordinates, apply modifiers, or install frame/depsgraph handlers.
"""

from __future__ import annotations

import math

try:
    import bpy
except ModuleNotFoundError:  # The reference function can be used outside Blender.
    bpy = None


EPSILON = 1.0e-8
PROJECTION_VERSION = 2


class Graph:
    """Small socket-oriented graph builder, also used by the armature engine."""

    def __init__(self, tree):
        self.tree = tree
        self._index = 0

    def node(self, idname, label=None):
        node = self.tree.nodes.new(idname)
        if label:
            node.label = label
        # Keep generated graphs inspectable without an expensive layout pass.
        node.location = ((self._index % 8) * 205, -(self._index // 8) * 175)
        self._index += 1
        return node

    def connect(self, value, node, socket=0):
        """Connect an output socket or set an input's constant value."""
        target = node.inputs[socket]
        if isinstance(value, bpy.types.NodeSocket):
            self.tree.links.new(value, target)
        else:
            target.default_value = value
        return node

    def math(self, operation, a, b=None, c=None):
        node = self.node("ShaderNodeMath")
        node.operation = operation
        self.connect(a, node, 0)
        if b is not None:
            self.connect(b, node, 1)
        if c is not None:
            self.connect(c, node, 2)
        return node.outputs[0]

    def vector(self, operation, a, b=None, scale=None):
        node = self.node("ShaderNodeVectorMath")
        node.operation = operation
        self.connect(a, node, 0)
        if b is not None:
            self.connect(b, node, 1)
        if scale is not None:
            self.connect(scale, node, "Scale")
        if operation in {"LENGTH", "DISTANCE", "DOT_PRODUCT"}:
            return node.outputs["Value"]
        return node.outputs["Vector"]

    def xyz(self, x, y, z):
        node = self.node("ShaderNodeCombineXYZ")
        for name, value in zip(("X", "Y", "Z"), (x, y, z)):
            self.connect(value, node, name)
        return node.outputs["Vector"]

    def separate(self, vector):
        node = self.node("ShaderNodeSeparateXYZ")
        self.connect(vector, node, "Vector")
        return tuple(node.outputs[name] for name in ("X", "Y", "Z"))

    def transform(self, matrix, point):
        node = self.node("FunctionNodeTransformPoint")
        self.connect(point, node, "Vector")
        self.connect(matrix, node, "Transform")
        return node.outputs["Vector"]

    def project(self, matrix, point):
        node = self.node("FunctionNodeProjectPoint")
        self.connect(point, node, "Vector")
        self.connect(matrix, node, "Transform")
        return node.outputs["Vector"]

    def inverse(self, matrix):
        node = self.node("FunctionNodeInvertMatrix")
        self.connect(matrix, node, 0)
        return node.outputs[0]

    def switch(self, condition, false_value, true_value, input_type="FLOAT"):
        node = self.node("GeometryNodeSwitch")
        node.input_type = input_type
        self.connect(condition, node, "Switch")
        self.connect(false_value, node, "False")
        self.connect(true_value, node, "True")
        return node.outputs["Output"]

    def driven_value(self, owner, data_path, label=None):
        """Use a simple property driver: no Python driver namespace or handler."""
        node = self.node("ShaderNodeValue", label or data_path)
        output = node.outputs[0]
        output.default_value = float(owner.path_resolve(data_path))
        fcurve = output.driver_add("default_value")
        driver = fcurve.driver
        driver.type = "AVERAGE"
        variable = driver.variables.new()
        variable.name = "value"
        variable.type = "SINGLE_PROP"
        target = variable.targets[0]
        target.id_type = owner.id_type
        target.id = owner
        target.data_path = data_path
        return output


class CameraWarp:
    """Reusable live warp from a point to a point in the same coordinate space.

    ``space='RELATIVE'`` means the geometry modifier owner's local space;
    ``space='ORIGINAL'`` means world space. Reuse one instance for all points in
    a graph, so camera information, projection calibration and setting drivers
    are shared. The camera pointer is captured at construction and must be
    rebuilt if the user chooses another camera. Its transforms, lens, shift,
    render aspect and the numerical settings remain live dependencies.
    """

    def __init__(self, graph, scene, settings_path="gyogan", space="RELATIVE"):
        if space not in {"ORIGINAL", "RELATIVE"}:
            raise ValueError("変形に使用する座標系の指定が正しくありません")
        self.graph = graph
        self.space = space
        settings = scene.path_resolve(settings_path)
        camera = settings.camera
        if camera is None or camera.type != "CAMERA":
            raise ValueError("魚眼変形の基準カメラを指定してください")
        if camera.data.type != "PERSP":
            raise ValueError("魚眼変形には透視投影カメラを使用してください")
        g = graph

        self.strength = g.driven_value(scene, settings_path + ".strength", "魚眼の強度")
        self.angular_strength = g.math("MAXIMUM", self.strength, 1.0)
        self.angular_strength.node.label = "標準を超える歪みの強調"
        g.tree["gyogan_projection_version"] = PROJECTION_VERSION
        self.fov = g.driven_value(scene, settings_path + ".fov", "魚眼画角 (rad)")
        self.zoom = g.driven_value(scene, settings_path + ".zoom", "画面内サイズ")
        self.near = g.driven_value(scene, settings_path + ".near_distance", "カメラ面の保護範囲")

        camera_info = g.node("GeometryNodeObjectInfo", "基準カメラのワールド姿勢")
        camera_info.transform_space = "ORIGINAL"
        camera_info.inputs["Object"].default_value = camera

        # Camera scale does not alter a perspective camera's projection. Strip
        # it in world space, before the owner's possibly nonuniform transform.
        camera_pose = g.node("FunctionNodeCombineTransform", "カメラの位置・回転（スケールを除外）")
        g.connect(camera_info.outputs["Location"], camera_pose, "Translation")
        g.connect(camera_info.outputs["Rotation"], camera_pose, "Rotation")
        camera_pose.inputs["Scale"].default_value = (1.0, 1.0, 1.0)
        self.camera_matrix = camera_pose.outputs["Transform"]
        self.camera_inverse = g.inverse(self.camera_matrix)
        self.owner_matrix = None
        self.owner_inverse = None
        if space == "RELATIVE":
            owner = g.node("GeometryNodeSelfObject", "変形対象")
            owner_info = g.node("GeometryNodeObjectInfo", "対象の全変換（非一様スケール対応）")
            owner_info.transform_space = "ORIGINAL"
            g.connect(owner.outputs[0], owner_info, "Object")
            self.owner_matrix = owner_info.outputs["Transform"]
            self.owner_inverse = g.inverse(self.owner_matrix)

        projection_info = g.node("GeometryNodeCameraInfo", "レンズ・シフト・出力アスペクト")
        projection_info.inputs["Camera"].default_value = camera
        inverse_projection = g.inverse(projection_info.outputs["Projection Matrix"])
        center = g.project(inverse_projection, (0.0, 0.0, 0.0))
        right = g.project(inverse_projection, (1.0, 0.0, 0.0))
        cx, cy, cz = g.separate(center)
        rx, _, rz = g.separate(right)
        self.shift_x = g.math("DIVIDE", cx, g.math("MULTIPLY", cz, -1.0))
        self.shift_y = g.math("DIVIDE", cy, g.math("MULTIPLY", cz, -1.0))
        right_slope = g.math("DIVIDE", rx, g.math("MULTIPLY", rz, -1.0))
        self.horizontal_half_width = g.math(
            "ABSOLUTE", g.math("SUBTRACT", right_slope, self.shift_x)
        )
        # k = h / (horizontal fisheye FOV / 2). Lens shift remains the
        # perspective camera's principal-point offset; it is not cancelled.
        safe_fov = g.math("MAXIMUM", self.fov, 1.0e-4)
        safe_zoom = g.math("MAXIMUM", self.zoom, 0.0)
        self.k = g.math(
            "DIVIDE",
            g.math("MULTIPLY", g.math("MULTIPLY", self.horizontal_half_width, 2.0), safe_zoom),
            safe_fov,
        )

    def apply(self, position):
        """Return a deformed point socket, preserving depth in camera space."""
        g = self.graph
        world = g.transform(self.owner_matrix, position) if self.owner_matrix is not None else position
        camera_point = g.transform(self.camera_inverse, world)
        x, y, z = g.separate(camera_point)
        depth = g.math("MULTIPLY", z, -1.0)
        radius = g.vector("LENGTH", g.xyz(x, y, 0.0))
        angular_radius = g.math("MULTIPLY", radius, self.angular_strength)
        positive_depth = g.math("MAXIMUM", depth, EPSILON)
        theta = g.math("ARCTAN2", angular_radius, positive_depth)
        radial_scale = g.math(
            "DIVIDE",
            g.math("MULTIPLY", g.math("MULTIPLY", positive_depth, self.k), theta),
            g.math("MAXIMUM", angular_radius, EPSILON),
        )
        # For s>1: R=d*k*atan(q*r/d)/q, q=max(s,1). Its radial derivative is
        # k/(1+(q*r/d)^2)>0: amplify peripheral compression without extrapolating
        # through zero or reversing radial order. s<=1 retains the old mapping.
        # Analytic on-axis limit: d*k*atan(q*r/d)/(q*r) -> k. A relative threshold
        # avoids flattening microscopic but otherwise valid scenes.
        on_axis = g.math("LESS_THAN", radius, g.math("MULTIPLY", positive_depth, 1.0e-6))
        radial_scale = g.switch(on_axis, radial_scale, self.k)
        warped_camera = g.xyz(
            g.math("MULTIPLY", x, radial_scale),
            g.math("MULTIPLY", y, radial_scale),
            z,
        )
        warped_world = g.transform(self.camera_matrix, warped_camera)
        warped = g.transform(self.owner_inverse, warped_world) if self.owner_inverse is not None else warped_world

        # Fade continuously to identity around the camera plane. Behind the
        # plane and up to near_distance are unchanged; the warp reaches full
        # strength at 2*near_distance. No clipping or vertex deletion occurs.
        safe_near = g.math("MAXIMUM", self.near, EPSILON)
        fade = g.math("DIVIDE", g.math("SUBTRACT", depth, safe_near), safe_near)
        fade = g.math("MINIMUM", g.math("MAXIMUM", fade, 0.0), 1.0)
        smooth_fade = g.math(
            "MULTIPLY", g.math("MULTIPLY", fade, fade),
            g.math("SUBTRACT", 3.0, g.math("MULTIPLY", fade, 2.0)),
        )
        strength = g.math("MINIMUM", g.math("MAXIMUM", self.strength, 0.0), 1.0)
        weight = g.math("MULTIPLY", strength, smooth_fade)
        offset = g.vector("SUBTRACT", warped, position)
        offset = g.vector("SCALE", offset, scale=weight)
        # Interpolate in input space so strength=0 yields the original point
        # exactly, without a matrix round-trip tolerance.
        return g.vector("ADD", position, offset)


def build_mesh_group(name, scene, settings_path="gyogan"):
    """Build one group shared by all of a scene's registered mesh modifiers."""
    tree = bpy.data.node_groups.new(name, "GeometryNodeTree")
    try:
        tree.interface.new_socket(name="Geometry", in_out="INPUT", socket_type="NodeSocketGeometry")
        tree.interface.new_socket(name="Geometry", in_out="OUTPUT", socket_type="NodeSocketGeometry")
        tree.is_modifier = True
        g = Graph(tree)
        group_input = g.node("NodeGroupInput", "入力形状")
        group_output = g.node("NodeGroupOutput", "魚眼変形（元データは保持）")
        group_output.is_active_output = True
        realize = g.node("GeometryNodeRealizeInstances", "既存のインスタンスを変形用に実体化")
        g.connect(group_input.outputs["Geometry"], realize, "Geometry")
        position = g.node("GeometryNodeInputPosition")
        warp = CameraWarp(g, scene, settings_path=settings_path)
        set_position = g.node("GeometryNodeSetPosition", "深度を保持した等距離魚眼")
        g.connect(realize.outputs["Geometry"], set_position, "Geometry")
        g.connect(warp.apply(position.outputs["Position"]), set_position, "Position")
        g.connect(set_position.outputs["Geometry"], group_output, "Geometry")
        tree["gyogan_schema"] = 1
        tree["gyogan_role"] = "mesh_warp"
        return tree
    except Exception:
        bpy.data.node_groups.remove(tree)
        raise


def upgrade_strength_group(tree):
    """Upgrade an owned legacy warp in place, preserving references and IDs.

    Only the angular radius subgraph changes. The original blend, near fade,
    interface, drivers and armature matrix consumers are preserved.
    """
    if (not tree.get("gyogan_owner")
            or tree.get("gyogan_role") not in {"mesh_warp", "armature_warp"}
            or tree.get("gyogan_projection_version", 1) >= PROJECTION_VERSION):
        return False
    drivers = tree.animation_data.drivers if tree.animation_data else ()
    strength_paths = {curve.data_path for curve in drivers
                      if any(target.data_path.endswith(".strength")
                             for variable in curve.driver.variables
                             for target in variable.targets)}
    strength_nodes = [node for node in tree.nodes
                      if node.bl_idname == "ShaderNodeValue"
                      and node.outputs[0].path_from_id("default_value") in strength_paths]
    plan = []
    for theta in tree.nodes:
        if theta.bl_idname != "ShaderNodeMath" or theta.operation != "ARCTAN2":
            continue
        if not theta.inputs[0].is_linked:
            continue
        radius = theta.inputs[0].links[0].from_socket
        if radius.node.bl_idname != "ShaderNodeVectorMath" or radius.node.operation != "LENGTH":
            continue
        denominators = [node for node in tree.nodes
                        if node.bl_idname == "ShaderNodeMath" and node.operation == "MAXIMUM"
                        and node.inputs[0].is_linked
                        and node.inputs[0].links[0].from_socket == radius
                        and not node.inputs[1].is_linked
                        and abs(node.inputs[1].default_value - EPSILON) < 1e-12]
        if len(denominators) != 1:
            raise ValueError("既存の魚眼ノード構成が変更されているため、自動更新できません")
        plan.append((theta, radius, denominators[0]))
    if len(strength_nodes) != 1 or not plan:
        raise ValueError("既存の魚眼ノード構成が変更されているため、自動更新できません")
    graph = Graph(tree)
    graph._index = len(tree.nodes)
    angular_strength = graph.math("MAXIMUM", strength_nodes[0].outputs[0], 1.0)
    angular_strength.node.label = "標準を超える歪みの強調"
    for theta, radius, denominator in plan:
        angular_radius = graph.math("MULTIPLY", radius, angular_strength)
        graph.connect(angular_radius, theta, 0)
        graph.connect(angular_radius, denominator, 0)
    tree["gyogan_projection_version"] = PROJECTION_VERSION
    return True


def camera_space_reference(point, strength, fov, zoom, near_distance, horizontal_half_width):
    """Pure Python oracle matching CameraWarp, for isolated numerical tests.

    ``point`` is a camera-space XYZ tuple, FOV is horizontal and in radians,
    and horizontal_half_width is the camera frame's half width at depth 1.
    Lens shift is applied later by the actual camera projection.
    """
    x, y, z = point
    depth = -z
    near = max(float(near_distance), EPSILON)
    fade = min(max((depth - near) / near, 0.0), 1.0)
    weight = min(max(float(strength), 0.0), 1.0) * fade * fade * (3.0 - 2.0 * fade)
    if weight == 0.0:
        return tuple(point)
    radius = math.hypot(x, y)
    k = 2.0 * abs(horizontal_half_width) * max(zoom, 0.0) / max(fov, 1.0e-4)
    positive_depth = max(depth, EPSILON)
    if radius < positive_depth * 1.0e-6:
        scale = k
    else:
        angular_radius = radius * max(float(strength), 1.0)
        scale = positive_depth * k * math.atan2(angular_radius, positive_depth) / max(angular_radius, EPSILON)
    return (x + weight * (x * scale - x), y + weight * (y * scale - y), z)
