"""Reversible camera dolly zoom using persistent, simple RNA drivers."""

import math
import textwrap
import uuid

import bpy
from bpy.props import (BoolProperty, FloatProperty, FloatVectorProperty,
                       PointerProperty, StringProperty)
from bpy.types import Operator, PropertyGroup
from mathutils import Vector


PREFIX = 'gyogan_dolly.'
TRANSFORMS = ('location', 'rotation_euler', 'rotation_quaternion',
              'rotation_axis_angle', 'scale', 'delta_location',
              'delta_rotation_euler', 'delta_rotation_quaternion', 'delta_scale')
SNAPSHOTS = ('active', 'camera', 'camera_data', 'base_location', 'base_lens',
             'depth', 'back_axis', 'near_clip', 'lens_max', 'target_position',
             'target_name', 'token', 'status', 'ratio', 'enabled')
EFFECTIVE_EXPRESSION = 'min(max(r,1/b,n*1.01/d),m/b)'


def effective_ratio(settings):
    if not settings.enabled:
        return 1.0
    return min(max(settings.ratio, 1.0 / settings.base_lens,
                   settings.near_clip * 1.01 / settings.depth),
               settings.lens_max / settings.base_lens)


def _factor(settings):
    # This getter is for UI / diagnostics only. Node drivers read the source
    # properties directly: a Scene driver reading its own derived property
    # would create a PARAMETERS_EVAL dependency cycle in Blender 5.2.
    return (effective_ratio(settings)
            if settings.active and settings.compensate_fisheye else 1.0)


def _matches(path, prefixes):
    return any(path == prefix or path.startswith(prefix + '.')
               or path.startswith(prefix + '[') for prefix in prefixes)


def _action_curves(action, slot_handle=None):
    if not action:
        return
    for curve in getattr(action, 'fcurves', ()):
        yield curve
    for layer in getattr(action, 'layers', ()):
        for strip in layer.strips:
            for bag in getattr(strip, 'channelbags', ()):
                if slot_handle is None or bag.slot_handle == slot_handle:
                    yield from bag.fcurves


def _strip_curves(strip):
    yield from _action_curves(getattr(strip, 'action', None),
                             getattr(strip, 'action_slot_handle', None))
    for child in getattr(strip, 'strips', ()):
        yield from _strip_curves(child)


def _has_animation(owner, paths):
    animation = owner.animation_data
    if not animation:
        return False
    curves = list(animation.drivers)
    curves.extend(_action_curves(animation.action,
                                 getattr(animation, 'action_slot_handle', None)))
    for track in animation.nla_tracks:
        for strip in track.strips:
            curves.extend(_strip_curves(strip))
    return any(_matches(curve.data_path, paths) for curve in curves)


def _editable(owner):
    return not owner.library and not owner.override_library and owner.is_editable


def _near(values, expected):
    return all(abs(a - b) <= 1e-6 for a, b in zip(values, expected))


def _preflight(scene):
    settings = scene.gyogan_dolly
    if settings.active:
        raise ValueError('ドリーズームは開始済みです。いったん元のカメラに戻してください')
    camera = getattr(getattr(scene, 'gyogan', None), 'camera', None) or scene.camera
    if camera is None or camera.type != 'CAMERA' or camera.name not in scene.objects:
        raise ValueError('このシーンの基準カメラを指定してください')
    data = camera.data
    if data.type != 'PERSP':
        raise ValueError('ドリーズームには透視投影カメラが必要です')
    if not all(_editable(item) for item in (scene, camera, data)):
        raise ValueError('リンクやライブラリーオーバーライドのカメラ・シーンには対応していません')
    if camera.parent:
        raise ValueError('親が設定されたカメラには対応していません。独立したカメラを使用してください')
    if any(not constraint.mute for constraint in camera.constraints):
        raise ValueError('制約が有効なカメラには対応していません。制約のないカメラを使用してください')
    if (not _near(camera.delta_location, (0, 0, 0))
            or not _near(camera.delta_rotation_euler, (0, 0, 0))
            or not _near(camera.delta_rotation_quaternion, (1, 0, 0, 0))
            or not _near(camera.delta_scale, (1, 1, 1))):
        raise ValueError('デルタトランスフォームがあるカメラには対応していません')
    if _has_animation(camera, TRANSFORMS) or _has_animation(data, ('lens',)):
        raise ValueError('カメラの移動・回転・拡縮や焦点距離にアニメーション、NLA、ドライバーがあります。独立したカメラを使用してください')
    if len(camera.users_scene) > 1:
        raise ValueError('複数シーンで共有されたカメラには対応していません')
    if any(obj != camera and obj.type == 'CAMERA' and obj.data == data
           for obj in bpy.data.objects):
        raise ValueError('カメラデータが共有されています。カメラデータを独立させてください')
    protected = tuple(PREFIX + name for name in SNAPSHOTS if name not in {'ratio'})
    if _has_animation(scene, protected):
        raise ValueError('ドリーズームの内部設定にアニメーションやドライバーがあるため開始できません')
    target = settings.target
    if target and target.name not in scene.objects:
        raise ValueError('基準の被写体は、このシーンのオブジェクトを指定してください')
    return camera


def _specs(scene):
    """Reconstruct exact signatures so altered drivers are never claimed."""
    settings = scene.gyogan_dolly
    owner_name = 'owner_' + settings.token
    common = {
        'r': PREFIX + 'ratio', 'e': PREFIX + 'enabled',
        'b': PREFIX + 'base_lens', 'd': PREFIX + 'depth',
        'n': PREFIX + 'near_clip', 'm': PREFIX + 'lens_max',
        owner_name: PREFIX + 'active',
    }
    effective = f'({EFFECTIVE_EXPRESSION} if e else 1)'
    suffix = '+0*' + owner_name
    result = []
    if settings.camera:
        for axis in range(3):
            variables = dict(common, p=f'{PREFIX}base_location[{axis}]',
                             a=f'{PREFIX}back_axis[{axis}]')
            result.append((settings.camera, 'location', axis, variables,
                           f'p+a*d*({effective}-1){suffix}'))
    if settings.camera_data:
        result.append((settings.camera_data, 'lens', None, common,
                       f'b*{effective}{suffix}'))
    return result


def _find_curve(owner, path, index):
    animation = owner.animation_data
    if animation:
        return next((curve for curve in animation.drivers
                     if curve.data_path == path
                     and (index is None or curve.array_index == index)), None)
    return None


def _owned(curve, scene, variables, expression):
    if (curve is None or curve.mute or curve.modifiers
            or curve.keyframe_points or curve.sampled_points):
        return False
    driver = curve.driver
    if driver.type != 'SCRIPTED' or driver.expression != expression or driver.use_self:
        return False
    if len(driver.variables) != len(variables):
        return False
    for variable in driver.variables:
        if (variable.type != 'SINGLE_PROP' or variable.name not in variables
                or len(variable.targets) != 1):
            return False
        target = variable.targets[0]
        if (target.id != scene or target.data_path != variables[variable.name]
                or getattr(target, 'use_fallback_value', False)):
            return False
    return True


def _configure_driver(curve, scene, variables, expression):
    # Blender creates two identity-mapping points with each new driver. These
    # freshly owned curves use the expression directly; remove that implicit
    # mapping so any later user-authored mapping is an ownership conflict.
    curve.keyframe_points.clear()
    driver = curve.driver
    driver.type = 'SCRIPTED'
    driver.use_self = False
    for old_variable in list(driver.variables):
        driver.variables.remove(old_variable)
    for name, data_path in variables.items():
        variable = driver.variables.new()
        variable.name = name
        variable.type = 'SINGLE_PROP'
        target = variable.targets[0]
        target.id_type = 'SCENE'
        target.id = scene
        target.data_path = data_path
    driver.expression = expression


def configure_factor_driver(curve, scene):
    """Drive an owned node socket directly, without a Scene self-dependency."""
    variables = {
        'r': PREFIX + 'ratio', 'e': PREFIX + 'enabled',
        'c': PREFIX + 'compensate_fisheye', 't': PREFIX + 'active',
        'b': PREFIX + 'base_lens', 'd': PREFIX + 'depth',
        'n': PREFIX + 'near_clip', 'm': PREFIX + 'lens_max',
    }
    _configure_driver(curve, scene, variables,
                      f'{EFFECTIVE_EXPRESSION} if t and e and c else 1')


def _install_driver(scene, spec, created):
    owner, path, index, variables, expression = spec
    curve = owner.driver_add(path) if index is None else owner.driver_add(path, index)
    created.append((owner, curve))
    _configure_driver(curve, scene, variables, expression)


def setup(scene):
    """Capture a static camera and target, then attach four owned drivers."""
    camera = _preflight(scene)
    settings = scene.gyogan_dolly
    with bpy.context.temp_override(scene=scene, view_layer=scene.view_layers[0]):
        bpy.context.view_layer.update()
        graph = bpy.context.evaluated_depsgraph_get()
        target = (settings.target.evaluated_get(graph).matrix_world.translation.copy()
                  if settings.target else scene.cursor.location.copy())
    # No parent, constraints or transform animation: location equals world location.
    location = camera.location.copy()
    axis = camera.matrix_world.to_3x3().col[2].normalized()
    depth = (location - target).dot(axis)
    if (not math.isfinite(depth) or axis.length < 0.99
            or depth <= camera.data.clip_start * 1.01):
        raise ValueError('基準の被写体をカメラ前方の表示範囲に置いてください。未指定の場合は3Dカーソルを使用します')
    previous = {name: getattr(settings, name) for name in SNAPSHOTS}
    for name in ('base_location', 'back_axis', 'target_position'):
        previous[name] = tuple(previous[name])
    created = []
    try:
        settings.camera = camera
        settings.camera_data = camera.data
        settings.base_location = location
        settings.base_lens = camera.data.lens
        settings.back_axis = axis
        settings.depth = depth
        settings.near_clip = camera.data.clip_start
        settings.lens_max = camera.data.bl_rna.properties['lens'].hard_max
        settings.target_position = target
        settings.target_name = settings.target.name if settings.target else '3Dカーソル'
        settings.token = uuid.uuid4().hex
        settings.ratio = 1.0
        settings.enabled = True
        settings.active = True
        for spec in _specs(scene):
            _install_driver(scene, spec, created)
        settings.status = '開始時の被写体の位置を基準に、距離と焦点距離を連動します'
        camera.update_tag()
        camera.data.update_tag()
        scene.update_tag()
    except Exception:
        for owner, curve in reversed(created):
            owner.animation_data.drivers.remove(curve)
        camera.location = location
        camera.data.lens = settings.base_lens
        for name, value in previous.items():
            setattr(settings, name, value)
        camera.update_tag()
        camera.data.update_tag()
        scene.update_tag()
        raise
    return camera


def restore(scene):
    """Restore only unchanged owned channels; preserve edits and explain them."""
    settings = scene.gyogan_dolly
    if not settings.active:
        return []
    warnings = []
    if settings.camera is None:
        warnings.append('元のカメラが削除されています')
    elif settings.camera.data != settings.camera_data:
        warnings.append('カメラデータの差し替えを保持しました')
    for owner, path, index, variables, expression in _specs(scene):
        curve = _find_curve(owner, path, index)
        if not _owned(curve, scene, variables, expression):
            label = (f'カメラ位置{"XYZ"[index]}' if path == 'location'
                     else '焦点距離' if path == 'lens' else '魚眼の補正')
            warnings.append(f'{label}の変更を保持しました（管理ドライバーが変更または削除されています）')
            continue
        owner.animation_data.drivers.remove(curve)
        if path == 'location':
            owner.location[index] = settings.base_location[index]
        elif path == 'lens':
            owner.lens = settings.base_lens
        owner.update_tag()
    settings.active = False
    settings.status = '／'.join(warnings) if warnings else '開始前のカメラ位置・焦点距離に戻しました'
    # Keep snapshots and ratio animation: actions belong to the user.
    scene.update_tag()
    return warnings


class GYOGAN_DollySettings(PropertyGroup):
    active: BoolProperty(default=False, options=set())
    camera: PointerProperty(type=bpy.types.Object, options=set())
    camera_data: PointerProperty(type=bpy.types.Camera, options=set())
    target: PointerProperty(name='基準の被写体', type=bpy.types.Object,
                            description='開始時の原点位置を使用します。未指定の場合は3Dカーソルの位置を使用します。開始後の移動には追従しません',
                            options=set())
    ratio: FloatProperty(name='ドリー倍率', default=1., min=.1, max=5.,
                         soft_min=.1, soft_max=5., precision=3,
                         description='1で開始時。小さくするとカメラが近づき広角、大きくすると離れて望遠になります。キーフレームを設定できます')
    enabled: BoolProperty(name='ドリーズーム', default=True, options=set(),
                          description='オフで開始時のカメラ位置と焦点距離に戻します。倍率とキーフレームは保持します')
    compensate_fisheye: BoolProperty(name='魚眼の大きさも補正', default=True,
                                     options=set(),
                                     description='魚眼による焦点距離の打ち消しを補正します。魚眼の強い周辺まで大きさが一致するとは限りません')
    factor: FloatProperty(default=1., get=_factor, options={'HIDDEN'})
    base_location: FloatVectorProperty(size=3, options={'HIDDEN'})
    base_lens: FloatProperty(default=50., options={'HIDDEN'})
    depth: FloatProperty(default=1., options={'HIDDEN'})
    back_axis: FloatVectorProperty(size=3, default=(0., 0., 1.), options={'HIDDEN'})
    near_clip: FloatProperty(default=.1, options={'HIDDEN'})
    lens_max: FloatProperty(default=5000., options={'HIDDEN'})
    target_position: FloatVectorProperty(size=3, options={'HIDDEN'})
    target_name: StringProperty(options={'HIDDEN'})
    token: StringProperty(options={'HIDDEN'})
    status: StringProperty(options=set())


class GYOGAN_OT_dolly_start(Operator):
    bl_idname = 'gyogan.dolly_start'
    bl_label = '基準を登録'
    bl_description = '現在の位置・焦点距離を保存して、ドリーズームを開始します'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            setup(context.scene)
        except Exception as exc:
            context.scene.gyogan_dolly.status = f'開始できません：{exc}'
            self.report({'ERROR'}, context.scene.gyogan_dolly.status)
            return {'CANCELLED'}
        self.report({'INFO'}, 'ドリーズームを開始しました。倍率を調整してください')
        return {'FINISHED'}


class GYOGAN_OT_dolly_restore(Operator):
    bl_idname = 'gyogan.dolly_restore'
    bl_label = '元のカメラへ戻す'
    bl_description = 'ドリーズームを取り外し、開始前の位置・焦点距離に戻します。倍率のアニメーションは保持します'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene.gyogan_dolly.active

    def execute(self, context):
        warnings = restore(context.scene)
        self.report({'WARNING'} if warnings else {'INFO'}, context.scene.gyogan_dolly.status)
        return {'FINISHED'}


def draw(layout, context):
    settings = context.scene.gyogan_dolly
    box = layout.box()
    box.label(text='ドリーズーム', icon='CAMERA_DATA')
    if settings.active:
        box.prop(settings, 'enabled', toggle=True,
                 text='ドリーズーム：オン' if settings.enabled else 'ドリーズーム：オフ')
        controls = box.column()
        controls.enabled = settings.enabled
        controls.prop(settings, 'ratio', slider=True)
        controls.prop(settings, 'compensate_fisheye')
        if settings.enabled and abs(effective_ratio(settings) - settings.ratio) > 1e-5:
            box.label(text=f'カメラの限界で実際の倍率：{effective_ratio(settings):.3f}', icon='INFO')
        box.label(text=f'開始時の基準：{settings.target_name}')
        box.label(text='小さく：近づいて広角')
        box.label(text='大きく：離れて望遠')
        box.operator('gyogan.dolly_restore', icon='LOOP_BACK')
    else:
        box.prop(settings, 'target')
        if settings.target is None:
            box.label(text='未指定：3Dカーソルの位置を使用', icon='PIVOT_CURSOR')
        box.prop(settings, 'compensate_fisheye')
        box.operator('gyogan.dolly_start', icon='PLAY')
    for line in textwrap.wrap(settings.status, width=26):
        box.label(text=line)


CLASSES = (GYOGAN_DollySettings, GYOGAN_OT_dolly_start, GYOGAN_OT_dolly_restore)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.gyogan_dolly = PointerProperty(type=GYOGAN_DollySettings)


def unregister():
    for scene in bpy.data.scenes:
        if hasattr(scene, 'gyogan_dolly'):
            warnings = restore(scene)
            for warning in warnings:
                print('ドリーズームの復元：' + warning)
    del bpy.types.Scene.gyogan_dolly
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
