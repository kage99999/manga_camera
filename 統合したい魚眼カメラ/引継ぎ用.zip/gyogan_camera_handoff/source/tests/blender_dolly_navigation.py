"""Camera-lock navigation regressions in an isolated Blender 5.2 process.

Real orbit/zoom operators are compared with an ordinary camera. Background
Blender does not execute view_pan; its matrix translation path is exercised
separately and that limitation is included in the report.
"""

import importlib.util
import json
import math
import sys
import traceback
from pathlib import Path

import bpy
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Matrix, Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
from test_paths import output_path
REPORT = output_path('dolly_navigation_result.json')
FIXTURE = output_path('dolly_navigation_fixture.blend')
sys.dont_write_bytecode = True
from blender_center import addon, refresh


def matrix_error(first, second):
    return max(abs(first[row][column] - second[row][column])
               for row in range(4) for column in range(4))


def pose(scene, camera):
    return camera.evaluated_get(refresh(scene)).matrix_world.copy()


def run():
    if not bpy.app.background:
        raise RuntimeError('カメラ操作の検証は専用のバックグラウンドプロセスで実行してください')
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if not hasattr(bpy.types.Scene, 'gyogan'):
        addon.register()
    checks, limitations, exception = [], [], None

    def check(name, condition, **details):
        checks.append(dict(test=name, passed=bool(condition), **details))

    def same_pose(name, scene, camera, expected, tolerance=2.e-4):
        difference = matrix_error(pose(scene, camera), expected)
        check(name, difference < tolerance, max_error=difference)

    def settle(scene, count=4):
        for _ in range(count):
            refresh(scene)

    def scale_at_target(scene, camera):
        matrix = pose(scene, camera)
        right = matrix.to_3x3().col[0].normalized()
        target = Vector(scene.gyogan_dolly.target_position)
        points = [world_to_camera_view(scene, camera, target + right * sign * .25)
                  for sign in (-1., 1.)]
        return abs(points[1].x - points[0].x)

    def assert_scale(name, scene, camera, depth, projected_scale):
        control = scene.gyogan_dolly
        matrix = pose(scene, camera)
        axis = matrix.to_3x3().col[2].normalized()
        projected = (matrix.translation - Vector(control.target_position)).dot(axis)
        check(name + '_keeps_ratio_one_depth', abs(control.depth - depth) < 2.e-5)
        check(name + '_ratio_tracks_target_depth',
              abs(addon.dolly.effective_ratio(control) - projected / depth) < 3.e-5)
        check(name + '_keeps_lens_over_depth',
              math.isclose(camera.data.lens / projected, control.base_lens / depth,
                           rel_tol=3.e-6, abs_tol=3.e-5),
              actual=camera.data.lens / projected, expected=control.base_lens / depth)
        actual_scale = scale_at_target(scene, camera)
        check(name + '_keeps_projected_target_plane_size',
              math.isclose(actual_scale, projected_scale, rel_tol=3.e-6, abs_tol=3.e-5),
              actual=actual_scale, expected=projected_scale)

    def move_world(name, scene, camera, matrix, fallback=False):
        lens = camera.data.lens
        control = scene.gyogan_dolly
        ratio, depth = control.ratio, control.depth
        projected_scale = scale_at_target(scene, camera)
        camera.matrix_world = matrix
        same_pose(name + '_no_jump', scene, camera, matrix)
        settle(scene)
        same_pose(name + '_no_drift', scene, camera, matrix)
        if control.enabled and not fallback:
            assert_scale(name, scene, camera, depth, projected_scale)
        else:
            check(name + '_keeps_lens_and_ratio', abs(camera.data.lens - lens) < 1.e-4
                  and control.ratio == ratio)

    try:
        scene = bpy.context.scene
        scene.name = 'ドリーズーム・カメラ操作検証'
        control = scene.gyogan_dolly
        camera = bpy.data.objects.new('カメラ操作検証・カメラ', bpy.data.cameras.new('カメラ操作検証・データ'))
        scene.collection.objects.link(camera)
        camera.location = (0., -10., 2.)
        camera.rotation_euler = (math.pi / 2., 0., 0.)
        camera.data.lens = 28.
        camera.data.clip_start = .1
        scene.camera = scene.gyogan.camera = camera
        scene.cursor.location = (0., 0., 2.)
        original_matrix = pose(scene, camera)
        original_lens = camera.data.lens
        camera['navigation_test_identity'] = 'original_camera'
        addon.dolly.setup(scene)
        control.ratio = 2.
        settle(scene)
        check('location_channels_remain_free', all(curve.data_path != 'location'
              for curve in camera.animation_data.drivers))
        check('three_owned_delta_channels_drive_dolly', sum(curve.data_path == 'delta_location'
              for curve in camera.animation_data.drivers) == 3)
        check('navigation_schema_is_saved', control.navigation_version >= 1)

        ordinary = bpy.data.objects.new('カメラ操作検証・比較用カメラ', camera.data.copy())
        scene.collection.objects.link(ordinary)
        ordinary.data.animation_data_clear()
        area = next(area for area in bpy.context.screen.areas if area.type == 'VIEW_3D')
        region = next(region for region in area.regions if region.type == 'WINDOW')
        space = area.spaces.active
        bpy.context.preferences.view.smooth_view = 0
        # Blender 5.1's camera-lock orbit pushes grouped undo entries even in
        # background mode. A factory-startup background process has no initial
        # undo stack; initialize it before exercising the real view operators.
        bpy.ops.ed.undo_push(message='カメラ操作検証の初期状態')

        def configure_view(selected, matrix):
            space.use_local_camera = True
            space.camera = selected
            space.lock_camera = True
            rv3d = space.region_3d
            rv3d.view_location = Vector(control.target_position)
            rv3d.view_distance = 10.
            rv3d.view_rotation = matrix.to_quaternion()
            rv3d.view_camera_zoom = 0.
            rv3d.view_camera_offset = (0., 0.)
            rv3d.view_perspective = 'CAMERA'
            refresh(scene)

        for label, operator, arguments in (
                ('orbit_up', bpy.ops.view3d.view_orbit, {'type': 'ORBITUP'}),
                ('orbit_right', bpy.ops.view3d.view_orbit, {'type': 'ORBITRIGHT'}),
                ('zoom_in', bpy.ops.view3d.zoom, {'delta': 1}),
                ('zoom_out', bpy.ops.view3d.zoom, {'delta': -1})):
            before = pose(scene, camera)
            lens, ratio = camera.data.lens, control.ratio
            depth, projected_scale = control.depth, scale_at_target(scene, camera)
            ordinary.matrix_world = before
            ordinary.data.lens = lens
            configure_view(ordinary, before)
            with bpy.context.temp_override(area=area, region=region):
                ordinary_result = operator(**arguments)
            expected = pose(scene, ordinary)
            configure_view(camera, before)
            with bpy.context.temp_override(area=area, region=region):
                managed_result = operator(**arguments)
            check(label + '_real_operators_complete', ordinary_result == {'FINISHED'}
                  and managed_result == {'FINISHED'}, ordinary=list(ordinary_result), managed=list(managed_result))
            check(label + '_ordinary_camera_actually_moves', matrix_error(before, expected) > 1.e-3)
            same_pose(label + '_matches_ordinary_camera', scene, camera, expected)
            settle(scene)
            same_pose(label + '_does_not_snap_back', scene, camera, expected)
            assert_scale(label, scene, camera, depth, projected_scale)
            if label.startswith('zoom_'):
                check(label + '_changes_ratio_and_lens', abs(control.ratio - ratio) > 1.e-4
                      and abs(camera.data.lens - lens) > 1.e-4)

        with bpy.context.temp_override(area=area, region=region):
            pan_result = bpy.ops.view3d.view_pan(type='PANRIGHT')
        if pan_result == {'PASS_THROUGH'}:
            limitations.append('バックグラウンドの view_pan は PASS_THROUGH。水平・垂直移動はカメラ行列の変更で検証。')
        else:
            check('real_pan_operator_completes_when_supported', pan_result == {'FINISHED'}, result=list(pan_result))
        for label, column, distance in (('pan_right', 0, 2.),
                                        ('pan_up', 1, 1.),
                                        ('manual_forward', 2, -1.)):
            changed = pose(scene, camera)
            before_base, before_ratio = Vector(control.base_location), control.ratio
            changed.translation += changed.to_3x3().col[column].normalized() * distance
            move_world(label, scene, camera, changed)
            if column != 2:
                check(label + '_does_not_change_ratio', abs(control.ratio - before_ratio) < 2.e-5)
            else:
                check(label + '_is_equivalent_to_ratio_edit',
                      abs(control.ratio - (before_ratio + distance / control.depth)) < 2.e-5
                      and (Vector(control.base_location) - before_base).length < 2.e-4)

        reframed_pose = pose(scene, camera)
        base, axis, depth = Vector(control.base_location), Vector(control.back_axis), control.depth
        reframed_rotation = reframed_pose.to_quaternion()
        reframed_ratio = control.ratio
        check('reframed_axis_follows_camera_rotation',
              (axis - reframed_pose.to_3x3().col[2].normalized()).length < 2.e-5)
        check('reframed_depth_uses_target_and_current_ratio',
              abs(depth * reframed_ratio - (reframed_pose.translation - Vector(control.target_position)).dot(axis)) < 2.e-4)
        control.ratio = .5
        current = pose(scene, camera)
        check('changed_ratio_uses_new_framing_axis',
              (current.translation - (base + axis * depth * (.5 - 1.))).length < 2.e-4
              and current.to_quaternion().rotation_difference(reframed_rotation).angle < 2.e-4)
        check('ratio_change_does_not_rebase_framing',
              (Vector(control.base_location) - base).length < 1.e-6 and abs(control.depth - depth) < 1.e-6)
        control.enabled = False
        off = pose(scene, camera)
        check('off_uses_current_framing_at_ratio_one', (off.translation - base).length < 2.e-4
              and abs(camera.data.lens - original_lens) < 1.e-4)
        control.enabled = True
        same_pose('on_returns_to_current_dolly_pose', scene, camera, current)
        control.ratio = reframed_ratio
        same_pose('ratio_round_trip_keeps_reframed_pose', scene, camera, reframed_pose)

        control.enabled = False
        off_navigation = pose(scene, camera)
        off_navigation.translation += Vector((.5, 0., .25))
        move_world('navigation_while_off', scene, camera, off_navigation)
        check('off_navigation_becomes_new_ratio_one_base',
              (Vector(control.base_location) - off_navigation.translation).length < 2.e-4)
        control.enabled = True
        reframed_pose = pose(scene, camera)
        check('reenable_after_off_navigation_uses_new_base',
              (reframed_pose.translation - (Vector(control.base_location)
                                           + Vector(control.back_axis) * control.depth * (reframed_ratio - 1.))).length < 2.e-4)

        away = pose(scene, camera)
        away = Matrix.Translation(away.translation) @ away.to_quaternion().to_matrix().to_4x4() @ Matrix.Rotation(math.pi, 4, 'Y')
        move_world('look_away_from_target', scene, camera, away, fallback=True)
        check('behind_target_keeps_positive_depth', control.depth > 0. and math.isfinite(control.depth))
        move_world('look_back_to_target', scene, camera, reframed_pose)

        for label, requested_ratio in (('upper_ratio_limit', 9.),
                                       ('lower_ratio_limit', .001),
                                       ('same_axis_crosses_target', -1.)):
            before = pose(scene, camera)
            axis = before.to_3x3().col[2].normalized()
            right = before.to_3x3().col[0].normalized()
            depth, projected_scale = control.depth, scale_at_target(scene, camera)
            requested = before.copy()
            requested.translation += (axis * depth * (requested_ratio - addon.dolly.effective_ratio(control))
                                      + right * .125)
            expected_ratio = min(max(requested_ratio, .1, 1. / control.base_lens,
                                     control.near_clip * 1.01 / depth),
                                 5., control.lens_max / control.base_lens)
            expected = requested.copy()
            expected.translation += axis * depth * (expected_ratio - requested_ratio)
            camera.matrix_world = requested
            same_pose(label + '_constrains_only_axial_position', scene, camera, expected)
            settle(scene)
            same_pose(label + '_does_not_drift', scene, camera, expected)
            check(label + '_sets_bounded_ratio', abs(control.ratio - expected_ratio) < 2.e-5,
                  actual_ratio=control.ratio, expected_ratio=expected_ratio)
            assert_scale(label, scene, camera, depth, projected_scale)
        move_world('return_from_navigation_limits', scene, camera, reframed_pose)

        rotation_before = pose(scene, camera)
        rotation_only = (Matrix.Translation(rotation_before.translation)
                         @ rotation_before.to_quaternion().to_matrix().to_4x4()
                         @ Matrix.Rotation(math.radians(7.), 4, 'Y'))
        before_ratio = control.ratio
        move_world('rotation_only_prioritizes_target_scale', scene, camera, rotation_only)
        check('rotation_only_changes_ratio_when_target_depth_changes', abs(control.ratio - before_ratio) > 1.e-4)
        move_world('rotation_only_return', scene, camera, rotation_before)
        base, axis, depth = Vector(control.base_location), Vector(control.back_axis), control.depth

        for frame, ratio in ((1, .5), (5, 1.), (9, 2.)):
            control.ratio = ratio
            control.keyframe_insert('ratio', frame=frame)
        scene.frame_set(5)
        animation = scene.animation_data
        curves = list(addon.dolly._action_curves(animation.action, animation.action_slot_handle))
        keyed_values = [(curve.data_path, tuple(tuple(key.co) for key in curve.keyframe_points))
                        for curve in curves]
        protected_pose = pose(scene, camera)
        protected_ratio, protected_lens = control.ratio, camera.data.lens
        requested = (Matrix.Translation(protected_pose.translation)
                     @ protected_pose.to_quaternion().to_matrix().to_4x4()
                     @ Matrix.Rotation(math.radians(5.), 4, 'X'))
        requested.translation += protected_pose.to_3x3().col[0].normalized() * .3
        requested.translation -= protected_pose.to_3x3().col[2].normalized() * 2.
        requested_axis = requested.to_3x3().col[2].normalized()
        expected = requested.copy()
        requested_depth = (requested.translation - Vector(control.target_position)).dot(requested_axis)
        expected.translation += requested_axis * (depth * protected_ratio - requested_depth)
        camera.matrix_world = requested
        same_pose('keyed_ratio_allows_pan_rotation_but_constrains_axial_move', scene, camera, expected)
        settle(scene)
        same_pose('keyed_ratio_navigation_does_not_drift', scene, camera, expected)
        check('keyed_ratio_navigation_keeps_value_and_keys', abs(control.ratio - protected_ratio) < 1.e-6
              and abs(camera.data.lens - protected_lens) < 1.e-4
              and keyed_values == [(curve.data_path, tuple(tuple(key.co) for key in curve.keyframe_points))
                                   for curve in curves])
        check('keyed_ratio_navigation_explains_protection', bool(control.status))
        base, axis, depth = Vector(control.base_location), Vector(control.back_axis), control.depth
        saved_poses = {}
        for frame in (9, 1, 5, 7, 9, 1):
            scene.frame_set(frame)
            current = pose(scene, camera)
            q = scene.evaluated_get(refresh(scene)).gyogan_dolly.ratio
            check('reframed_animation_frame_' + str(frame),
                  (current.translation - (base + axis * depth * (q - 1.))).length < 2.e-4
                  and abs(camera.data.lens - original_lens * q) < 2.e-4)
            saved_poses[frame] = current
        check('animated_ratio_never_mutates_framing', (Vector(control.base_location) - base).length < 1.e-6
              and abs(control.depth - depth) < 1.e-6)
        name = camera.name
        token = control.token
        bpy.ops.wm.save_as_mainfile(filepath=str(FIXTURE), check_existing=False)
        bpy.ops.wm.open_mainfile(filepath=str(FIXTURE))
        scene = bpy.context.scene
        control, camera = scene.gyogan_dolly, bpy.data.objects[name]
        check('save_reopen_retains_camera_and_ownership', control.camera == camera and control.token == token
              and camera['navigation_test_identity'] == 'original_camera')
        for frame in (7, 1, 9, 5):
            scene.frame_set(frame)
            same_pose('reopened_animation_frame_' + str(frame), scene, camera, saved_poses[frame])
        check('reopened_animation_keeps_original_snapshot',
              (Vector(control.original_location) - original_matrix.translation).length < 1.e-6)
        addon.dolly.restore(scene)
        same_pose('restore_after_navigation_and_save_recovers_start_pose', scene, camera, original_matrix)
        check('restore_after_navigation_recovers_lens_and_clears_delta',
              abs(camera.data.lens - original_lens) < 1.e-5 and camera.delta_location.length < 1.e-6)
        check('restore_keeps_user_ratio_animation', scene.animation_data is not None
              and scene.animation_data.action is not None)
        scene.animation_data_clear()

        lens_hard_max = camera.data.bl_rna.properties['lens'].hard_max
        for limit_name, start_lens, clip_start, requests in (
                ('physical_lens_minimum', 2., .1, (.1,)),
                ('physical_lens_maximum', lens_hard_max / 2., .1, (4.,)),
                ('physical_near_clip', original_lens, 3., (.01, -1.))):
            camera.data.lens = start_lens
            camera.data.clip_start = clip_start
            addon.dolly.setup(scene)
            depth, projected_scale = control.depth, scale_at_target(scene, camera)
            for attempt, requested_ratio in enumerate(requests):
                before = pose(scene, camera)
                axis = before.to_3x3().col[2].normalized()
                right = before.to_3x3().col[0].normalized()
                effective_before = addon.dolly.effective_ratio(control)
                requested = before.copy()
                requested.translation += (axis * depth * (requested_ratio - effective_before)
                                          + right * .1)
                expected_ratio = min(max(requested_ratio, .1, 1. / start_lens,
                                         clip_start * 1.01 / depth),
                                     5., lens_hard_max / start_lens)
                expected = requested.copy()
                expected.translation += axis * depth * (expected_ratio - requested_ratio)
                camera.matrix_world = requested
                label = limit_name + '_attempt_' + str(attempt + 1)
                same_pose(label + '_constrains_axial_position', scene, camera, expected)
                settle(scene)
                same_pose(label + '_does_not_drift', scene, camera, expected)
                check(label + '_uses_physical_effective_bound',
                      abs(addon.dolly.effective_ratio(control) - expected_ratio) < 2.e-5,
                      actual_effective_ratio=addon.dolly.effective_ratio(control), expected_ratio=expected_ratio)
                assert_scale(label, scene, camera, depth, projected_scale)
            addon.dolly.restore(scene)
            same_pose(limit_name + '_restore_recovers_original_position', scene, camera, original_matrix)
            check(limit_name + '_restore_recovers_initial_lens', abs(camera.data.lens - start_lens) < 1.e-4)
            camera.data.lens = original_lens
            camera.data.clip_start = .1

        for animation_kind in ('driver', 'nla'):
            addon.dolly.setup(scene)
            if animation_kind == 'driver':
                external = scene.driver_add('gyogan_dolly.ratio')
                external.driver.expression = '1.5'
                driver_pointer = external.as_pointer()
            else:
                for frame in (1, 9):
                    control.ratio = 1.5
                    control.keyframe_insert('ratio', frame=frame)
                animation = scene.animation_data
                action = animation.action
                slot = animation.action_slot
                keyed_values = [(curve.data_path, tuple(tuple(key.co) for key in curve.keyframe_points))
                                for curve in addon.dolly._action_curves(action, slot.handle)]
                animation.action = None
                track = animation.nla_tracks.new()
                strip = track.strips.new('ドリー倍率の保護検証', 1, action)
                strip.action_slot = slot
            scene.frame_set(5)
            before = pose(scene, camera)
            current_ratio = addon.dolly.effective_ratio(control)
            depth, projected_scale = control.depth, scale_at_target(scene, camera)
            check(animation_kind + '_fixture_controls_ratio', abs(current_ratio - 1.5) < 1.e-5)
            requested = (Matrix.Translation(before.translation)
                         @ before.to_quaternion().to_matrix().to_4x4()
                         @ Matrix.Rotation(math.radians(4.), 4, 'Y'))
            requested.translation += before.to_3x3().col[0].normalized() * .4
            requested.translation -= before.to_3x3().col[2].normalized() * 2.
            requested_axis = requested.to_3x3().col[2].normalized()
            expected = requested.copy()
            requested_depth = (requested.translation - Vector(control.target_position)).dot(requested_axis)
            expected.translation += requested_axis * (depth * current_ratio - requested_depth)
            camera.matrix_world = requested
            same_pose(animation_kind + '_navigation_preserves_pan_rotation_with_locked_depth', scene, camera, expected)
            settle(scene)
            same_pose(animation_kind + '_navigation_does_not_drift', scene, camera, expected)
            assert_scale(animation_kind + '_navigation', scene, camera, depth, projected_scale)
            if animation_kind == 'driver':
                authored_preserved = any(curve.as_pointer() == driver_pointer
                                        and curve.driver.expression == '1.5'
                                        for curve in scene.animation_data.drivers)
            else:
                authored_preserved = (strip.action == action and strip.action_slot == slot
                    and keyed_values == [(curve.data_path, tuple(tuple(key.co) for key in curve.keyframe_points))
                                         for curve in addon.dolly._action_curves(action, slot.handle)])
            check(animation_kind + '_navigation_preserves_authored_control', authored_preserved
                  and control.active and abs(control.ratio - current_ratio) < 1.e-5)
            addon.dolly.restore(scene)
            same_pose(animation_kind + '_restore_recovers_original_camera', scene, camera, original_matrix)
            scene.animation_data_clear()

        # Exercise real undo/redo when this background build exposes the stack;
        # otherwise record that limitation instead of counting a vacuous pass.
        addon.dolly.setup(scene)
        control.ratio = 2.
        before_undo_navigation = pose(scene, camera)
        bpy.context.preferences.edit.use_global_undo = True
        bpy.ops.ed.undo_push(message='ドリー構図変更前')
        after_undo_navigation = before_undo_navigation.copy()
        after_undo_navigation.translation += Vector((1.5, 0., .75))
        move_world('undo_fixture_navigation', scene, camera, after_undo_navigation)
        bpy.ops.ed.undo_push(message='ドリー構図変更後')
        if bpy.ops.ed.undo.poll():
            result = bpy.ops.ed.undo()
            scene = bpy.context.scene
            control, camera = scene.gyogan_dolly, bpy.data.objects[name]
            check('undo_operator_completes', result == {'FINISHED'})
            same_pose('undo_recovers_previous_framing', scene, camera, before_undo_navigation)
            settle(scene)
            same_pose('undo_is_not_rebased_to_newer_runtime_cache', scene, camera, before_undo_navigation)
            result = bpy.ops.ed.redo()
            scene = bpy.context.scene
            control, camera = scene.gyogan_dolly, bpy.data.objects[name]
            check('redo_operator_completes', result == {'FINISHED'})
            same_pose('redo_recovers_new_framing', scene, camera, after_undo_navigation)
            settle(scene)
            same_pose('redo_does_not_drift', scene, camera, after_undo_navigation)
        else:
            limitations.append('バックグラウンドの undo は実行不可。保存・再読込で状態復帰を検証。')
        addon.dolly.restore(scene)
        same_pose('restore_after_history_recovers_original_camera', scene, camera, original_matrix)

        # Run the frozen 0.1.9 implementation from its released ZIP, then migrate
        # the actual legacy graph while retaining the same camera/data IDs.
        spec = importlib.util.spec_from_file_location(
            'gyogan_legacy_v019_dolly', ROOT / 'tests' / 'fixtures' / 'legacy_v019_dolly.py')
        legacy = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(legacy)
        control.navigation_version = 0
        legacy.setup(scene)
        control.ratio = 2.
        settle(scene)
        legacy_pose = pose(scene, camera)
        camera_pointer, data_pointer = camera.as_pointer(), camera.data.as_pointer()
        check('legacy_fixture_really_has_old_location_drivers',
              sum(curve.data_path == 'location' for curve in camera.animation_data.drivers) == 3)
        addon.dolly.upgrade_saved(scene)
        same_pose('legacy_active_upgrade_preserves_current_pose', scene, camera, legacy_pose)
        check('legacy_upgrade_preserves_camera_ids', camera.as_pointer() == camera_pointer
              and camera.data.as_pointer() == data_pointer and control.camera == camera)
        check('legacy_upgrade_frees_location_channels', control.navigation_version >= 1
              and all(curve.data_path != 'location' for curve in camera.animation_data.drivers))
        pointers = [curve.as_pointer() for curve in camera.animation_data.drivers]
        addon.dolly.upgrade_saved(scene)
        check('legacy_upgrade_is_idempotent', pointers == [curve.as_pointer() for curve in camera.animation_data.drivers])
        control.ratio = 1.
        same_pose('legacy_upgrade_ratio_one_preserves_original_base', scene, camera, original_matrix)
        addon.dolly.restore(scene)
        same_pose('legacy_upgrade_restores_original_camera', scene, camera, original_matrix)

        control.navigation_version = 0
        legacy.setup(scene)
        for frame, ratio in ((1, .5), (9, 2.)):
            control.ratio = ratio
            control.keyframe_insert('ratio', frame=frame)
        scene.frame_set(9)
        legacy_saved_pose = pose(scene, camera)
        token = control.token
        bpy.ops.wm.save_as_mainfile(filepath=str(FIXTURE), check_existing=False)
        bpy.ops.wm.open_mainfile(filepath=str(FIXTURE))
        scene = bpy.context.scene
        control, camera = scene.gyogan_dolly, bpy.data.objects[name]
        check('legacy_saved_file_migrates_automatically', control.navigation_version >= 1
              and control.token == token and control.camera == camera)
        same_pose('legacy_saved_migration_keeps_current_animated_pose', scene, camera, legacy_saved_pose)
        scene.frame_set(1)
        first_frame = original_matrix.copy()
        first_frame.translation = Vector((0., -5., 2.))
        same_pose('legacy_saved_migration_retains_ratio_animation', scene, camera, first_frame)
        addon.dolly.restore(scene)
        same_pose('legacy_saved_migration_restores_original_pose', scene, camera, original_matrix)
        scene.animation_data_clear()

        control.navigation_version = 0
        legacy.setup(scene)
        changed = next(curve for curve in camera.animation_data.drivers
                       if curve.data_path == 'location' and curve.array_index == 0)
        changed.driver.expression = '7.0'
        original_drivers = [(curve.as_pointer(), curve.driver.expression)
                            for curve in camera.animation_data.drivers]
        addon.dolly.upgrade_saved(scene)
        check('legacy_edited_driver_prevents_migration', control.navigation_version == 0
              and original_drivers == [(curve.as_pointer(), curve.driver.expression)
                                       for curve in camera.animation_data.drivers])
        addon.dolly.restore(scene)
        check('legacy_restore_preserves_edited_user_driver',
              any(curve.data_path == 'location' and curve.driver.expression == '7.0'
                  for curve in camera.animation_data.drivers))
        camera.driver_remove('location', 0)
        camera.matrix_world = original_matrix
        camera.data.lens = original_lens
        settle(scene)

        for conflict in ('location_driver', 'location_action', 'constraint', 'parent', 'shared_data'):
            addon.dolly.setup(scene)
            control.ratio = 2.
            settle(scene)
            helper = None
            if conflict == 'location_driver':
                external = camera.driver_add('location', 0)
                external.driver.expression = '3.0'
                external_pointer = external.as_pointer()
            elif conflict == 'location_action':
                camera.keyframe_insert('location', frame=1)
                action = camera.animation_data.action
            elif conflict == 'constraint':
                external = camera.constraints.new('LIMIT_LOCATION')
                external.use_min_x = True
                external.min_x = 3.
                external_pointer = external.as_pointer()
            elif conflict == 'parent':
                helper = bpy.data.objects.new('カメラ操作検証・後付けの親', None)
                scene.collection.objects.link(helper)
                camera.parent = helper
            else:
                helper = bpy.data.objects.new('カメラ操作検証・後付けの共有', camera.data)
                scene.collection.objects.link(helper)
            addon.dolly.update_navigation(scene)
            settle(scene)
            if conflict == 'location_driver':
                preserved = next((curve for curve in camera.animation_data.drivers
                                  if curve.data_path == 'location' and curve.array_index == 0), None)
                kept = preserved is not None and preserved.as_pointer() == external_pointer and preserved.driver.expression == '3.0'
            elif conflict == 'location_action':
                kept = camera.animation_data.action == action
            elif conflict == 'constraint':
                kept = any(item.as_pointer() == external_pointer for item in camera.constraints)
            elif conflict == 'parent':
                kept = camera.parent == helper
            else:
                kept = helper.data == camera.data
            check('late_' + conflict + '_is_preserved', kept)
            check('late_' + conflict + '_stops_owned_control', not control.active and bool(control.status)
                  and all(curve.data_path != 'delta_location' for curve in camera.animation_data.drivers)
                  and not camera.data.animation_data.drivers)
            addon.dolly.restore(scene)
            if conflict == 'location_driver':
                camera.driver_remove('location', 0)
            elif conflict == 'location_action':
                camera.animation_data.action = None
            elif conflict == 'constraint':
                camera.constraints.remove(external)
            elif conflict == 'parent':
                camera.parent = None
            if helper:
                bpy.data.objects.remove(helper, do_unlink=True)
            camera.delta_location = (0., 0., 0.)
            camera.matrix_world = original_matrix
            camera.data.lens = original_lens
            settle(scene)

        addon.dolly.setup(scene)
        control.ratio = 2.
        settle(scene)
        moved = pose(scene, camera)
        moved.translation += Vector((1., 0., 1.))
        move_world('final_navigation', scene, camera, moved)
        addon.unregister()
        same_pose('unregister_restores_start_camera_after_navigation', scene, camera, original_matrix)
        check('unregister_removes_unchanged_owned_drivers', not camera.animation_data or not camera.animation_data.drivers)
    except Exception:
        exception = traceback.format_exc()
        print(exception)
    finally:
        passed = bool(checks) and all(item['passed'] for item in checks) and exception is None
        report = dict(blender=bpy.app.version_string, passed=passed, checks=checks,
                      limitations=limitations, exception=exception)
        REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        print('GYOGAN_DOLLY_NAVIGATION_RESULTS=' + json.dumps(report, ensure_ascii=False))
    if not passed:
        raise AssertionError('カメラ操作の検証に失敗しました: ' + str(REPORT))


if __name__ == '__main__':
    run()
