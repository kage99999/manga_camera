"""Run all integration suites in isolated background Blender processes.

Host Python example:
  python tests/run_compatibility.py --blender "C:/.../Blender 5.2/blender.exe" \
      --blender "C:/.../Blender 5.1/blender.exe"

Each invocation, executable and suite has a separate output directory. The
normal tests/*_result.json files and user Blender sessions are never changed.
"""

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import uuid


ROOT = Path(__file__).resolve().parents[1]
SUITES = ('smoke', 'persistence', 'center', 'negative', 'ellipse', 'dolly',
          'dolly_navigation', 'camera_switch', 'bone_compat', 'framing', 'targets', 'subdivision', 'presets', 'cursor', 'helpers')
LOG_ERRORS = re.compile(
    r'Dependency (?:graph )?cycle|ID user decrement|ID user count error|'
    r'ID reference count error|Traceback \(most recent call last\)', re.IGNORECASE)


def relative(path):
    return Path(path).resolve().relative_to(ROOT).as_posix()


def process_options():
    # Background test runs must not create a console window on Windows.
    return {'creationflags': subprocess.CREATE_NO_WINDOW} if os.name == 'nt' else {}


def inspect_report(path, log, expected_version):
    """Do not trust an exit code or top-level passed flag alone."""
    errors = []
    report = {}
    try:
        report = json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(report, dict):
            raise ValueError('結果JSONがオブジェクトではありません')
    except (OSError, ValueError) as exc:
        errors.append('結果JSONを読めません: ' + str(exc))
        report = {}
    checks = report.get('checks')
    if not isinstance(checks, list) or not checks:
        errors.append('検証項目がありません')
        checks = []
    failed = [item.get('test', '(無名)') if isinstance(item, dict) else '(不正な項目)'
              for item in checks if not isinstance(item, dict) or item.get('passed') is not True]
    if report.get('passed') is not True:
        errors.append('結果JSONの成功状態がtrueではありません')
    if failed:
        errors.append('失敗した検証: ' + ', '.join(str(name) for name in failed))
    if report.get('exception'):
        errors.append('検証中に例外が発生しました: ' + str(report['exception']))
    reported_version = str(report.get('blender', ''))
    if not reported_version or not reported_version.startswith(expected_version):
        errors.append('結果JSONのBlenderバージョンが実行ファイルと一致しません')
    log_errors = list(dict.fromkeys(line.strip() for line in log.splitlines() if LOG_ERRORS.search(line)))
    if log_errors:
        errors.append('Blenderログに例外・循環依存・ID参照数エラーがあります')
    return {'blender': reported_version, 'check_count': len(checks),
            'failed_checks': failed, 'errors': errors, 'log_errors': log_errors}


def blender_info(executable):
    completed = subprocess.run([str(executable), '--version'], capture_output=True,
                               text=True, encoding='utf-8', errors='replace',
                               timeout=30, **process_options())
    match = re.search(r'^Blender (\d+\.\d+\.\d+[^\r\n]*)', completed.stdout, re.MULTILINE)
    if completed.returncode or not match:
        raise RuntimeError('Blenderのバージョンを確認できません: ' + completed.stderr.strip())
    label = match.group(1)
    version = re.match(r'\d+\.\d+\.\d+', label).group(0)
    return {'executable': str(executable), 'version': version, 'label': label}


def run_suite(info, suite, run_directory, timeout):
    executable = info['executable']
    binary_id = hashlib.sha256(os.path.normcase(executable).encode('utf-8')).hexdigest()[:8]
    directory = run_directory / (info['version'] + '-' + binary_id) / suite
    directory.mkdir(parents=True, exist_ok=True)
    log_path = directory / 'blender.log'
    report_path = directory / (suite + '_result.json')
    command = [executable, '--background', '--factory-startup', '--python-exit-code', '1',
               '--python', str(ROOT / 'tests' / ('blender_' + suite + '.py'))]
    environment = os.environ.copy()
    environment['GYOGAN_TEST_OUTPUT_DIR'] = str(directory)
    environment['PYTHONIOENCODING'] = 'utf-8'
    for suffix in ('RESOURCES', 'CONFIG', 'EXTENSIONS', 'SCRIPTS', 'DATAFILES'):
        folder = directory / suffix.lower()
        folder.mkdir(exist_ok=True)
        environment['BLENDER_USER_' + suffix] = str(folder)
    start = time.monotonic()
    process_error = None
    returncode = None
    with log_path.open('wb') as output:
        try:
            completed = subprocess.run(command, cwd=str(ROOT), env=environment,
                                       stdout=output, stderr=subprocess.STDOUT,
                                       timeout=timeout, **process_options())
            returncode = completed.returncode
        except (OSError, subprocess.TimeoutExpired) as exc:
            process_error = str(exc)
    log = log_path.read_text(encoding='utf-8', errors='replace')
    result = inspect_report(report_path, log, info['version'])
    if process_error:
        result['errors'].insert(0, 'プロセスを完了できません: ' + process_error)
    elif returncode != 0:
        result['errors'].insert(0, 'プロセス終了コード: ' + str(returncode))
    result.update(suite=suite, passed=not result['errors'], exit_code=returncode,
                  seconds=round(time.monotonic() - start, 3),
                  report=relative(report_path), log=relative(log_path))
    return result


def main():
    parser = argparse.ArgumentParser(description='複数のBlenderで15種類の回帰検証を実行します。')
    parser.add_argument('--blender', type=Path, action='append', required=True,
                        help='Blenderの実行ファイル。複数指定できます。')
    parser.add_argument('--jobs', type=int, default=4, help='同時実行数（既定: 4）')
    parser.add_argument('--timeout', type=float, default=300,
                        help='各検証の制限秒数（既定: 300）')
    args = parser.parse_args()
    if args.jobs < 1 or args.timeout <= 0:
        parser.error('--jobsと--timeoutには正の値を指定してください')
    executables = list(dict.fromkeys(path.expanduser().resolve() for path in args.blender))
    for executable in executables:
        if not executable.is_file():
            parser.error('実行ファイルが見つかりません: ' + str(executable))

    started = datetime.now(timezone.utc)
    run_directory = ROOT / 'tests' / '.compat' / (started.strftime('%Y%m%dT%H%M%SZ-') + uuid.uuid4().hex[:8])
    versions = []
    for executable in executables:
        try:
            info = blender_info(executable)
            info.update(passed=False, suites=[], errors=[])
        except (OSError, RuntimeError, subprocess.TimeoutExpired) as exc:
            info = {'executable': str(executable), 'passed': False, 'suites': [], 'errors': [str(exc)]}
        versions.append(info)

    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        futures = {pool.submit(run_suite, info, suite, run_directory, args.timeout): (info, suite)
                   for info in versions if not info['errors'] for suite in SUITES}
        for future in as_completed(futures):
            info, suite = futures[future]
            try:
                result = future.result()
            except Exception as exc:
                result = {'suite': suite, 'passed': False, 'check_count': 0, 'errors': [repr(exc)]}
            info['suites'].append(result)
            print('{} {}: {} ({} checks)'.format(info['label'], suite,
                  'PASS' if result['passed'] else 'FAIL', result['check_count']), flush=True)

    for info in versions:
        info['suites'].sort(key=lambda item: SUITES.index(item['suite']))
        info['check_count'] = sum(item['check_count'] for item in info['suites'])
        info['passed'] = (not info['errors'] and len(info['suites']) == len(SUITES)
                          and all(item['passed'] for item in info['suites']))
    summary = {'started_utc': started.isoformat(), 'completed_utc': datetime.now(timezone.utc).isoformat(),
               'passed': all(info['passed'] for info in versions), 'suites': list(SUITES),
               'versions': versions}
    summary_path = ROOT / 'tests' / 'compatibility_result.json'
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('Compatibility results: ' + str(summary_path), flush=True)
    return 0 if summary['passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
