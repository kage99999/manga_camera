"""Active-camera switching regressions in an isolated Blender 5.2 process.

Only small numeric meshes and two test bones are created. This script never
loads or changes the user's working file or character assets.
"""

import json
import math
import sys
import traceback
from pathlib import Path

import bpy
from mathutils import Matrix, Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
from test_paths import output_path
REPORT = output_path('camera_switch_result.json')
FIXTURE = output_path('camera_switch_fixture.blend')
sys.dont_write_bytecode = True
from blender_center import addon, bone_points, error, make_mesh, make_rig, positions, refresh


def settle(scene):
    for _ in range(4):
        refresh(scene)


def make_camera(scene, name, location, lens=28., rotation=(math.pi / 2., 0., 0.)):
    camera = bpy.data.objects.new(name, bpy.data.cameras.new(name + '・データ'))
    scene.collection.objects.link(camera)
    camera.location, camera.rotation_euler, camera.data.lens = location, rotation, lens
    return camera


def oracle(scene, points):
    settings = scene.gyogan
    graph = refresh(scene)
    camera = scene.camera.evaluated_get(graph)
    matrix = camera.matrix_world.normalized()
    inverse = matrix.inverted()
    frame = camera.data.view_frame(scene=scene)
    half_width = (max(v.x / -v.z for v in frame) - min(v.x / -v.z for v in frame)) / 2.
    center = settings.center_object
    center_point = inverse @ center.evaluated_get(graph).matrix_world.translation if center else None
    return [matrix @ Vector(addon.nodes.camera_space_reference(
        inverse @ point, settings.strength, settings.fov, settings.zoom,
        settings.near_distance, half_width, center_point=center_point,
        ellipse_x=settings.ellipse_x, ellipse_y=settings.ellipse_y)) for point in points]


def matrix_error(first, second):
    return max(abs(first[row][column] - second[row][column])
               for row in range(4) for column in range(4))


def camera_pose(scene, camera):
    return camera.evaluated_get(refresh(scene)).matrix_world.copy()


def managed_identity(scene):
    return [(target.token, target.node_group.as_pointer(),
             target.output_rig.as_pointer() if target.output_rig else None,
             target.calculator.as_pointer() if target.calculator else None,
             tuple(record.uid for record in target.modifiers),
             tuple(record.output.as_pointer() for record in target.outputs))
            for target in scene.gyogan.targets]


def run():
    if not bpy.app.background:
        raise RuntimeError('カメラ切り替えの検証は専用のバックグラウンドプロセスで実行してください')
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if not hasattr(bpy.types.Scene, 'gyogan'):
        addon.register()
    checks, exception = [], None

    def check(name, condition, **details):
        checks.append(dict(test=name, passed=bool(condition), **details))

    def compare(name, actual, expected, tolerance=3.e-4):
        difference = error(actual, expected)
        check(name, difference < tolerance, max_error=difference)

    try:
        scene = bpy.context.scene
        scene.name = '基準カメラ切り替え・専用検証'
        settings = scene.gyogan
        none_warning = addon.cameras.warning(scene)
        check('no_camera_has_japanese_warning', bool(none_warning) and 'カメラ' in none_warning,
              warning=none_warning)
        first = make_camera(scene, '切替検証・正面カメラA', (0., -10., 2.))
        second = make_camera(scene, '切替検証・正面カメラB', (2., -12., 3.), 42.,
                             (math.pi / 2., 0., -.08))
        settle(scene)
        inactive_warning = addon.cameras.warning(scene)
        check('existing_cameras_do_not_choose_arbitrary_active_camera', scene.camera is None
              and settings.camera is None)
        check('no_active_camera_warning_is_distinct', bool(inactive_warning)
              and inactive_warning != none_warning and 'カメラ' in inactive_warning,
              warning=inactive_warning)
        scene.camera = first
        settle(scene)
        check('scene_active_camera_is_default_reference', settings.camera == first)
        check('active_camera_removes_missing_warning', not addon.cameras.warning(scene))
        settings.subdivision = 'NONE'
        settings.strength = 1.6
        settings.ellipse_x, settings.ellipse_y = 1.2, .85
        scene.render.resolution_x, scene.render.resolution_y = 1280, 720
        grid = make_mesh(scene, '切替検証・格子',
                         [(x, y, .3*x) for y in (-1., 0., 1.) for x in (-2., 0., 2.)],
                         [(a, a+1, a+4, a+3) for a in (0, 1, 3, 4)])
        grid.matrix_world = first.matrix_world @ Matrix.Translation((2., 0., -6.))
        raw_grid = [tuple(vertex.co) for vertex in grid.data.vertices]
        original_grid = positions(scene, grid)
        mesh_target = addon.setup_mesh(scene, grid)
        rig, body = make_rig(scene)
        secondary = scene.view_layers.new('元の非表示を保持するレイヤー')
        body.hide_set(True, view_layer=secondary)
        raw_body = [tuple(vertex.co) for vertex in body.data.vertices]
        source_pose = bone_points(scene, rig)
        original_skin = positions(scene, body)
        rig_target = addon.setup_armature(scene, rig)
        output, output_rig = rig_target.outputs[0].output, rig_target.output_rig
        initial_identity = managed_identity(scene)
        first_grid = positions(scene, grid)
        compare('initial_mesh_matches_camera_A_oracle', first_grid, oracle(scene, original_grid))
        compare('initial_armature_matches_camera_A_oracle', bone_points(scene, output_rig),
                oracle(scene, source_pose))
        scene.camera = second
        settle(scene)
        check('external_active_camera_change_updates_reference', settings.camera == second)
        check('switch_preserves_registered_target_and_generated_IDs', managed_identity(scene) == initial_identity)
        compare('switched_mesh_matches_camera_B_oracle', positions(scene, grid), oracle(scene, original_grid))
        compare('switched_armature_matches_camera_B_oracle', bone_points(scene, output_rig), oracle(scene, source_pose))
        check('switch_changes_projection', error(first_grid, positions(scene, grid)) > .01)
        settings.camera = first
        settle(scene)
        check('reference_assignment_also_sets_scene_active_camera', scene.camera == first)
        compare('switch_back_restores_camera_A_deformation', positions(scene, grid), first_grid)

        # Old camera is independently usable as a center. Replacing every Object
        # Info reference indiscriminately would corrupt this intended reference.
        settings.center_object = first
        scene.camera = second
        settle(scene)
        check('switch_does_not_replace_old_camera_used_as_center', settings.center_object == first)
        compare('camera_center_remains_independent_for_mesh', positions(scene, grid), oracle(scene, original_grid))
        compare('camera_center_remains_independent_for_armature', bone_points(scene, output_rig), oracle(scene, source_pose))
        second_grid = positions(scene, grid)
        second_bones = bone_points(scene, output_rig)
        scene.camera = None
        settle(scene)
        check('clearing_active_camera_clears_reference', settings.camera is None)
        check('clearing_active_camera_keeps_preview_preference', settings.enabled)
        check('clearing_active_camera_warns', bool(addon.cameras.warning(scene)))
        compare('missing_camera_suspends_mesh_deformation', positions(scene, grid), original_grid, 1.e-6)
        check('missing_camera_restores_source_visibility', not body.hide_get() and not body.hide_render
              and output.hide_get() and output.hide_render and output_rig.hide_get())
        check('missing_camera_restores_each_layer_original_visibility', body.hide_get(view_layer=secondary))
        check('missing_camera_preserves_registered_IDs', managed_identity(scene) == initial_identity)
        scene.camera = second
        settle(scene)
        compare('reselect_camera_resumes_previous_mesh_preview', positions(scene, grid), second_grid)
        compare('reselect_camera_resumes_previous_armature_preview', bone_points(scene, output_rig), second_bones)
        check('reselect_camera_resumes_original_preview_visibility', body.hide_get() and body.hide_render
              and not output.hide_get() and not output.hide_render)
        check('reselect_camera_keeps_secondary_layer_hidden', output.hide_get(view_layer=secondary))
        settings.camera = None
        settle(scene)
        check('clearing_reference_also_clears_active_scene_camera', scene.camera is None)
        compare('clearing_reference_suspends_preview', positions(scene, grid), original_grid, 1.e-6)
        settings.camera = second
        settle(scene)
        compare('reference_assignment_resumes_suspended_preview', positions(scene, grid), second_grid)

        disposable = make_camera(scene, '切替検証・削除するカメラ', (-1., -9., 2.5), 35.)
        settings.camera = disposable
        settle(scene)
        bpy.data.objects.remove(disposable, do_unlink=True)
        settle(scene)
        check('deleted_active_camera_clears_scene_and_reference', scene.camera is None and settings.camera is None)
        check('deleted_active_camera_warns_and_keeps_preview_preference', bool(addon.cameras.warning(scene))
              and settings.enabled)
        compare('deleted_active_camera_suspends_deformation', positions(scene, grid), original_grid, 1.e-6)
        scene.camera = second
        settle(scene)
        compare('selection_after_camera_deletion_resumes_preview', positions(scene, grid), second_grid)
        orthographic = make_camera(scene, '切替検証・平行投影カメラ', (0., -11., 2.), 30.)
        orthographic.data.type = 'ORTHO'
        scene.camera = orthographic
        settle(scene)
        check('orthographic_selection_remains_scene_active_camera', scene.camera == settings.camera == orthographic)
        check('orthographic_camera_warns_and_keeps_preview_preference', bool(addon.cameras.warning(scene))
              and settings.enabled)
        compare('orthographic_camera_suspends_mesh_preview', positions(scene, grid), original_grid, 1.e-6)
        check('orthographic_camera_suspends_armature_preview', not body.hide_get() and output.hide_get())
        orthographic.data.type = 'PERSP'
        settle(scene)
        check('changing_same_camera_to_perspective_clears_warning', not addon.cameras.warning(scene))
        compare('changing_same_camera_to_perspective_resumes_mesh', positions(scene, grid), oracle(scene, original_grid))
        compare('changing_same_camera_to_perspective_resumes_armature', bone_points(scene, output_rig), oracle(scene, source_pose))
        scene.camera = second
        settle(scene)
        settings.enabled = False
        scene.camera = first
        settle(scene)
        check('camera_switch_respects_explicit_preview_off', not settings.enabled and not body.hide_get())
        compare('preview_off_switch_keeps_original_geometry', positions(scene, grid), original_grid, 1.e-6)
        settings.enabled = True
        settings.strength = 0.
        scene.camera = second
        settle(scene)
        compare('zero_strength_after_switch_keeps_mesh', positions(scene, grid), original_grid, 1.e-6)
        compare('zero_strength_after_switch_keeps_skin', positions(scene, output), original_skin)
        settings.strength = 1.6
        settings.center_object = None

        # Active dolly ownership moves only after a compatible new camera passes
        # preflight. The newly chosen camera starts a fresh ratio-one reference.
        scene.camera = first
        settle(scene)
        control = scene.gyogan_dolly
        target = bpy.data.objects.new('切替検証・ドリー被写体', None)
        scene.collection.objects.link(target)
        target.location = (0., 0., 2.)
        control.target = target
        first_pose, first_lens = camera_pose(scene, first), first.data.lens
        second_pose, second_lens = camera_pose(scene, second), second.data.lens
        addon.dolly.setup(scene)
        control.ratio = 1.7
        settle(scene)
        check('dolly_started_on_original_camera', control.active and control.camera == first)

        # A late redraw failure occurs after camera/driver ownership transferred.
        # Retrying display must not revert only the selection pointers and leave
        # generated geometry and dolly drivers attached to a different camera.
        refresh_views = addon.cameras._refresh_views
        redraw_failures = []

        def fail_redraw_once(current_scene):
            if not redraw_failures:
                redraw_failures.append(current_scene.name)
                raise RuntimeError('検証用：カメラビューの再描画に一度失敗')
            refresh_views(current_scene)

        addon.cameras._refresh_views = fail_redraw_once
        try:
            scene.camera = second
            addon.cameras.synchronize(scene)
            check('late_redraw_failure_was_exercised', len(redraw_failures) == 1)
            check('late_redraw_failure_keeps_committed_camera_selection',
                  scene.camera == settings.camera == control.camera == second and control.active)
            tokens = {record.token for record in settings.targets}
            camera_sockets = [node.inputs['Object' if node.get('gyogan_role') == 'camera_transform' else 'Camera']
                              for group in bpy.data.node_groups if group.get(addon.OWNER) in tokens
                              for node in group.nodes
                              if node.get('gyogan_role') in {'camera_transform', 'camera_projection'}]
            check('late_redraw_failure_keeps_all_generated_camera_references', len(camera_sockets) >= 4
                  and all(socket.default_value == second for socket in camera_sockets))
            check('late_redraw_failure_already_restored_old_camera',
                  (first.location - first_pose.translation).length < 2.e-5
                  and abs(first.data.lens - first_lens) < 1.e-5
                  and (not first.animation_data or not first.animation_data.drivers))
            check('late_redraw_failure_has_retry_warning', bool(settings.camera_error))
        finally:
            addon.cameras._refresh_views = refresh_views
        settle(scene)
        check('late_redraw_retry_clears_warning_without_reverting_selection', not addon.cameras.warning(scene)
              and scene.camera == settings.camera == control.camera == second and control.active)
        compare('late_redraw_retry_mesh_matches_current_camera', positions(scene, grid), oracle(scene, original_grid))
        compare('late_redraw_retry_armature_matches_current_camera', bone_points(scene, output_rig), oracle(scene, source_pose))
        check('active_dolly_switch_follows_scene_and_reference', scene.camera == settings.camera == control.camera == second
              and control.active and control.enabled)
        check('new_dolly_camera_starts_at_ratio_one', abs(control.ratio - 1.) < 1.e-6)
        check('dolly_switch_preserves_target_selection', control.target == target)
        check('dolly_switch_restores_old_camera_pose', matrix_error(camera_pose(scene, first), first_pose) < 2.e-5)
        check('dolly_switch_restores_old_camera_lens', abs(first.data.lens - first_lens) < 1.e-5)
        check('dolly_switch_releases_old_camera_owned_drivers', not first.animation_data or not first.animation_data.drivers)
        check('dolly_switch_keeps_new_camera_initial_pose', matrix_error(camera_pose(scene, second), second_pose) < 2.e-5)
        check('dolly_switch_keeps_new_camera_initial_lens', abs(second.data.lens - second_lens) < 1.e-5)
        check('dolly_switch_keeps_registered_IDs', managed_identity(scene) == initial_identity)
        control.ratio = 1.35
        settle(scene)
        invalid = make_camera(scene, '切替検証・親付きの非対応カメラ', (0., -8., 2.), 38.)
        invalid.parent = target
        invalid_pose, invalid_lens = camera_pose(scene, invalid), invalid.data.lens
        current_pose, current_lens = camera_pose(scene, second), second.data.lens
        token, ratio = control.token, control.ratio
        scene.camera = invalid
        settle(scene)
        check('incompatible_active_dolly_camera_switch_is_rejected', scene.camera == second
              and settings.camera == second and control.camera == second and control.active)
        check('rejected_switch_keeps_owned_dolly_token_and_ratio', control.token == token and control.ratio == ratio)
        check('rejected_switch_keeps_running_camera_pose', matrix_error(camera_pose(scene, second), current_pose) < 2.e-5)
        check('rejected_switch_keeps_running_camera_lens', abs(second.data.lens - current_lens) < 1.e-5)
        check('rejected_switch_does_not_change_candidate', matrix_error(camera_pose(scene, invalid), invalid_pose) < 2.e-5
              and invalid.data.lens == invalid_lens and invalid.parent == target)
        check('rejected_switch_reports_japanese_reason', bool(settings.status) or bool(addon.cameras.warning(scene)))

        # Save/reload both an active dolly switch and a suspended missing-camera
        # setup; pointers, generated data, and original restoration must survive.
        names = {key: obj.name for key, obj in dict(grid=grid, rig=rig, body=body, output=output,
                                                  output_rig=output_rig, first=first, second=second).items()}
        before_save_grid, before_save_bones = positions(scene, grid), bone_points(scene, output_rig)
        saved_tokens = [record.token for record in settings.targets]
        bpy.ops.wm.save_as_mainfile(filepath=str(FIXTURE), check_existing=False)
        bpy.ops.wm.open_mainfile(filepath=str(FIXTURE))
        scene, settings, control = bpy.context.scene, bpy.context.scene.gyogan, bpy.context.scene.gyogan_dolly
        grid, rig, body, output, output_rig, first, second = [bpy.data.objects[names[key]]
            for key in ('grid', 'rig', 'body', 'output', 'output_rig', 'first', 'second')]
        settle(scene)
        check('saved_switch_preserves_camera_and_dolly_selection', scene.camera == settings.camera == control.camera == second
              and control.active and control.enabled)
        check('saved_switch_preserves_target_tokens', [record.token for record in settings.targets] == saved_tokens)
        compare('saved_switch_keeps_mesh_projection', positions(scene, grid), before_save_grid)
        compare('saved_switch_keeps_armature_projection', bone_points(scene, output_rig), before_save_bones)
        scene.camera = None
        settle(scene)
        check('clearing_camera_after_saved_switch_stops_dolly', not control.active
              and scene.camera is None and settings.camera is None)
        check('clearing_camera_after_saved_switch_restores_new_camera_pose', matrix_error(camera_pose(scene, second), second_pose) < 2.e-5)
        check('clearing_camera_after_saved_switch_restores_new_camera_lens', abs(second.data.lens - second_lens) < 1.e-5)
        scene.camera = second
        settle(scene)
        check('reselecting_after_missing_camera_does_not_restart_dolly', not control.active)
        scene.camera = None
        settle(scene)
        bpy.ops.wm.save_as_mainfile(filepath=str(FIXTURE), check_existing=False)
        bpy.ops.wm.open_mainfile(filepath=str(FIXTURE))
        scene, settings = bpy.context.scene, bpy.context.scene.gyogan
        grid, rig, body, output, output_rig, first, second = [bpy.data.objects[names[key]]
            for key in ('grid', 'rig', 'body', 'output', 'output_rig', 'first', 'second')]
        settle(scene)
        check('saved_missing_camera_stays_unassigned_with_warning', scene.camera is None and settings.camera is None
              and bool(addon.cameras.warning(scene)))
        check('saved_missing_camera_keeps_preview_preference', settings.enabled)
        compare('saved_missing_camera_keeps_mesh_original', positions(scene, grid), original_grid, 1.e-6)
        check('saved_missing_camera_keeps_original_source_visible', not body.hide_get() and output.hide_get())
        scene.camera = second
        settle(scene)
        compare('camera_after_suspended_reload_resumes_mesh', positions(scene, grid), oracle(scene, original_grid))
        compare('camera_after_suspended_reload_resumes_armature', bone_points(scene, output_rig), oracle(scene, source_pose))
        check('all_switches_preserve_raw_source_vertices', raw_grid == [tuple(v.co) for v in grid.data.vertices]
              and raw_body == [tuple(v.co) for v in body.data.vertices])
        compare('all_switches_preserve_source_rig_pose', bone_points(scene, rig), source_pose, 1.e-6)

        # A user may edit an owned graph after registration. Unsupported graph
        # edits must reject retargeting, but cannot keep a camera-less preview
        # visible or strand its owned lens driver after camera deletion.
        control = scene.gyogan_dolly
        addon.dolly.setup(scene)
        control.ratio = 1.2
        settle(scene)
        edited_identity = managed_identity(scene)
        tree = next(record.node_group for record in settings.targets if record.kind == 'MESH')
        projection = next(node for node in tree.nodes if node.bl_idname == 'GeometryNodeCameraInfo')
        camera_source = tree.nodes.new('GeometryNodeSwitch')
        camera_source.input_type = 'OBJECT'
        camera_source.inputs['Switch'].default_value = False
        camera_source.inputs['False'].default_value = second
        tree.links.new(camera_source.outputs[0], projection.inputs['Camera'])
        scene.camera = first
        settle(scene)
        check('hand_edited_camera_link_rejects_switch_safely', scene.camera == settings.camera == control.camera == second
              and control.active and bool(settings.camera_error))
        check('rejected_switch_preserves_user_camera_link', projection.inputs['Camera'].is_linked
              and projection.inputs['Camera'].links[0].from_node == camera_source)
        camera_data = second.data
        bpy.data.objects.remove(second, do_unlink=True)
        settle(scene)
        check('deleted_camera_with_edited_graph_clears_reference', scene.camera is None and settings.camera is None)
        check('deleted_camera_with_edited_graph_keeps_warning', bool(addon.cameras.warning(scene))
              and bool(settings.camera_error))
        check('deleted_camera_with_edited_graph_keeps_preview_preference', settings.enabled)
        check('deleted_camera_with_edited_graph_disables_owned_mesh_modifiers', all(
            not addon.find_modifier(record.source, modifier).show_viewport
            and not addon.find_modifier(record.source, modifier).show_render
            for record in settings.targets if record.kind == 'MESH' for modifier in record.modifiers))
        compare('deleted_camera_with_edited_graph_shows_original_mesh', positions(scene, grid), original_grid, 1.e-6)
        check('deleted_camera_with_edited_graph_restores_armature_sources', not body.hide_get() and not body.hide_render
              and output.hide_get() and output.hide_render and output_rig.hide_get())
        check('deleted_camera_with_edited_graph_stops_dolly', not control.active)
        check('deleted_camera_with_edited_graph_removes_owned_lens_driver', not camera_data.animation_data
              or not any(curve.data_path == 'lens' for curve in camera_data.animation_data.drivers))
        check('deleted_camera_with_edited_graph_preserves_generated_IDs', managed_identity(scene) == edited_identity)
        check('deleted_camera_does_not_remove_user_graph_edit', projection.inputs['Camera'].is_linked
              and projection.inputs['Camera'].links[0].from_node == camera_source)
        tokens = {record.token for record in settings.targets}
        while settings.targets:
            addon.remove_target(scene, len(settings.targets) - 1)
        leftovers = [block.name for kind in ('objects', 'meshes', 'armatures', 'node_groups', 'collections')
                     for block in getattr(bpy.data, kind) if block.get(addon.OWNER) in tokens]
        check('remove_after_switches_leaves_no_owned_data', not leftovers, leftovers=leftovers)
        check('remove_after_switches_restores_original_setup', not grid.modifiers and len(body.modifiers) == 1
              and body.modifiers[0].object == rig and not body.hide_get() and not body.hide_render)
    except Exception:
        exception = traceback.format_exc()
        print(exception)
    finally:
        passed = bool(checks) and all(item['passed'] for item in checks) and exception is None
        report = dict(blender=bpy.app.version_string, passed=passed, checks=checks, exception=exception)
        REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        print('GYOGAN_CAMERA_SWITCH_RESULTS=' + json.dumps(report, ensure_ascii=False))
    if not passed:
        raise AssertionError('カメラ切り替えの検証に失敗しました: ' + str(REPORT))


if __name__ == '__main__':
    run()
