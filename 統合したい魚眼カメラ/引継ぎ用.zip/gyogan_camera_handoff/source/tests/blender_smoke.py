"""Run with Blender 5.2 --background --factory-startup --python this_file.

Can also be executed through MCP. All test objects belong to a new test scene.
The caller's scene is restored; test data is removed on success or failure.
"""
import json
import math
import os
import sys
import traceback
from pathlib import Path

import bpy
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
from test_paths import output_path
sys.path.insert(0, str(ROOT))
import gyogan_camera as addon


def run():
    if not hasattr(bpy.types.Scene, 'gyogan'):
        addon.register()
    old_scene = bpy.context.window.scene
    scene = bpy.data.scenes.new('Gyogan · Automated Verification')
    bpy.context.window.scene = scene
    baseline_ids = {kind: {x.as_pointer() for x in getattr(bpy.data, kind)}
                    for kind in ['objects', 'meshes', 'armatures', 'cameras', 'actions', 'node_groups', 'collections']}
    results = []

    def check(name, condition, **details):
        results.append(dict(test=name, passed=bool(condition), **details))
        if not condition:
            raise AssertionError(f'{name}: {details}')

    def refresh():
        scene.update_tag()
        bpy.context.view_layer.update()
        return bpy.context.evaluated_depsgraph_get()

    def positions(obj):
        graph = refresh()
        evaluated = obj.evaluated_get(graph)
        mesh = evaluated.to_mesh()
        try:
            return [evaluated.matrix_world @ v.co for v in mesh.vertices]
        finally:
            evaluated.to_mesh_clear()

    def error(a, b):
        return max(((p-q).length for p, q in zip(a, b)), default=0.0) if len(a) == len(b) else float('inf')

    def make_mesh(name, vertices, faces):
        data = bpy.data.meshes.new(name)
        data.from_pydata(vertices, [], faces)
        data.update()
        obj = bpy.data.objects.new(name, data)
        scene.collection.objects.link(obj)
        return obj

    try:
        camera = bpy.data.objects.new('Gyogan Test Camera', bpy.data.cameras.new('Gyogan Test Camera'))
        scene.collection.objects.link(camera)
        camera.data.lens = 25
        scene.camera = scene.gyogan.camera = camera
        scene.render.resolution_x, scene.render.resolution_y = 1024, 768
        settings = scene.gyogan
        settings.subdivision = 'NONE'
        settings.strength = 0.0
        grid = make_mesh('Gyogan Test Grid',
                         [(x, y, -6.0) for y in (-2., 0., 2.) for x in (-4., 0., 4.)],
                         [(a, a+1, a+4, a+3) for a in (0, 1, 3, 4)])
        original_coordinates = [v.co.copy() for v in grid.data.vertices]
        original = positions(grid)
        target = addon.setup_mesh(scene, grid)
        check('mesh_strength_zero', error(positions(grid), original) < 1e-5)
        settings.strength = 1.0
        warped = positions(grid)
        frame = camera.data.view_frame(scene=scene)
        h = (max(p.x / -p.z for p in frame) - min(p.x / -p.z for p in frame)) / 2
        reference = [Vector(addon.nodes.camera_space_reference(p, 1, settings.fov,
                      settings.zoom, settings.near_distance, h)) for p in original]
        check('mesh_numeric_projection', error(warped, reference) < 2e-5,
              max_error=error(warped, reference), half_width=h)
        check('mesh_actually_deforms', error(warped, original) > 0.1)

        # The extended range must change the projection without extrapolating
        # vertices through the optical axis or reversing radial order.
        settings.strength = 2.5
        strong_warped = positions(grid)
        strong_reference = [Vector(addon.nodes.camera_space_reference(
            p, 2.5, settings.fov, settings.zoom, settings.near_distance, h)) for p in original]
        check('mesh_strength_above_one_projection',
              error(strong_warped, strong_reference) < 2e-5 and error(strong_warped, warped) > .05,
              max_error=error(strong_warped, strong_reference), displacement=error(strong_warped, warped))
        radial_order_ok = True
        for high_strength in (2.5, 5.0):
            settings.strength = high_strength
            high_positions = positions(grid)
            radial_pairs = sorted((math.hypot(p.x, p.y), math.hypot(q.x, q.y))
                                  for p, q in zip(original, high_positions))
            radial_order_ok = radial_order_ok and all(
                p.x*q.x + p.y*q.y > 0 if math.hypot(p.x, p.y) > 1e-6 else math.hypot(q.x, q.y) < 1e-6
                for p, q in zip(original, high_positions))
            radial_order_ok = radial_order_ok and all(
                next_output > output_radius if next_radius > radius + 1e-6 else True
                for (radius, output_radius), (next_radius, next_output) in zip(radial_pairs, radial_pairs[1:]))
            radial_order_ok = radial_order_ok and all(
                math.isfinite(value) for q in high_positions for value in q)
            radial_order_ok = radial_order_ok and all(abs(p.z-q.z) < 1e-6 for p, q in zip(original, high_positions))
        check('mesh_strength_above_one_preserves_radial_order', radial_order_ok, strengths=[2.5, 5.0])

        # Build the old effective topology in place, even though this test was
        # launched with the new add-on. Preserve the actual modifier/group IDs.
        tree = target.node_group
        theta = next(node for node in tree.nodes
                     if node.bl_idname == 'ShaderNodeMath' and node.operation == 'ARCTAN2')
        radius = next(node.outputs['Value'] for node in tree.nodes
                      if node.bl_idname == 'ShaderNodeVectorMath' and node.operation == 'LENGTH')
        numerator = next(link.to_node for link in theta.outputs[0].links
                         if link.to_node.bl_idname == 'ShaderNodeMath' and link.to_node.operation == 'MULTIPLY')
        division = next(link.to_node for link in numerator.outputs[0].links
                        if link.to_node.bl_idname == 'ShaderNodeMath' and link.to_node.operation == 'DIVIDE')
        denominator = division.inputs[1].links[0].from_node
        assert denominator.bl_idname == 'ShaderNodeMath' and denominator.operation == 'MAXIMUM'
        tree.links.new(radius, theta.inputs[0])
        tree.links.new(radius, denominator.inputs[0])
        on_axis = next(node for node in tree.nodes
                       if node.bl_idname == 'ShaderNodeMath' and node.operation == 'LESS_THAN')
        tree.links.new(radius, on_axis.inputs[0])
        if 'gyogan_projection_version' in tree:
            del tree['gyogan_projection_version']
        tree.update_tag()
        settings.strength = 2.5
        legacy_warped = positions(grid)
        check('legacy_strength_graph_emulated', error(legacy_warped, warped) < 2e-5)
        group_pointer = tree.as_pointer()
        upgraded = addon.nodes.upgrade_strength_group(tree)
        check('legacy_strength_graph_upgraded',
              upgraded and tree.get('gyogan_projection_version') == 2
              and target.node_group.as_pointer() == group_pointer
              and error(positions(grid), strong_reference) < 2e-5)
        upgraded_node_count = len(tree.nodes)
        addon.nodes.upgrade_strength_group(tree)
        check('legacy_strength_graph_upgrade_idempotent',
              len(tree.nodes) == upgraded_node_count and error(positions(grid), strong_reference) < 2e-5,
              node_count=upgraded_node_count)
        settings.strength = 0.0
        check('mesh_strength_zero_after_high', error(positions(grid), original) < 1e-5)
        settings.strength = .4
        old_blend = [p.lerp(q, .4) for p, q in zip(original, warped)]
        check('mesh_existing_blend_range_unchanged', error(positions(grid), old_blend) < 2e-5)
        settings.strength = 1.0

        # Registration must include peripheral objects brought into the frame
        # by strength > 1, while continuing to reject objects behind the camera.
        candidate = make_mesh('Gyogan Peripheral Registration Candidate',
                              [(-.05, -.05, 0), (.05, -.05, 0), (.05, .05, 0), (-.05, .05, 0)],
                              [(0, 1, 2, 3)])
        behind = make_mesh('Gyogan Behind Camera Candidate',
                           [(-.05, -.05, 0), (.05, -.05, 0), (.05, .05, 0), (-.05, .05, 0)],
                           [(0, 1, 2, 3)])
        candidate.location = (10*math.sin(math.radians(80)), 0, -10*math.cos(math.radians(80)))
        behind.location = (0, 0, 5)
        prior_fov, prior_scope = settings.fov, settings.scope
        settings.fov = math.radians(90)
        settings.scope = 'CAMERA'
        refresh()
        standard_excludes = not addon.within_camera(candidate, scene)
        settings.strength = 5.0
        selected_candidates = addon.collect_candidates(bpy.context)
        check('camera_registration_high_strength_front_hemisphere',
              standard_excludes and addon.within_camera(candidate, scene)
              and not addon.within_camera(behind, scene)
              and candidate in selected_candidates and behind not in selected_candidates,
              fov_degrees=90, strength=5, peripheral_angle_degrees=80)
        # Exercise the nonsaturated inverse as well as the hemisphere branch.
        candidate.location = (10*math.sin(math.radians(25)), 0, -10*math.cos(math.radians(25)))
        settings.fov = math.radians(30)
        settings.strength = 1.0
        refresh()
        standard_excludes = not addon.within_camera(candidate, scene)
        settings.strength = 2.0
        check('camera_registration_high_strength_inverse_angle',
              standard_excludes and addon.within_camera(candidate, scene),
              fov_degrees=30, strength=2, peripheral_angle_degrees=25)
        settings.fov, settings.scope, settings.strength = prior_fov, prior_scope, 1.0

        # Live camera transform/lens, object transform and aspect without frame stepping.
        camera.location.x = .8
        moved = positions(grid)
        check('camera_live_move', error(moved, warped) > .01)
        camera.data.lens = 40
        changed_lens = positions(grid)
        check('camera_live_lens', error(changed_lens, moved) > .01)
        grid.scale = (1.3, .7, 1.1)
        grid.rotation_euler.z = .15
        settings.strength = 0
        settings.enabled = False
        unmodified = positions(grid)
        settings.enabled = True
        check('mesh_nonuniform_zero', error(positions(grid), unmodified) < 1e-5)
        settings.strength = 1
        check('mesh_nonuniform_deforms', error(positions(grid), unmodified) > .1)
        # Rename the owned modifier before removal: persisted UID must work.
        grid.modifiers[-1].name = 'User renamed the fisheye modifier'
        settings.enabled = False
        check('mesh_toggle_restores', error(positions(grid), unmodified) < 1e-5)
        addon.remove_target(scene, 0)
        check('mesh_remove_restores', len(grid.modifiers) == 0 and error(positions(grid), unmodified) < 1e-5)
        check('mesh_data_untouched', error([v.co.copy() for v in grid.data.vertices], original_coordinates) == 0)
        # Extra Catmull subdivision must also be disabled and removed.
        settings.subdivision = 'CATMULL_CLARK'
        settings.enabled = True
        addon.setup_mesh(scene, grid)
        check('subdivision_added', len(grid.modifiers) == 2)
        settings.enabled = False
        check('subdivision_toggle_restores', error(positions(grid), unmodified) < 1e-5)
        addon.remove_target(scene, 0)
        settings.subdivision = 'NONE'

        # Simple two-bone rig with an overlapping weighted mesh.
        data = bpy.data.armatures.new('Gyogan Test Skeleton')
        rig = bpy.data.objects.new('Gyogan Test Skeleton', data)
        scene.collection.objects.link(rig)
        bpy.context.view_layer.objects.active = rig
        rig.select_set(True)
        bpy.ops.object.mode_set(mode='EDIT')
        root = data.edit_bones.new('Root')
        root.head, root.tail = (0, 0, 0), (0, 1, 0)
        tip = data.edit_bones.new('Tip')
        tip.head, tip.tail, tip.parent, tip.use_connect = (0, 1, 0), (0, 2, 0), root, True
        bpy.ops.object.mode_set(mode='OBJECT')
        rig.location = (2, -1, -6)
        body = make_mesh('Gyogan Test Body',
                         [(x, y, z) for y in (0., .5, 1., 1.5, 2.)
                          for x, z in ((-.2,-.2),(.2,-.2),(.2,.2),(-.2,.2))],
                         [(4*j+i, 4*j+(i+1)%4, 4*(j+1)+(i+1)%4, 4*(j+1)+i)
                          for j in range(4) for i in range(4)])
        body.location = rig.location.copy()
        vg0, vg1 = body.vertex_groups.new(name='Root'), body.vertex_groups.new(name='Tip')
        for v in body.data.vertices:
            w = max(0, min(1, v.co.y - .5))
            vg0.add([v.index], 1-w, 'REPLACE')
            vg1.add([v.index], w, 'REPLACE')
        mod = body.modifiers.new('Original Armature', 'ARMATURE')
        mod.object = rig
        rig.pose.bones['Root'].rotation_mode = 'XYZ'
        rig.pose.bones['Root'].rotation_euler.z = .12
        rig.pose.bones['Tip'].rotation_mode = 'XYZ'
        rig.pose.bones['Tip'].rotation_euler.z = -.3
        rig.pose.bones['Tip'].scale = (1.1, .85, 1.2)
        original_skin = positions(body)
        rest_matrices = {b.name: b.matrix_local.copy() for b in rig.data.bones}
        source_data = body.data
        second_layer = scene.view_layers.new('Initially Hidden Layer')
        body.hide_set(True, view_layer=second_layer)
        settings.strength = 0
        settings.enabled = True
        rig_target = addon.setup_armature(scene, rig)
        output = rig_target.outputs[0].output
        skin0 = positions(output)
        check('armature_strength_zero', error(skin0, original_skin) < 3e-5,
              max_error=error(skin0, original_skin))
        check('source_rig_data_isolated', rig_target.output_rig.data != rig.data)
        check('mesh_data_shared_untouched', output.data == source_data and body.data == source_data)
        settings.strength = 1
        skin1 = positions(output)
        check('armature_deforms', error(skin1, skin0) > .05, displacement=error(skin1, skin0))
        # Source pose stays the animation input, even while source mesh is hidden.
        check('source_skin_unchanged', error(positions(body), original_skin) < 3e-5)
        settings.strength = 2.5
        skin_high = positions(output)
        check('armature_strength_above_one_and_source_untouched',
              error(skin_high, skin1) > .01 and error(positions(body), original_skin) < 3e-5
              and all(math.isfinite(value) for vertex in skin_high for value in vertex),
              displacement=error(skin_high, skin1))
        settings.strength = 0.0
        check('armature_strength_zero_after_high', error(positions(output), original_skin) < 3e-5)
        settings.strength = 1.0
        rig.pose.bones['Tip'].rotation_euler.z = .2
        check('armature_live_pose', error(positions(output), skin1) > .01)
        settings.enabled = False
        check('armature_toggle_restores_visibility', not body.hide_get() and
              body.hide_get(view_layer=second_layer) and not body.hide_render and output.hide_render)
        settings.enabled = True
        token = rig_target.token
        addon.remove_target(scene, 0)
        check('armature_remove_restores_visibility', not body.hide_get() and
              body.hide_get(view_layer=second_layer) and not body.hide_render)
        check('source_modifier_preserved', len(body.modifiers) == 1 and body.modifiers[0].object == rig)
        check('source_rest_pose_preserved', all(
            max(abs(rest_matrices[b.name][i][j] - b.matrix_local[i][j]) for i in range(4) for j in range(4)) < 1e-7
            for b in rig.data.bones))
        leftover = [x.name for kind in ['objects','meshes','armatures','node_groups','collections']
                    for x in getattr(bpy.data,kind) if x.get(addon.OWNER) == token]
        check('armature_cleanup_no_owned_ids', not leftover, leftover=leftover)
        # Unsupported rigs must fail before any record or source mutation.
        rig.data.bones['Tip'].bbone_segments = 3
        try:
            addon.setup_armature(scene, rig)
            rejected = False
        except ValueError:
            rejected = True
        check('unsupported_rig_preflight', rejected and not settings.targets and not body.hide_render)

        # Failure during node construction removes the earlier subdivision.
        original_builder = addon.nodes.build_mesh_group
        settings.subdivision = 'SIMPLE'
        def deliberate_failure(*args, **kwargs):
            raise RuntimeError('intentional rollback verification')
        addon.nodes.build_mesh_group = deliberate_failure
        try:
            try:
                addon.setup_mesh(scene, grid)
            except RuntimeError:
                pass
        finally:
            addon.nodes.build_mesh_group = original_builder
        check('setup_failure_rolls_back', not grid.modifiers and not settings.targets)
    finally:
        while scene.gyogan.targets:
            addon.remove_target(scene, len(scene.gyogan.targets)-1)
        bpy.context.window.scene = old_scene
        bpy.data.scenes.remove(scene)
        for kind in ['objects', 'collections', 'meshes', 'armatures', 'cameras', 'actions', 'node_groups']:
            for item in list(getattr(bpy.data, kind)):
                if item.as_pointer() not in baseline_ids[kind]:
                    if kind == 'objects':
                        bpy.data.objects.remove(item, do_unlink=True)
                    elif item.users == 0:
                        getattr(bpy.data, kind).remove(item)
        report = {'blender': bpy.app.version_string, 'checks': results,
                  'passed': bool(results) and all(r['passed'] for r in results)}
        output_path('smoke_result.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        print('GYOGAN_TEST_RESULTS=' + json.dumps(report, ensure_ascii=False))


if __name__ == '__main__':
    run()
