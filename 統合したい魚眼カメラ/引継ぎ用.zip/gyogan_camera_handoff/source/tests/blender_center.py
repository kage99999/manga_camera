"""Center-object regression checks in a separate Blender 5.2 background process.

Run with --background --factory-startup --python-exit-code 1 --python this_file.
The script creates and reopens its own small numeric fixtures. Never run via MCP
or in a user's interactive session. No user assets or human models are used.
"""

import importlib.util
import json
import math
import sys
import traceback
from pathlib import Path

import bpy
from mathutils import Matrix, Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
from test_paths import output_path
REPORT = output_path('center_result.json')
FIXTURE = output_path('center_fixture.blend')
LEGACY_FIXTURE = output_path('center_legacy_fixture.blend')
sys.path.insert(0, str(ROOT))
sys.dont_write_bytecode = True
import gyogan_camera as addon

spec = importlib.util.spec_from_file_location(
    'gyogan_legacy_v2_fixture', ROOT / 'tests' / 'fixtures' / 'legacy_v2_nodes.py')
legacy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)


def refresh(scene):
    scene.update_tag()
    bpy.context.view_layer.update()
    return bpy.context.evaluated_depsgraph_get()


def positions(scene, obj):
    evaluated = obj.evaluated_get(refresh(scene))
    mesh = evaluated.to_mesh()
    try:
        return [evaluated.matrix_world @ vertex.co for vertex in mesh.vertices]
    finally:
        evaluated.to_mesh_clear()


def error(first, second):
    if len(first) != len(second):
        return 1.0e20
    return max(((a - b).length for a, b in zip(first, second)), default=0.0)


def source_world(scene, obj):
    evaluated = obj.evaluated_get(refresh(scene))
    return [evaluated.matrix_world @ vertex.co for vertex in obj.data.vertices]


def make_mesh(scene, name, vertices, faces):
    mesh = bpy.data.meshes.new(name + '・データ')
    mesh.from_pydata(vertices, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    scene.collection.objects.link(obj)
    return obj


def make_empty(scene, name, camera_point):
    obj = bpy.data.objects.new(name, None)
    scene.collection.objects.link(obj)
    obj.location = scene.camera.matrix_world @ Vector(camera_point)
    return obj


def reference(scene, points, center):
    """Independent composition around the frozen old v2 optical-axis oracle."""
    graph = refresh(scene)
    settings = scene.gyogan
    camera = scene.camera.evaluated_get(graph)
    camera_matrix = camera.matrix_world.normalized()
    inverse = camera_matrix.inverted()
    anchor = inverse @ center.evaluated_get(graph).matrix_world.translation if center else None
    frame = camera.data.view_frame(scene=scene)
    half_width = (max(v.x / -v.z for v in frame) - min(v.x / -v.z for v in frame)) / 2
    result = []
    for point in points:
        p = inverse @ point
        offset = Vector((0.0, 0.0, 0.0))
        if anchor is not None and -anchor.z > settings.near_distance:
            fade = min(1., max(0., (-anchor.z - settings.near_distance) / settings.near_distance))
            fade = fade * fade * (3. - 2. * fade)
            offset.x = fade * -p.z * anchor.x / -anchor.z
            offset.y = fade * -p.z * anchor.y / -anchor.z
        old = Vector(legacy.camera_space_reference(
            p - offset, settings.strength, settings.fov, settings.zoom,
            settings.near_distance, half_width)) + offset
        result.append(camera_matrix @ old)
    return result


def bone_points(scene, rig):
    evaluated = rig.evaluated_get(refresh(scene))
    result = []
    for name in ('根元', '先端'):
        bone = evaluated.pose.bones[name]
        matrix = evaluated.matrix_world @ bone.matrix
        result.extend((matrix.translation, matrix @ Vector((0.0, bone.bone.length, 0.0))))
    return result


def make_rig(scene):
    data = bpy.data.armatures.new('中心検証・骨格データ')
    rig = bpy.data.objects.new('中心検証・元リグ', data)
    scene.collection.objects.link(rig)
    bpy.context.view_layer.objects.active = rig
    rig.select_set(True)
    bpy.ops.object.mode_set(mode='EDIT')
    first = data.edit_bones.new('根元')
    first.head, first.tail = (0, 0, 0), (0, 1, 0)
    second = data.edit_bones.new('先端')
    second.head, second.tail = (0, 1, 0), (0, 2, 0)
    second.parent, second.use_connect = first, True
    bpy.ops.object.mode_set(mode='OBJECT')
    rig.matrix_world = scene.camera.matrix_world @ Matrix.Translation((-2, -1, -7))
    body = make_mesh(scene, '中心検証・ウェイト筒',
                     [(x, y, z) for y in (0., .5, 1., 1.5, 2.)
                      for x, z in ((-.2, -.2), (.2, -.2), (.2, .2), (-.2, .2))],
                     [(4*j+i, 4*j+(i+1)%4, 4*(j+1)+(i+1)%4, 4*(j+1)+i)
                      for j in range(4) for i in range(4)])
    body.matrix_world = rig.matrix_world.copy()
    groups = [body.vertex_groups.new(name=name) for name in ('根元', '先端')]
    for vertex in body.data.vertices:
        weight = min(1., max(0., vertex.co.y - .5))
        groups[0].add([vertex.index], 1 - weight, 'REPLACE')
        groups[1].add([vertex.index], weight, 'REPLACE')
    modifier = body.modifiers.new('元のアーマチュア', 'ARMATURE')
    modifier.object = rig
    rig.pose.bones['根元'].rotation_mode = 'XYZ'
    rig.pose.bones['根元'].rotation_euler.z = .12
    rig.pose.bones['先端'].rotation_mode = 'XYZ'
    rig.pose.bones['先端'].rotation_euler.z = -.3
    rig.pose.bones['先端'].scale = (1.1, .9, 1.2)
    return rig, body


def legacy_armature_warp(scene, target):
    """Replace only the generated warp subgroup with an actual old-v2 graph."""
    tree = bpy.data.node_groups.new('中心検証・旧人物座標変形', 'GeometryNodeTree')
    tree.interface.new_socket(name='Point', in_out='INPUT', socket_type='NodeSocketVector')
    tree.interface.new_socket(name='Point', in_out='OUTPUT', socket_type='NodeSocketVector')
    graph = legacy.Graph(tree)
    point = graph.node('NodeGroupInput').outputs['Point']
    result = legacy.CameraWarp(graph, scene, space='ORIGINAL').apply(point)
    graph.connect(result, graph.node('NodeGroupOutput'), 'Point')
    tree[addon.OWNER] = target.token
    tree['gyogan_role'] = 'armature_warp'
    previous = set()
    for node in target.node_group.nodes:
        if node.bl_idname != 'GeometryNodeGroup' or not node.node_tree:
            continue
        if node.node_tree.get('gyogan_role') != 'armature_warp':
            continue
        inputs = [(link.from_socket, link.to_socket.name) for link in node.inputs[0].links]
        outputs = [(link.from_socket.name, link.to_socket) for link in node.outputs[0].links]
        previous.add(node.node_tree)
        node.node_tree = tree
        for source, name in inputs:
            target.node_group.links.new(source, node.inputs[name])
        for name, destination in outputs:
            target.node_group.links.new(node.outputs[name], destination)
    for old in previous:
        if old.users == 0:
            bpy.data.node_groups.remove(old)
    return tree


def run():
    if not bpy.app.background:
        raise RuntimeError('中心の検証は、専用のバックグラウンドプロセスで実行してください')
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if not hasattr(bpy.types.Scene, 'gyogan'):
        addon.register()
    checks, exception = [], None

    def check(name, passed, **details):
        checks.append(dict(test=name, passed=bool(passed), **details))

    def compare(name, actual, expected, tolerance=2.0e-4):
        difference = error(actual, expected)
        check(name, difference < tolerance, max_error=difference)

    try:
        scene = bpy.context.scene
        scene.name = '中心指定・専用数値検証'
        settings = scene.gyogan
        camera = bpy.data.objects.new('中心検証・正面カメラ', bpy.data.cameras.new('中心検証・カメラデータ'))
        scene.collection.objects.link(camera)
        camera.location = (0, -10, 2)
        camera.rotation_euler.x = math.pi / 2
        camera.data.lens = 28
        scene.camera = settings.camera = camera
        scene.render.resolution_x, scene.render.resolution_y = 1280, 720
        settings.subdivision = 'NONE'
        settings.strength = 1.0
        refresh(scene)
        grid = make_mesh(scene, '中心検証・格子',
                         [(x, y, .3*x) for y in (-1., 0., 1.) for x in (-2., 0., 2.)],
                         [(a, a+1, a+4, a+3) for a in (0, 1, 3, 4)])
        grid.matrix_world = camera.matrix_world @ Matrix.Translation((2, 0, -6))
        raw_grid = [tuple(vertex.co) for vertex in grid.data.vertices]
        original_grid = positions(scene, grid)
        grid_target = addon.setup_mesh(scene, grid)
        default_grid = positions(scene, grid)
        compare('unset_center_matches_frozen_v2_oracle', default_grid, reference(scene, original_grid, None))
        check('unset_is_default', settings.center_object is None)

        anchor = make_empty(scene, '中心検証・エンプティ', (2, 0, -6))
        anchor_base_users = anchor.users
        bpy.context.view_layer.objects.active = grid
        grid.select_set(True)
        selected_before = {obj.name for obj in bpy.context.selected_objects}
        active_before = bpy.context.view_layer.objects.active
        settings.center_object = anchor
        compare('mesh_center_numeric_projection', positions(scene, grid), reference(scene, original_grid, anchor))
        frame = camera.data.view_frame(scene=scene)
        half_width = (max(v.x / -v.z for v in frame) - min(v.x / -v.z for v in frame)) / 2
        inverse = camera.matrix_world.normalized().inverted()
        center_point = inverse @ anchor.matrix_world.translation
        pure_result = [camera.matrix_world.normalized() @ Vector(addon.nodes.camera_space_reference(
            inverse @ point, settings.strength, settings.fov, settings.zoom,
            settings.near_distance, half_width, center_point=center_point)) for point in original_grid]
        compare('new_pure_oracle_matches_independent_recenter_composition', pure_result, reference(scene, original_grid, anchor), 1.0e-6)
        compare('mesh_center_origin_is_fixed', [positions(scene, grid)[4]], [original_grid[4]])
        inverse = camera.matrix_world.normalized().inverted()
        depth_error = max(abs((inverse @ p).z - (inverse @ q).z)
                          for p, q in zip(original_grid, positions(scene, grid)))
        check('mesh_depth_preserved', depth_error < 1.0e-5, max_error=depth_error)
        before_move = positions(scene, grid)
        anchor.location += Vector((.8, .1, .4))
        moved = positions(scene, grid)
        compare('empty_transform_live_without_frame_step', moved, reference(scene, original_grid, anchor))
        check('empty_move_changes_deformation', error(moved, before_move) > .01)
        replacement = make_empty(scene, '中心検証・交換先', (-1, 1, -8))
        replacement_base_users = replacement.users
        group_id = grid_target.node_group.as_pointer()
        settings.center_object = replacement
        check('replaced_center_user_count_balanced', anchor.users == anchor_base_users,
              actual=anchor.users, expected=anchor_base_users)
        compare('center_pointer_replacement_live', positions(scene, grid), reference(scene, original_grid, replacement))
        check('pointer_replacement_preserves_group_id', grid_target.node_group.as_pointer() == group_id)
        settings.center_object = None
        check('cleared_center_user_count_balanced', replacement.users == replacement_base_users,
              actual=replacement.users, expected=replacement_base_users)
        compare('cleared_center_restores_exact_optical_axis', positions(scene, grid), default_grid, 1.0e-7)
        settings.center_object = replacement
        bpy.data.objects.remove(replacement, do_unlink=True)
        compare('deleted_center_restores_optical_axis', positions(scene, grid), default_grid, 1.0e-7)
        check('deleted_center_clears_scene_pointer', settings.center_object is None)
        for label, coordinates in (('camera_plane', (2, 1, 0)), ('behind_camera', (2, 1, 2)),
                                   ('inside_near_guard', (2, 1, -.5*settings.near_distance))):
            anchor.location = camera.matrix_world @ Vector(coordinates)
            settings.center_object = anchor
            compare('invalid_center_' + label + '_uses_axis', positions(scene, grid), default_grid, 1.0e-7)
        anchor.location = camera.matrix_world @ Vector((.02, .01, -1.5*settings.near_distance))
        compare('center_near_fade_matches_independent_oracle', positions(scene, grid), reference(scene, original_grid, anchor))
        settings.center_object = grid
        compare('source_mesh_own_origin_numeric_projection', positions(scene, grid), reference(scene, original_grid, grid))
        compare('source_mesh_own_origin_stays_fixed', [positions(scene, grid)[4]], [original_grid[4]])
        saved_grid_matrix = grid.matrix_world.copy()
        grid.location.x += .7
        compare('source_mesh_own_origin_moves_live', positions(scene, grid), reference(scene, source_world(scene, grid), grid))
        grid.matrix_world = saved_grid_matrix
        settings.strength = 0
        compare('mesh_center_strength_zero_restores', positions(scene, grid), original_grid, 1.0e-6)
        settings.strength = 2.5
        compare('center_with_extended_strength', positions(scene, grid), reference(scene, original_grid, grid))
        settings.enabled = False
        compare('mesh_center_preview_off_restores', positions(scene, grid), original_grid, 1.0e-6)
        settings.enabled = True
        check('center_changes_preserve_selection', selected_before == {obj.name for obj in bpy.context.selected_objects}
              and bpy.context.view_layer.objects.active == active_before)
        check('mesh_original_vertex_data_untouched', raw_grid == [tuple(vertex.co) for vertex in grid.data.vertices])

        # Numeric two-bone cylinder only: no procedural character or user asset.
        settings.strength = 1.0
        rig, body = make_rig(scene)
        raw_body = [tuple(vertex.co) for vertex in body.data.vertices]
        original_skin = positions(scene, body)
        original_pose = bone_points(scene, rig)
        rig_target = addon.setup_armature(scene, rig)
        output = rig_target.outputs[0].output
        compare('armature_center_heads_tails_match_oracle', bone_points(scene, rig_target.output_rig), reference(scene, original_pose, grid))
        settings.strength = 0
        compare('armature_center_strength_zero_matches_source', positions(scene, output), original_skin)
        settings.strength = 1
        settings.center_object = None
        default_skin = positions(scene, output)
        settings.center_object = anchor
        anchor.parent = rig
        anchor.parent_type = 'BONE'
        anchor.parent_bone = '根元'
        anchor.location = (.2, .1, 0)
        check('original_bone_parented_empty_is_accepted', addon.center_poll(settings, anchor))
        before_pose = positions(scene, output)
        rig.pose.bones['根元'].rotation_euler.z += .3
        compare('bone_parented_center_tracks_source_pose', bone_points(scene, rig_target.output_rig), reference(scene, bone_points(scene, rig), anchor))
        check('bone_parented_center_updates_skin', error(positions(scene, output), before_pose) > .01)
        source_skin_before_center_change = positions(scene, body)
        settings.center_object = None
        compare('source_skin_unmodified_by_center', positions(scene, body), source_skin_before_center_change)
        settings.center_object = anchor
        check('source_raw_mesh_and_shared_output_preserved', output.data == body.data and raw_body == [tuple(vertex.co) for vertex in body.data.vertices])
        check('generated_output_center_is_rejected_by_poll', not addon.center_poll(settings, output)
              and not addon.center_poll(settings, rig_target.output_rig))
        settings.center_object = output
        check('generated_output_center_is_cleared_by_update', settings.center_object is None)
        dangerous = rig.pose.bones['根元'].constraints.new('COPY_TRANSFORMS')
        dangerous.target = output
        try:
            check('center_original_bone_indirect_generated_dependency_rejected', not addon.center_poll(settings, anchor))
            check('rig_origin_ignores_unrelated_pose_constraints', addon.center_poll(settings, rig))
        finally:
            rig.pose.bones['根元'].constraints.remove(dangerous)
        compare('rejected_center_leaves_mesh_on_axis', positions(scene, grid), reference(scene, original_grid, None))
        check('center_rejection_did_not_change_source_pose', abs(rig.pose.bones['根元'].rotation_euler.z - .42) < 1.0e-6)

        # Build exact pre-center v2 topology from the frozen module, then verify
        # in-place upgrades without swapping modifiers or their group IDs.
        legacy_grid = make_mesh(scene, '中心検証・旧版格子', [tuple(v.co) for v in grid.data.vertices],
                                [tuple(p.vertices) for p in grid.data.polygons])
        legacy_grid.matrix_world = grid.matrix_world.copy()
        current_builder = addon.nodes.build_mesh_group
        addon.nodes.build_mesh_group = legacy.build_mesh_group
        try:
            legacy_target = addon.setup_mesh(scene, legacy_grid)
        finally:
            addon.nodes.build_mesh_group = current_builder
        legacy_tree = legacy_target.node_group
        legacy_arm_tree = legacy_armature_warp(scene, rig_target)
        check('legacy_v2_fixture_has_no_center_nodes', legacy_tree.get('gyogan_projection_version') == 2
              and not legacy_tree.get('gyogan_center_version') and not legacy_arm_tree.get('gyogan_center_version'))
        legacy_mesh_base = positions(scene, legacy_grid)
        legacy_skin_base = positions(scene, output)
        group_ids = [tree.as_pointer() for tree in (legacy_tree, legacy_arm_tree)]
        node_ids = [{node.as_pointer() for node in tree.nodes} for tree in (legacy_tree, legacy_arm_tree)]
        modifier_uid = legacy_grid.modifiers[-1].persistent_uid
        for tree in (legacy_tree, legacy_arm_tree):
            addon.nodes.upgrade_center_group(tree, scene)
        check('legacy_center_upgrade_preserves_ids_and_projection_v2',
              group_ids == [tree.as_pointer() for tree in (legacy_tree, legacy_arm_tree)]
              and all(original.issubset({node.as_pointer() for node in tree.nodes})
                      for original, tree in zip(node_ids, (legacy_tree, legacy_arm_tree)))
              and legacy_grid.modifiers[-1].persistent_uid == modifier_uid
              and all(tree.get('gyogan_projection_version') == 2 and tree.get('gyogan_center_version') == 1
                      for tree in (legacy_tree, legacy_arm_tree)))
        compare('legacy_mesh_upgrade_null_baseline_exact', positions(scene, legacy_grid), legacy_mesh_base, 1.0e-7)
        compare('legacy_armature_upgrade_null_baseline_exact', positions(scene, output), legacy_skin_base, 1.0e-7)
        counts = [len(tree.nodes) for tree in (legacy_tree, legacy_arm_tree)]
        for tree in (legacy_tree, legacy_arm_tree):
            addon.nodes.upgrade_center_group(tree, scene)
        check('legacy_center_upgrade_is_idempotent', counts == [len(tree.nodes) for tree in (legacy_tree, legacy_arm_tree)])
        settings.center_object = anchor
        compare('upgraded_legacy_mesh_uses_center', positions(scene, legacy_grid), reference(scene, original_grid, anchor))
        compare('upgraded_legacy_armature_uses_center', bone_points(scene, rig_target.output_rig), reference(scene, bone_points(scene, rig), anchor))

        # Persist real old-v2 mesh and armature graphs, then exercise load_post.
        settings.center_object = None
        old_mesh_group = legacy.build_mesh_group('中心検証・保存する旧版格子', scene)
        old_mesh_group[addon.OWNER] = legacy_target.token
        replaced = legacy_target.node_group
        legacy_grid.modifiers[-1].node_group = old_mesh_group
        legacy_target.node_group = old_mesh_group
        if replaced.users == 0:
            bpy.data.node_groups.remove(replaced)
        old_arm_group = legacy_armature_warp(scene, rig_target)
        legacy_null = (positions(scene, legacy_grid), positions(scene, output))
        legacy_group_names = (old_mesh_group.name, old_arm_group.name)
        names = dict(grid=grid.name, rig=rig.name, body=body.name, output=output.name,
                     anchor=anchor.name, legacy_grid=legacy_grid.name)
        bpy.ops.wm.save_as_mainfile(filepath=str(LEGACY_FIXTURE), check_existing=False)
        bpy.ops.wm.open_mainfile(filepath=str(LEGACY_FIXTURE))
        scene, settings = bpy.context.scene, bpy.context.scene.gyogan
        grid, rig, body, output, anchor, legacy_grid = [bpy.data.objects[names[key]]
                                                     for key in ('grid', 'rig', 'body', 'output', 'anchor', 'legacy_grid')]
        loaded_legacy_groups = [bpy.data.node_groups[name] for name in legacy_group_names]
        check('saved_legacy_v2_graphs_upgraded_on_load',
              all(tree.get('gyogan_center_version') == 1 and tree.get('gyogan_projection_version') == 2
                  for tree in loaded_legacy_groups)
              and legacy_grid.modifiers[-1].persistent_uid == modifier_uid)
        compare('saved_legacy_mesh_null_baseline_exact', positions(scene, legacy_grid), legacy_null[0], 1.0e-7)
        compare('saved_legacy_armature_null_baseline_exact', positions(scene, output), legacy_null[1], 1.0e-7)
        settings.center_object = anchor

        # Animated Empty + original bone drive both modes after save/reopen.
        for frame, local_x, angle in ((1, .2, .1), (8, 1.1, .6)):
            anchor.location.x = local_x
            anchor.keyframe_insert('location', frame=frame)
            rig.pose.bones['根元'].rotation_euler.z = angle
            rig.pose.bones['根元'].keyframe_insert('rotation_euler', frame=frame)
        before_save = {}
        for frame in (1, 8, 4):
            scene.frame_set(frame)
            before_save[frame] = (positions(scene, grid), positions(scene, output))
        names = dict(grid=grid.name, rig=rig.name, body=body.name, output=output.name,
                     anchor=anchor.name, legacy_grid=legacy_grid.name)
        scene.frame_set(1)
        bpy.ops.wm.save_as_mainfile(filepath=str(FIXTURE), check_existing=False)
        bpy.ops.wm.open_mainfile(filepath=str(FIXTURE))
        scene, settings = bpy.context.scene, bpy.context.scene.gyogan
        grid, rig, body, output, anchor, legacy_grid = [bpy.data.objects[names[key]]
                                                     for key in ('grid', 'rig', 'body', 'output', 'anchor', 'legacy_grid')]
        check('save_open_preserves_animated_center_reference', settings.center_object == anchor
              and anchor.parent == rig and anchor.parent_type == 'BONE')
        for frame in (8, 1, 4):
            scene.frame_set(frame)
            compare('saved_center_mesh_frame_' + str(frame), positions(scene, grid), before_save[frame][0])
            compare('saved_center_armature_frame_' + str(frame), positions(scene, output), before_save[frame][1])
        settings.center_object = None
        null_before_save = (positions(scene, grid), positions(scene, output))
        bpy.ops.wm.save_as_mainfile(filepath=str(FIXTURE), check_existing=False)
        bpy.ops.wm.open_mainfile(filepath=str(FIXTURE))
        scene, settings = bpy.context.scene, bpy.context.scene.gyogan
        grid, rig, body, output = [bpy.data.objects[names[key]] for key in ('grid', 'rig', 'body', 'output')]
        check('save_open_preserves_unset_center', settings.center_object is None)
        compare('saved_unset_center_mesh_exact', positions(scene, grid), null_before_save[0], 1.0e-7)
        compare('saved_unset_center_armature_exact', positions(scene, output), null_before_save[1], 1.0e-7)
        settings.enabled = False
        compare('saved_center_preview_off_restores_mesh', positions(scene, grid), original_grid, 1.0e-6)
        check('saved_center_preview_off_restores_source_visibility', not body.hide_get() and not body.hide_render
              and output.hide_get() and output.hide_render)
        tokens = {target.token for target in settings.targets}
        while settings.targets:
            addon.remove_target(scene, len(settings.targets) - 1)
        leftovers = [block.name for kind in ('objects', 'meshes', 'armatures', 'node_groups', 'collections')
                     for block in getattr(bpy.data, kind) if block.get(addon.OWNER) in tokens]
        check('center_remove_restores_without_owned_leftovers', not leftovers and not grid.modifiers
              and len(body.modifiers) == 1 and body.modifiers[0].object == rig, leftovers=leftovers)
        check('center_save_restore_original_raw_data_unchanged', raw_grid == [tuple(v.co) for v in grid.data.vertices]
              and raw_body == [tuple(v.co) for v in body.data.vertices])
        anchor = bpy.data.objects[names['anchor']]
        lifecycle_users = anchor.users
        settings.enabled = True
        for cycle in range(2):
            settings.center_object = anchor
            addon.setup_mesh(scene, grid)
            addon.remove_target(scene, 0)
            addon.setup_armature(scene, rig)
            addon.remove_target(scene, 0)
            settings.center_object = None
            check('center_mesh_remove_armature_reregister_users_' + str(cycle),
                  anchor.users == lifecycle_users and not settings.targets,
                  actual=anchor.users, expected=lifecycle_users)
    except Exception:
        exception = traceback.format_exc()
        print(exception)
    finally:
        passed = bool(checks) and all(item['passed'] for item in checks) and exception is None
        report = dict(blender=bpy.app.version_string, passed=passed, checks=checks, exception=exception)
        REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        print('GYOGAN_CENTER_RESULTS=' + json.dumps(report, ensure_ascii=False))
    if not passed:
        raise AssertionError('中心指定の検証に失敗しました: ' + str(REPORT))


if __name__ == '__main__':
    run()
