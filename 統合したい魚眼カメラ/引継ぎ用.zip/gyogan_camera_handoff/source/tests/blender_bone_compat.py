"""Exercise native and Blender 5.0 RNA-driver bone reads in isolation.

Run in a separate --background --factory-startup process, never a user scene.
The matrix comparison includes evaluated IK, a nonuniform object transform,
nonsequential frames, interactive changes, and saved-file driver evaluation.
"""

import json
import sys
import traceback
from pathlib import Path

import bpy

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
from test_paths import output_path
sys.path.insert(0, str(ROOT))
from gyogan_camera.armature import _bone_pose, _is_original_bone_pose
from gyogan_camera.nodes import Graph

REPORT = output_path('bone_compat_result.json')
FIXTURE = output_path('bone_compat_fixture.blend')


def run():
    checks, exception = [], None

    def check(name, condition, **details):
        checks.append(dict(test=name, passed=bool(condition), **details))
        if not condition:
            raise AssertionError(f'{name}: {details}')

    def make_rig(scene, name, connected):
        data = bpy.data.armatures.new(name)
        rig = bpy.data.objects.new(name, data)
        scene.collection.objects.link(rig)
        bpy.context.view_layer.objects.active = rig
        rig.select_set(True)
        bpy.ops.object.mode_set(mode='EDIT')
        root = data.edit_bones.new('根元')
        root.head, root.tail = (0, 0, 0), (0, 1, 0)
        # Quotes and backslashes also exercise RNA path escaping.
        tip = data.edit_bones.new('先端 "名前" \\')
        tip.head, tip.tail = (0, 1, 0), (0, 2, 0)
        if connected:
            tip.parent, tip.use_connect = root, True
        bpy.ops.object.mode_set(mode='OBJECT')
        rig.select_set(False)
        return rig

    def compare(case):
        scene = bpy.context.scene
        bpy.context.view_layer.update()
        graph = bpy.context.evaluated_depsgraph_get()
        source = bpy.data.objects['元リグ'].evaluated_get(graph)
        output = bpy.data.objects['出力リグ'].evaluated_get(graph)
        differences = []
        for bone in source.pose.bones:
            expected = source.matrix_world @ bone.matrix
            actual = output.matrix_world @ output.pose.bones[bone.name].matrix
            differences.append(max(abs(expected[row][column] - actual[row][column])
                                   for row in range(4) for column in range(4)))
        check(case, max(differences) < 3.0e-5,
              max_error=max(differences), frame=scene.frame_current)
        tree = bpy.data.node_groups['ボーン互換検証']
        drivers = tree.animation_data.drivers if tree.animation_data else ()
        check(case + '_drivers_valid', all(curve.driver.is_valid for curve in drivers))

    try:
        scene = bpy.context.scene
        source = make_rig(scene, '元リグ', True)
        output = make_rig(scene, '出力リグ', False)
        source.location = (3, 2, 1)
        source.rotation_euler = (.2, .3, .4)
        source.scale = (1.5, .8, 1.2)
        target = bpy.data.objects.new('IK の目標', None)
        scene.collection.objects.link(target)
        tip = source.pose.bones[1]
        constraint = tip.constraints.new('IK')
        constraint.target, constraint.chain_count = target, 2
        for frame, position in ((1, (3, 3.2, 1)), (10, (2.5, 3, 1.5))):
            target.location = position
            target.keyframe_insert('location', frame=frame)
        source.pose.bones[0].scale = (1.1, .85, 1.25)
        original_rest = {bone.name: [list(row) for row in bone.matrix_local]
                         for bone in source.data.bones}

        mesh = bpy.data.meshes.new('計算用')
        mesh.from_pydata([(0, 0, 0)], [], [])
        calculator = bpy.data.objects.new('計算用', mesh)
        scene.collection.objects.link(calculator)
        tree = bpy.data.node_groups.new('ボーン互換検証', 'GeometryNodeTree')
        tree.interface.new_socket(name='Geometry', in_out='INPUT', socket_type='NodeSocketGeometry')
        tree.interface.new_socket(name='Geometry', in_out='OUTPUT', socket_type='NodeSocketGeometry')
        graph = Graph(tree)
        geometry = graph.node('NodeGroupInput').outputs['Geometry']
        for index, bone in enumerate(source.data.bones):
            pose = _bone_pose(graph, source, bone)
            check('reader_recognized_' + str(index), _is_original_bone_pose(pose))
            store = graph.node('GeometryNodeStoreNamedAttribute')
            store.domain, store.data_type = 'POINT', 'FLOAT4X4'
            store.inputs['Name'].default_value = f'pose_{index}'
            graph.connect(geometry, store, 'Geometry')
            graph.connect(pose, store, 'Value')
            geometry = store.outputs['Geometry']
            constraint = output.pose.bones[bone.name].constraints.new('GEOMETRY_ATTRIBUTE')
            constraint.target = calculator
            constraint.data_type, constraint.domain = 'FLOAT4X4', 'POINT'
            constraint.attribute_name = f'pose_{index}'
            constraint.owner_space = constraint.target_space = 'WORLD'
            constraint.apply_target_transform = False
        graph.connect(geometry, graph.node('NodeGroupOutput'), 'Geometry')
        calculator.modifiers.new('計算', 'NODES').node_group = tree
        fallback = not hasattr(bpy.types, 'GeometryNodeBoneInfo')
        drivers = tree.animation_data.drivers if tree.animation_data else ()
        check('reader_backend', len(drivers) == (32 if fallback else 0),
              fallback=fallback, driver_count=len(drivers))
        for frame in (1, 10, 4, 1, 10):
            scene.frame_set(frame)
            compare('ik_frame_' + str(frame))
        target.location.x += .3
        compare('ik_target_live_change')
        source.location.x += .5
        compare('rig_live_change')
        source.pose.bones[0].scale = (1.2, .9, .7)
        source.update_tag()
        compare('pose_live_change')

        bpy.ops.wm.save_as_mainfile(filepath=str(FIXTURE), check_existing=False)
        bpy.ops.wm.open_mainfile(filepath=str(FIXTURE))
        for frame in (10, 1, 4):
            bpy.context.scene.frame_set(frame)
            compare('saved_ik_frame_' + str(frame))
        source = bpy.data.objects['元リグ']
        check('source_rest_unchanged', original_rest == {
            bone.name: [list(row) for row in bone.matrix_local]
            for bone in source.data.bones})
        check('source_constraints_unchanged', len(source.pose.bones[1].constraints) == 1
              and source.pose.bones[1].constraints[0].type == 'IK')
        check('source_no_added_drivers', not source.animation_data
              or not source.animation_data.drivers)
    except Exception:
        exception = traceback.format_exc()
        print(exception)
    passed = bool(checks) and all(item['passed'] for item in checks) and exception is None
    report = dict(blender=bpy.app.version_string, passed=passed,
                  checks=checks, exception=exception)
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print('GYOGAN_BONE_COMPAT_RESULTS=' + json.dumps(report, ensure_ascii=False))
    if not passed:
        raise AssertionError('ボーン互換性の検証に失敗しました: ' + str(REPORT))


if __name__ == '__main__':
    run()
