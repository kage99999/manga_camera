"""Signed-strength regressions in an isolated Blender 5.2 background process.

Run with --background --factory-startup --python-exit-code 1 --python this_file.
Uses only a numeric grid and a two-bone cylinder; never run through live MCP.
"""

import json
import math
import sys
import traceback
from pathlib import Path

import bpy
from mathutils import Matrix, Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
from test_paths import output_path
REPORT = output_path('negative_result.json')
FIXTURE = output_path('negative_fixture.blend')
LEGACY_FIXTURE = output_path('negative_legacy_fixture.blend')
sys.dont_write_bytecode = True
from blender_center import (addon, legacy, refresh, positions, error, make_mesh,
                            make_empty, make_rig, bone_points, legacy_armature_warp)


def expected(scene, points, center):
    """Independent stated signed formula, with frozen v2 for the positive half."""
    settings = scene.gyogan
    graph = refresh(scene)
    camera = scene.camera.evaluated_get(graph)
    matrix = camera.matrix_world.normalized()
    inverse = matrix.inverted()
    anchor = inverse @ center.evaluated_get(graph).matrix_world.translation if center else None
    frame = camera.data.view_frame(scene=scene)
    half_width = (max(v.x / -v.z for v in frame) - min(v.x / -v.z for v in frame)) / 2
    k = 2 * half_width * settings.zoom / settings.fov
    near, strength = settings.near_distance, settings.strength
    result = []
    for world_point in points:
        point = inverse @ world_point
        offset = Vector((0., 0., 0.))
        if anchor is not None and -anchor.z > near:
            fade = min(1., max(0., (-anchor.z - near) / near))
            fade = fade * fade * (3 - 2 * fade)
            offset = Vector((-point.z * anchor.x / -anchor.z * fade,
                             -point.z * anchor.y / -anchor.z * fade, 0.))
        centered = point - offset
        if strength >= 0:
            answer = Vector(legacy.camera_space_reference(
                centered, strength, settings.fov, settings.zoom, near, half_width)) + offset
        else:
            depth = -point.z
            fade = min(1., max(0., (depth - near) / near))
            weight = min(abs(strength), 1.) * fade * fade * (3 - 2 * fade)
            rho = math.hypot(centered.x, centered.y) / max(depth, 1.0e-8)
            ratio = math.atan(rho) / rho if rho > 1.0e-8 else 1.
            scale = k * (1 + max(abs(strength), 1.) * (1 - ratio))
            answer = centered.lerp(Vector((centered.x * scale, centered.y * scale, centered.z)), weight) + offset
        result.append(matrix @ answer)
    return result


def optical_radii(scene, points, center):
    graph = refresh(scene)
    inverse = scene.camera.evaluated_get(graph).matrix_world.normalized().inverted()
    anchor = inverse @ center.evaluated_get(graph).matrix_world.translation
    result = []
    for point in points:
        p = inverse @ point
        offset = Vector((-p.z * anchor.x / -anchor.z, -p.z * anchor.y / -anchor.z, 0.))
        result.append(math.hypot(p.x - offset.x, p.y - offset.y))
    return result


def legacy_gate(tree):
    """Restore the actual pre-signed strength>0 matrix gate, keeping its IDs."""
    driver_paths = {curve.data_path for curve in tree.animation_data.drivers
                    if any(target.data_path.endswith('.strength')
                           for variable in curve.driver.variables for target in variable.targets)}
    source = next(node.outputs[0] for node in tree.nodes
                  if node.bl_idname == 'ShaderNodeValue'
                  and node.outputs[0].path_from_id('default_value') in driver_paths)
    obsolete = set()
    for node in tree.nodes:
        if node.bl_idname != 'GeometryNodeSwitch' or node.input_type != 'MATRIX':
            continue
        gate = node.inputs['Switch'].links[0].from_node
        old = gate.inputs[0].links[0].from_node
        if old.bl_idname == 'ShaderNodeMath' and old.operation == 'ABSOLUTE':
            obsolete.add(old)
        tree.links.new(source, gate.inputs[0])
    for node in obsolete:
        if not any(output.is_linked for output in node.outputs):
            tree.nodes.remove(node)
    if 'gyogan_signed_version' in tree:
        del tree['gyogan_signed_version']
    tree.update_tag()


def replace_legacy_mesh(scene, target):
    tree = legacy.build_mesh_group('負強度検証・旧版メッシュ', scene)
    tree[addon.OWNER] = target.token
    addon.nodes.upgrade_center_group(tree, scene)
    previous = target.node_group
    modifier = next(addon.find_modifier(target.source, record) for record in target.modifiers
                    if record.kind == 'NODES')
    modifier.node_group = tree
    target.node_group = tree
    if previous.users == 0:
        bpy.data.node_groups.remove(previous)
    return tree


def run():
    if not bpy.app.background:
        raise RuntimeError('負強度の検証は専用のバックグラウンドプロセスで実行してください')
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if not hasattr(bpy.types.Scene, 'gyogan'):
        addon.register()
    checks, exception = [], None

    def check(name, condition, **details):
        checks.append(dict(test=name, passed=bool(condition), **details))

    def compare(name, actual, reference, tolerance=3.0e-4):
        difference = error(actual, reference)
        check(name, difference < tolerance, max_error=difference)

    try:
        scene = bpy.context.scene
        scene.name = '負強度・専用数値検証'
        settings = scene.gyogan
        camera = bpy.data.objects.new('負強度検証・正面カメラ', bpy.data.cameras.new('負強度検証・カメラデータ'))
        scene.collection.objects.link(camera)
        camera.location = (0, -10, 2)
        camera.rotation_euler.x = math.pi / 2
        camera.data.lens = 28
        scene.camera = settings.camera = camera
        scene.render.resolution_x, scene.render.resolution_y = 1280, 720
        settings.subdivision = 'NONE'
        refresh(scene)
        radii = (0., .5, 1., 2., 4., 8., 12.)
        count = len(radii)
        grid = make_mesh(scene, '負強度検証・放射格子',
                         [(radius, y, 0.) for y in (0., 1.) for radius in radii],
                         [(i, i+1, i+count+1, i+count) for i in range(count-1)])
        grid.matrix_world = camera.matrix_world @ Matrix.Translation((1.5, .5, -6))
        anchor = make_empty(scene, '負強度検証・中心', (1.5, .5, -6))
        settings.center_object = anchor
        raw_grid = [tuple(v.co) for v in grid.data.vertices]
        original_grid = positions(scene, grid)
        target = addon.setup_mesh(scene, grid)
        positive = {}
        for strength in (0., .5, 1., 2.5, 5.):
            settings.strength = strength
            positive[strength] = positions(scene, grid)
            compare('positive_unchanged_' + str(strength), positive[strength], expected(scene, original_grid, anchor))
        for strength in (-.5, -1., -5.):
            settings.strength = strength
            actual = positions(scene, grid)
            compare('negative_mesh_formula_' + str(strength), actual, expected(scene, original_grid, anchor))
            compare('negative_center_stays_fixed_' + str(strength), actual[:1], original_grid[:1], 1.0e-5)
            inverse = camera.matrix_world.normalized().inverted()
            depth_error = max(abs((inverse @ a).z - (inverse @ b).z) for a, b in zip(actual, original_grid))
            check('negative_depth_finite_' + str(strength), depth_error < 1.0e-5
                  and all(math.isfinite(v) for point in actual for v in point), max_error=depth_error)
            radial = optical_radii(scene, actual[:count], anchor)
            original_radial = optical_radii(scene, original_grid[:count], anchor)
            matching_positive = optical_radii(scene, positive[abs(strength)][:count], anchor)
            check('negative_expands_relative_to_positive_' + str(strength),
                  all(a > b + 1.0e-4 for a, b in zip(radial[1:], matching_positive[1:])))
            check('negative_radial_order_no_flip_' + str(strength),
                  all(a < b for a, b in zip(radial, radial[1:])))
            scale_ratios = [r / original for r, original in zip(radial[1:], original_radial[1:])]
            check('negative_peripheral_scale_increases_' + str(strength),
                  all(a < b for a, b in zip(scale_ratios, scale_ratios[1:])))
        settings.strength = 0
        compare('negative_to_zero_restores_mesh', positions(scene, grid), original_grid, 1.0e-6)
        settings.strength = -5
        settings.enabled = False
        compare('negative_preview_off_restores_mesh', positions(scene, grid), original_grid, 1.0e-6)
        settings.enabled = True
        settings.center_object = None
        compare('negative_cleared_center_uses_optical_axis', positions(scene, grid), expected(scene, original_grid, None))
        settings.center_object = anchor

        rig, body = make_rig(scene)
        raw_body = [tuple(v.co) for v in body.data.vertices]
        source_skin = positions(scene, body)
        source_pose = bone_points(scene, rig)
        source_matrices = {bone.name: tuple(tuple(row) for row in bone.matrix_basis) for bone in rig.pose.bones}
        rig_target = addon.setup_armature(scene, rig)
        output = rig_target.outputs[0].output
        check('new_armature_signed_gate_marker', rig_target.node_group.get('gyogan_signed_version') == 1
              and any(node.get('gyogan_role') == 'signed_gate' for node in rig_target.node_group.nodes))
        for strength in (-.5, -1., -5.):
            settings.strength = strength
            compare('negative_armature_heads_tails_' + str(strength), bone_points(scene, rig_target.output_rig), expected(scene, source_pose, anchor))
            check('negative_armature_gate_deforms_skin_' + str(strength), error(positions(scene, output), source_skin) > .01)
        compare('negative_preserves_source_skin', positions(scene, body), source_skin, 1.0e-6)
        settings.strength = 0
        compare('negative_to_zero_restores_armature', positions(scene, output), source_skin)
        check('negative_preserves_source_pose_and_raw_data', raw_grid == [tuple(v.co) for v in grid.data.vertices]
              and raw_body == [tuple(v.co) for v in body.data.vertices]
              and source_matrices == {bone.name: tuple(tuple(row) for row in bone.matrix_basis) for bone in rig.pose.bones})

        # Actual pre-signed leaves plus the old rig gate; upgrading leaves alone
        # must not conceal the separate armature identity-gate regression.
        old_mesh = replace_legacy_mesh(scene, target)
        old_leaf = legacy_armature_warp(scene, rig_target)
        addon.nodes.upgrade_center_group(old_leaf, scene)
        legacy_gate(rig_target.node_group)
        pre_signed_positive = {}
        for strength in (0., .5, 1., 2.5, 5.):
            settings.strength = strength
            pre_signed_positive[strength] = (positions(scene, grid), positions(scene, output))
        settings.strength = -1
        compare('legacy_negative_mesh_was_identity', positions(scene, grid), original_grid, 1.0e-6)
        compare('legacy_negative_armature_gate_was_identity', positions(scene, output), source_skin)
        trees = (old_mesh, old_leaf, rig_target.node_group)
        tree_ids = [tree.as_pointer() for tree in trees]
        node_ids = [{node.as_pointer() for node in tree.nodes} for tree in trees]
        modifier_uid = grid.modifiers[-1].persistent_uid
        output_id, output_data_id = output.as_pointer(), output.data.as_pointer()
        addon.nodes.upgrade_signed_group(old_mesh, scene)
        addon.nodes.upgrade_signed_group(old_leaf, scene)
        check('core_upgrade_deforms_negative_mesh', error(positions(scene, grid), original_grid) > .01)
        compare('old_armature_gate_still_blocks_signed_leaf', positions(scene, output), source_skin)
        addon.armature.upgrade_signed_group(rig_target.node_group)
        compare('armature_gate_upgrade_enables_negative_pose', bone_points(scene, rig_target.output_rig), expected(scene, source_pose, anchor))
        check('signed_upgrade_preserves_owned_ids_and_sources',
              tree_ids == [tree.as_pointer() for tree in trees]
              and all(saved.issubset({node.as_pointer() for node in tree.nodes}) for saved, tree in zip(node_ids, trees))
              and grid.modifiers[-1].persistent_uid == modifier_uid
              and output.as_pointer() == output_id and output.data.as_pointer() == output_data_id
              and body.modifiers[0].object == rig
              and all(tree.get('gyogan_signed_version') == 1 for tree in trees))
        sizes = [len(tree.nodes) for tree in trees]
        addon.nodes.upgrade_signed_group(old_mesh, scene)
        addon.nodes.upgrade_signed_group(old_leaf, scene)
        addon.armature.upgrade_signed_group(rig_target.node_group)
        check('signed_upgrade_idempotent', sizes == [len(tree.nodes) for tree in trees])
        for strength, (mesh_before, skin_before) in pre_signed_positive.items():
            settings.strength = strength
            compare('signed_upgrade_preserves_positive_mesh_' + str(strength), positions(scene, grid), mesh_before, 1.0e-7)
            compare('signed_upgrade_preserves_positive_armature_' + str(strength), positions(scene, output), skin_before, 1.0e-7)

        # Save genuine pre-signed topology and let the registered load handler
        # migrate the leaf graphs and the calculator gate together.
        old_mesh = replace_legacy_mesh(scene, target)
        old_leaf = legacy_armature_warp(scene, rig_target)
        addon.nodes.upgrade_center_group(old_leaf, scene)
        legacy_gate(rig_target.node_group)
        names = dict(grid=grid.name, rig=rig.name, body=body.name, output=output.name, anchor=anchor.name)
        group_names = [tree.name for tree in (old_mesh, old_leaf, rig_target.node_group)]
        settings.strength = -1
        bpy.ops.wm.save_as_mainfile(filepath=str(LEGACY_FIXTURE), check_existing=False)
        bpy.ops.wm.open_mainfile(filepath=str(LEGACY_FIXTURE))
        scene, settings = bpy.context.scene, bpy.context.scene.gyogan
        grid, rig, body, output, anchor = [bpy.data.objects[names[key]] for key in ('grid', 'rig', 'body', 'output', 'anchor')]
        rig_target = next(item for item in settings.targets if item.source == rig)
        check('saved_pre_signed_graphs_auto_upgrade',
              all(bpy.data.node_groups[name].get('gyogan_signed_version') == 1 for name in group_names)
              and grid.modifiers[-1].persistent_uid == modifier_uid and settings.strength == -1)
        compare('saved_legacy_negative_mesh_deforms', positions(scene, grid), expected(scene, original_grid, anchor))
        compare('saved_legacy_negative_armature_deforms', bone_points(scene, rig_target.output_rig), expected(scene, source_pose, anchor))

        for frame, strength, x, angle in ((1, 1., 1.5, .1), (5, -.5, 2., .3), (9, -5., .5, .5)):
            settings.strength = strength
            settings.keyframe_insert('strength', frame=frame)
            anchor.location.x = x
            anchor.keyframe_insert('location', frame=frame)
            rig.pose.bones['根元'].rotation_euler.z = angle
            rig.pose.bones['根元'].keyframe_insert('rotation_euler', frame=frame)
        animated = {}
        for frame in (1, 5, 7, 9):
            scene.frame_set(frame)
            animated[frame] = (positions(scene, grid), positions(scene, output), settings.strength)
        scene.frame_set(5)
        bpy.ops.wm.save_as_mainfile(filepath=str(FIXTURE), check_existing=False)
        bpy.ops.wm.open_mainfile(filepath=str(FIXTURE))
        scene, settings = bpy.context.scene, bpy.context.scene.gyogan
        grid, rig, body, output, anchor = [bpy.data.objects[names[key]] for key in ('grid', 'rig', 'body', 'output', 'anchor')]
        for frame in (9, 1, 7, 5):
            scene.frame_set(frame)
            compare('saved_signed_mesh_frame_' + str(frame), positions(scene, grid), animated[frame][0], 1.0e-7)
            compare('saved_signed_armature_frame_' + str(frame), positions(scene, output), animated[frame][1], 1.0e-7)
            check('saved_signed_setting_frame_' + str(frame), abs(settings.strength - animated[frame][2]) < 1.0e-7)
        settings.center_object = None
        scene.frame_set(9)
        compare('saved_negative_cleared_center_mesh', positions(scene, grid), expected(scene, original_grid, None))
        rig_target = next(item for item in settings.targets if item.source == rig)
        compare('saved_negative_cleared_center_armature', bone_points(scene, rig_target.output_rig), expected(scene, bone_points(scene, rig), None))
        settings.enabled = False
        compare('saved_negative_off_restores_mesh', positions(scene, grid), original_grid, 1.0e-6)
        check('saved_negative_off_restores_visibility', not body.hide_get() and not body.hide_render
              and output.hide_get() and output.hide_render)
        tokens = {item.token for item in settings.targets}
        while settings.targets:
            addon.remove_target(scene, len(settings.targets) - 1)
        leftovers = [block.name for kind in ('objects', 'meshes', 'armatures', 'node_groups', 'collections')
                     for block in getattr(bpy.data, kind) if block.get(addon.OWNER) in tokens]
        check('negative_cleanup_preserves_source_data', not leftovers and not grid.modifiers
              and raw_grid == [tuple(v.co) for v in grid.data.vertices]
              and raw_body == [tuple(v.co) for v in body.data.vertices]
              and len(body.modifiers) == 1 and body.modifiers[0].object == rig, leftovers=leftovers)
    except Exception:
        exception = traceback.format_exc()
        print(exception)
    finally:
        passed = bool(checks) and all(item['passed'] for item in checks) and exception is None
        report = dict(blender=bpy.app.version_string, passed=passed, checks=checks, exception=exception)
        REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        print('GYOGAN_NEGATIVE_RESULTS=' + json.dumps(report, ensure_ascii=False))
    if not passed:
        raise AssertionError('負強度の検証に失敗しました: ' + str(REPORT))


if __name__ == '__main__':
    run()
