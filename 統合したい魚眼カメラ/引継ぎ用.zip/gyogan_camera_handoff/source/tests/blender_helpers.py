"""Bounds cache lifecycle and collection ownership in an isolated Blender."""
import json
import math
import sys
import traceback
from pathlib import Path

import bpy

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
from test_paths import output_path
from blender_center import addon, error, make_rig, positions
from blender_targets import square, settle, record, select_only, identity


def helpers(scene):
    tokens = {t.token for t in scene.gyogan.targets}
    return [obj for obj in bpy.data.objects if obj.get(addon.OWNER) in tokens
            and obj.get('gyogan_role') in {'camera_bounds', 'camera_bounds_evaluator'}]


def run():
    if not bpy.app.background or '--factory-startup' not in sys.argv:
        raise RuntimeError('補助オブジェクトの検証は専用バックグラウンドで実行してください')
    bpy.ops.wm.read_factory_settings(use_empty=True)
    addon.register()
    checks, exception = [], None

    def check(name, condition):
        checks.append(dict(test=name, passed=bool(condition)))

    try:
        scene = bpy.context.scene
        settings = scene.gyogan
        camera = bpy.data.objects.new('補助検証・カメラ', bpy.data.cameras.new('カメラデータ'))
        scene.collection.objects.link(camera)
        camera.location = (0., -10., 0.)
        camera.rotation_euler = (math.pi / 2., 0., 0.)
        scene.camera = settings.camera = camera
        settings.subdivision = 'NONE'
        settings.effect_scope = 'MANUAL'
        grid = square(scene, '補助検証・板')
        grid.rotation_euler.x = math.pi / 2.
        grid.location.x = 1.
        material = bpy.data.materials.new('補助検証・材質')
        grid.data.materials.append(material)
        grid.material_slots[0].link = 'OBJECT'
        grid.material_slots[0].material = material
        raw = [tuple(v.co) for v in grid.data.vertices]
        original = positions(scene, grid)
        target = addon.setup_mesh(scene, grid)
        initial_identity = identity(target)
        settings.effect_scope = 'CAMERA'
        settle(scene)
        check('default_keeps_bounds_helpers', settings.keep_bounds_helpers and len(helpers(scene)) == 2)
        root = settings.helper_collection
        check('root_collection_name', root.name == '魚眼用補助オブジェクト')
        check('owned_collections_nested', target.collection.name in root.children
              and target.collection.name not in scene.collection.children)
        check('bounds_hidden_in_view_layers', all(target.bounds_object.hide_get(view_layer=layer)
              for layer in scene.view_layers))
        warped = positions(scene, grid)
        proxy_id = target.bounds_object.as_pointer()
        settings.enabled = False
        settle(scene)
        check('checked_off_reuses_same_proxy', target.bounds_object.as_pointer() == proxy_id)
        check('off_restores_original_shape', error(positions(scene, grid), original) < 1.e-6)

        settings.keep_bounds_helpers = False
        addon.targets._tick()
        check('uncheck_while_off_removes_helpers', not helpers(scene) and target.bounds_object is None)
        check('empty_root_removed', settings.helper_collection is None)
        check('off_keeps_deformation_setup', identity(target) == initial_identity)
        check('off_keeps_manual_registration', any(t.source == grid for t in settings.manual_targets))
        check('off_removes_only_evaluation_nodes', not any(
              block.get(addon.OWNER) == target.token and block != target.node_group
              for block in bpy.data.node_groups))
        check('original_material_and_data_preserved', grid.material_slots[0].material == material
              and raw == [tuple(v.co) for v in grid.data.vertices])
        for index in range(3):
            settings.enabled = True
            settle(scene)
            check('rebuild_on_' + str(index), len(helpers(scene)) == 2
                  and error(positions(scene, grid), warped) < 1.e-6)
            settings.enabled = False
            addon.targets._tick()
            check('cleanup_off_' + str(index), not helpers(scene))

        # A user collection with the requested name must not be adopted/deleted.
        user_collection = bpy.data.collections.new('魚眼用補助オブジェクト')
        scene.collection.children.link(user_collection)
        settings.enabled = True
        settle(scene)
        check('same_name_user_collection_not_adopted', settings.helper_collection != user_collection)
        settings.keep_bounds_helpers = True
        settle(scene)
        proxy_id = target.bounds_object.as_pointer()
        settings.keep_bounds_helpers = False
        addon.targets._tick()
        check('uncheck_while_on_defers_until_off', target.bounds_object.as_pointer() == proxy_id)

        # Old scene-level cache collections migrate; user-added objects survive.
        root = settings.helper_collection
        collection = target.collection
        root.children.unlink(collection)
        scene.collection.children.link(collection)
        settle(scene)
        check('old_cache_collection_migrates', collection.name in root.children
              and collection.name not in scene.collection.children)
        extra = bpy.data.objects.new('補助検証・ユーザー追加', None)
        collection.objects.link(extra)
        user_child = bpy.data.collections.new('補助検証・ユーザー子コレクション')
        root.children.link(user_child)
        settings.enabled = False
        settle(scene)
        check('user_objects_and_children_survive_off', extra.name in scene.objects
              and user_child.name in root.children and collection.name in root.children)
        check('same_name_user_collection_preserved', user_collection.name in scene.collection.children)
        settings.enabled = True
        settle(scene)
        select_only(grid)
        bpy.ops.object.mode_set(mode='EDIT')
        settings.enabled = False
        addon.targets._tick()
        check('edit_mode_defers_deletion', bool(helpers(scene)))
        bpy.ops.object.mode_set(mode='OBJECT')
        addon.targets._tick()
        check('object_mode_finishes_deletion', not helpers(scene))
        settings.enabled = True
        settle(scene)
        addon.targets._render_init(scene)
        settings.enabled = False
        addon.targets.reconcile(scene, prepare=True)
        check('render_defers_deletion', bool(helpers(scene)))
        addon.targets._render_done(scene)
        addon.targets._tick()
        check('render_end_finishes_deletion', not helpers(scene))

        # Native history with material overrides, then saved OFF state.
        settings.enabled = True
        settle(scene)
        bpy.ops.ed.undo_push(message='補助検証・ON')
        settings.enabled = False
        addon.targets._tick()
        bpy.ops.ed.undo_push(message='補助検証・OFF')
        bpy.ops.ed.undo()
        scene, settings = bpy.context.scene, bpy.context.scene.gyogan
        grid = scene.objects['補助検証・板']
        settle(scene)
        check('undo_on_restores_helpers', settings.enabled and len(helpers(scene)) == 2)
        check('undo_on_restores_geometry', error(positions(scene, grid), warped) < 1.e-6)
        bpy.ops.ed.redo()
        scene, settings = bpy.context.scene, bpy.context.scene.gyogan
        grid = scene.objects['補助検証・板']
        settle(scene)
        check('redo_off_removes_helpers', not settings.enabled and not helpers(scene))
        fixture = output_path('helpers_fixture.blend')
        bpy.ops.wm.save_as_mainfile(filepath=str(fixture))
        bpy.ops.wm.open_mainfile(filepath=str(fixture))
        scene, settings = bpy.context.scene, bpy.context.scene.gyogan
        grid = scene.objects['補助検証・板']
        settle(scene)
        check('saved_off_preference_retained', not settings.keep_bounds_helpers and not helpers(scene))
        settings.enabled = True
        settle(scene)
        check('saved_on_rebuilds_helpers', len(helpers(scene)) == 2)
        check('saved_material_override_valid', grid.material_slots[0].link == 'OBJECT'
              and grid.material_slots[0].material.name == '補助検証・材質')

        # Numeric armature fixture only, never a user work scene.
        settings.effect_scope = 'MANUAL'
        rig, skin = make_rig(scene)
        rig_target = addon.setup_armature(scene, rig)
        rig_identity = identity(rig_target)
        settings.mode = 'ARMATURE'
        settings.effect_scope = 'CAMERA'
        settle(scene)
        check('rig_helpers_nested', rig_target.collection.name in settings.helper_collection.children)
        check('skin_evaluator_created', any(obj.get(addon.OWNER) == rig_target.token for obj in helpers(scene)))
        settings.enabled = False
        settle(scene)
        check('skin_evaluators_removed', not helpers(scene))
        check('rig_output_retained_for_reuse', identity(rig_target) == rig_identity)
        check('source_skin_restored', not skin.hide_get() and not skin.hide_render)
        settings.enabled = True
        settle(scene)
        check('skin_evaluator_rebuilt', any(obj.get(addon.OWNER) == rig_target.token for obj in helpers(scene)))
        addon.presets.ensure(scene)
        preset = addon.presets.create(scene, duplicate=True)
        check('preference_not_saved_in_preset', 'keep_bounds_helpers' not in json.loads(preset.settings_json))
        settings.enabled = False
        while settings.targets:
            addon.remove_target(scene, len(settings.targets) - 1)
        check('full_removal_preserves_user_content', '補助検証・ユーザー追加' in scene.objects
              and '補助検証・ユーザー子コレクション' in bpy.data.collections)
        check('full_removal_preserves_sources', grid.name in scene.objects and rig.name in scene.objects
              and len(skin.modifiers) == 1 and skin.modifiers[0].object == rig)
    except Exception:
        exception = traceback.format_exc()
        print(exception)
    passed = bool(checks) and all(c['passed'] for c in checks) and exception is None
    report = dict(blender=bpy.app.version_string, passed=passed, checks=checks, exception=exception)
    output_path('helpers_result.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print('GYOGAN_HELPERS_RESULTS=' + json.dumps(report, ensure_ascii=False))
    if not passed:
        raise AssertionError('補助オブジェクトの検証に失敗しました')


if __name__ == '__main__':
    run()
