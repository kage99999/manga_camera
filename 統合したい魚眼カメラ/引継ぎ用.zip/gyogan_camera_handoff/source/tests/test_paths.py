"""Output locations shared by standalone Blender integration suites.

Fixture source code stays under tests/fixtures. Only generated files move when
the compatibility runner supplies GYOGAN_TEST_OUTPUT_DIR.
"""

import os
from pathlib import Path


def output_path(filename):
    directory = Path(os.environ.get('GYOGAN_TEST_OUTPUT_DIR') or Path(__file__).resolve().parent)
    directory.mkdir(parents=True, exist_ok=True)
    return directory / filename
