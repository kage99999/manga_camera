"""Reversible dolly-zoom regressions in an isolated Blender 5.2 process.

Run with --background --factory-startup --python-exit-code 1 --python this_file.
Camera projection is measured with Blender's evaluated camera, independently
of the dolly module. Only this process's generated numeric fixtures are saved.
"""

import json
import math
import sys
import traceback
from pathlib import Path

import bpy
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
from test_paths import output_path
REPORT = output_path('dolly_result.json')
FIXTURE = output_path('dolly_fixture.blend')
sys.dont_write_bytecode = True
from blender_center import addon, refresh, positions, error, make_mesh, make_rig, bone_points
from blender_ellipse import replace_legacy_armature


def evaluated_camera(scene, camera):
    return camera.evaluated_get(refresh(scene))


def projected_width(scene, camera, points):
    evaluated = evaluated_camera(scene, camera)
    screen = [world_to_camera_view(scene, evaluated, point) for point in points]
    return max(point.x for point in screen) - min(point.x for point in screen)


def driver_state(block):
    if not block.animation_data:
        return []
    return [(curve.data_path, curve.array_index, curve.driver.expression,
             [(variable.name, variable.type,
               [(target.id.name if target.id else None, target.data_path)
                for target in variable.targets]) for variable in curve.driver.variables])
            for curve in block.animation_data.drivers]


def expected_bones(scene, points):
    graph = refresh(scene)
    camera = scene.camera.evaluated_get(graph)
    matrix = camera.matrix_world.normalized()
    inverse = matrix.inverted()
    frame = camera.data.view_frame(scene=scene)
    half_width = (max(v.x / -v.z for v in frame) - min(v.x / -v.z for v in frame)) / 2.
    settings = scene.gyogan
    factor = scene.evaluated_get(graph).gyogan_dolly.factor
    return [matrix @ Vector(addon.nodes.camera_space_reference(
        inverse @ point, settings.strength, settings.fov, settings.zoom,
        settings.near_distance, half_width, ellipse_x=settings.ellipse_x,
        ellipse_y=settings.ellipse_y, dolly_factor=factor)) for point in points]


def run():
    if not bpy.app.background:
        raise RuntimeError('ドリーズームの検証は専用のバックグラウンドプロセスで実行してください')
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if not hasattr(bpy.types.Scene, 'gyogan'):
        addon.register()
    checks, exception = [], None

    def check(name, condition, **details):
        checks.append(dict(test=name, passed=bool(condition), **details))

    def near(name, actual, expected, tolerance=3.e-5):
        difference = abs(actual - expected)
        check(name, difference < tolerance, actual=actual, expected=expected, error=difference)

    def camera_matches(name, scene, camera, location, lens):
        evaluated = evaluated_camera(scene, camera)
        difference = (evaluated.matrix_world.translation - Vector(location)).length
        check(name, difference < 4.e-5 and abs(evaluated.data.lens - lens) < 4.e-5,
              location_error=difference, lens=evaluated.data.lens, expected_lens=lens)

    try:
        scene = bpy.context.scene
        scene.name = 'ドリーズーム・専用数値検証'
        settings, control = scene.gyogan, scene.gyogan_dolly
        camera = bpy.data.objects.new('ドリー検証・正面カメラ', bpy.data.cameras.new('ドリー検証・カメラデータ'))
        scene.collection.objects.link(camera)
        camera.location = (0., -10., 2.)
        camera.rotation_euler.x = math.pi / 2
        camera.data.lens = 28.
        camera.data.clip_start = .1
        scene.camera = settings.camera = camera
        scene.cursor.location = (0., 0., 2.)
        scene.render.resolution_x, scene.render.resolution_y = 1280, 720
        settings.subdivision = 'NONE'
        settings.near_distance = .05
        original_location = camera.location.copy()
        original_rotation = camera.rotation_euler.copy()
        original_lens = camera.data.lens
        plane = [Vector((-1., 0., 2.)), Vector((1., 0., 2.))]
        background = [Vector((-1., 10., 2.)), Vector((1., 10., 2.))]
        ordinary_width = projected_width(scene, camera, plane)
        background_width = projected_width(scene, camera, background)
        raw_points = [(-.01, 0., 2.), (.01, 0., 2.), (0., 0., 2.01),
                      (1., 0., 2.), (-1., 0., 2.), (1., 10., 2.)]
        mesh = make_mesh(scene, 'ドリー検証・点群', raw_points, [(0, 1, 2)])
        source_vertices = [tuple(vertex.co) for vertex in mesh.data.vertices]
        target = addon.setup_mesh(scene, mesh)
        modifier_uid = mesh.modifiers[-1].persistent_uid
        node_pointer = target.node_group.as_pointer()
        check('ratio_default_limits_and_animation', control.ratio == 1.
              and abs(control.bl_rna.properties['ratio'].hard_min - .1) < 1.e-6
              and control.bl_rna.properties['ratio'].hard_max == 5.
              and control.bl_rna.properties['ratio'].is_animatable)
        check('first_toggle_captures_camera_and_enables_dolly', bpy.ops.gyogan.dolly_toggle() == {'FINISHED'}
              and control.active and control.enabled)
        check('setup_captures_original_camera_and_cursor_depth', control.camera == camera
              and control.camera_data == camera.data and abs(control.depth - 10.) < 1.e-5
              and abs(control.base_lens - 28.) < 1.e-5)
        camera_matches('ratio_one_keeps_original_camera', scene, camera, original_location, original_lens)
        check('all_control_drivers_are_valid', all(curve.is_valid for block in (camera, camera.data, scene)
              if block.animation_data for curve in block.animation_data.drivers))
        control.ratio = 2.
        camera_matches('ratio_two_moves_backward_and_doubles_lens', scene, camera, (0., -20., 2.), 56.)
        near('subject_plane_size_is_preserved', projected_width(scene, camera, plane), ordinary_width)
        check('background_perspective_changes', abs(projected_width(scene, camera, background) - background_width) > .02)
        near('compensation_factor_follows_ratio', scene.evaluated_get(refresh(scene)).gyogan_dolly.factor, 2.)
        scene.cursor.location = (5., 100., 12.)
        camera_matches('cursor_changes_do_not_retarget_capture', scene, camera, (0., -20., 2.), 56.)
        control.ratio = .5
        camera_matches('ratio_half_moves_forward_and_halves_lens', scene, camera, (0., -5., 2.), 14.)
        near('forward_dolly_preserves_subject_plane', projected_width(scene, camera, plane), ordinary_width)
        captured = (control.token, tuple(control.original_location), tuple(control.original_delta_location),
                    control.original_rotation_mode, tuple(control.original_rotation_euler),
                    tuple(control.original_rotation_quaternion), tuple(control.original_rotation_axis_angle),
                    tuple(control.target_position), control.target_name, control.base_lens, control.depth)
        owned_drivers = driver_state(camera), driver_state(camera.data)
        toggle_results = [bpy.ops.gyogan.dolly_toggle() == {'FINISHED'} and control.active and not control.enabled]
        camera_matches('preview_off_restores_original_camera', scene, camera, original_location, original_lens)
        off_factor = scene.evaluated_get(refresh(scene)).gyogan_dolly.factor
        for enabled in (True, False, True):
            toggle_results.append(bpy.ops.gyogan.dolly_toggle() == {'FINISHED'}
                                  and control.active and control.enabled == enabled)
            refresh(scene)
            toggle_results.append(control.ratio == .5 and captured == (
                control.token, tuple(control.original_location), tuple(control.original_delta_location),
                control.original_rotation_mode, tuple(control.original_rotation_euler),
                tuple(control.original_rotation_quaternion), tuple(control.original_rotation_axis_angle),
                tuple(control.target_position), control.target_name, control.base_lens, control.depth)
                and owned_drivers == (driver_state(camera), driver_state(camera.data)))
        evaluated = evaluated_camera(scene, camera)
        check('preview_toggle_keeps_capture_ratio_and_drivers', abs(off_factor - 1.) < 3.e-5
              and all(toggle_results) and abs(evaluated.data.lens - 14.) < 4.e-5
              and (evaluated.matrix_world.translation - Vector((0., -5., 2.))).length < 4.e-5,
              off_factor=off_factor, resumed_lens=evaluated.data.lens)
        control.ratio = 1.
        camera_matches('ratio_one_returns_exact_base', scene, camera, original_location, original_lens)

        for strength, ellipse in ((1., (1., 1.)), (-5., (.4, 2.)), (.5, (2., .4)), (5., (.4, 2.))):
            settings.strength = strength
            settings.ellipse_x, settings.ellipse_y = ellipse
            control.ratio = 1.
            width = projected_width(scene, camera, positions(scene, mesh)[:2])
            control.ratio = 2.
            shifted_width = projected_width(scene, camera, positions(scene, mesh)[:2])
            relative = abs(shifted_width / width - 1.)
            check('fisheye_near_axis_scale_preserved_' + str(strength), relative < .003, relative_error=relative)
        settings.strength = 1.
        settings.ellipse_x = settings.ellipse_y = 1.
        control.compensate_fisheye = False
        uncompensated = projected_width(scene, camera, positions(scene, mesh)[:2])
        control.compensate_fisheye = True
        compensated = projected_width(scene, camera, positions(scene, mesh)[:2])
        check('fisheye_compensation_switch_reaches_node_graph', abs(compensated / uncompensated - 2.) < .005)
        settings.enabled = False
        check('fisheye_off_preserves_original_mesh_during_dolly', error(positions(scene, mesh), [Vector(p) for p in raw_points]) < 2.e-6)
        near('ordinary_projection_works_with_fisheye_off', projected_width(scene, camera, positions(scene, mesh)[:2]),
             projected_width(scene, camera, [Vector(p) for p in raw_points[:2]]))
        settings.enabled = True
        check('dolly_keeps_original_mesh_and_node_references', source_vertices == [tuple(v.co) for v in mesh.data.vertices]
              and target.node_group.as_pointer() == node_pointer and mesh.modifiers[-1].persistent_uid == modifier_uid)
        control.ratio = 1.
        refresh(scene)
        rig, body = make_rig(scene)
        rig_target = addon.setup_armature(scene, rig)
        raw_body = [tuple(v.co) for v in body.data.vertices]
        for strength in (2., -3.):
            settings.strength = strength
            settings.ellipse_x, settings.ellipse_y = .6, 1.8
            control.ratio = 2.
            difference = error(bone_points(scene, rig_target.output_rig), expected_bones(scene, bone_points(scene, rig)))
            check('armature_head_tail_receive_dolly_factor_' + str(strength), difference < 4.e-4, max_error=difference)
        old_leaf = replace_legacy_armature(scene, rig_target)
        old_leaf_pointer = old_leaf.as_pointer()
        addon.nodes.upgrade_ellipse_group(old_leaf, scene)
        upgraded = addon.nodes.upgrade_dolly_group(old_leaf, scene)
        count = len(old_leaf.nodes)
        repeated = addon.nodes.upgrade_dolly_group(old_leaf, scene)
        check('legacy_armature_dolly_upgrade_preserves_id_and_is_idempotent', upgraded and not repeated
              and old_leaf.as_pointer() == old_leaf_pointer and len(old_leaf.nodes) == count)
        difference = error(bone_points(scene, rig_target.output_rig), expected_bones(scene, bone_points(scene, rig)))
        check('legacy_armature_dolly_upgrade_evaluates_factor', difference < 4.e-4, max_error=difference)
        check('dolly_armature_keeps_source_geometry', raw_body == [tuple(v.co) for v in body.data.vertices])
        settings.strength = 1.
        settings.ellipse_x = settings.ellipse_y = 1.
        check('restore_operator_completes', bpy.ops.gyogan.dolly_restore() == {'FINISHED'} and not control.active)
        camera_matches('restore_removes_camera_effect', scene, camera, original_location, original_lens)
        check('restore_removes_its_drivers', not driver_state(camera) and not driver_state(camera.data)
              and not any(item[0] == 'gyogan_dolly.factor' for item in driver_state(scene)))

        peripheral = make_mesh(scene, 'ドリー検証・登録範囲',
                               [(13.65, 0., 1.95), (13.75, 0., 1.95), (13.7, 0., 2.05)], [(0, 1, 2)])
        behind = make_mesh(scene, 'ドリー検証・カメラ後方',
                           [(-.05, -30., 1.95), (.05, -30., 1.95), (0., -30., 2.05)], [(0, 1, 2)])
        saved_fov = settings.fov
        settings.fov = math.radians(60.)
        scene.cursor.location = (0., 0., 2.)
        addon.dolly.setup(scene)
        refresh(scene)
        base_outside = not addon.within_camera(peripheral, scene)
        control.ratio = .5
        refresh(scene)
        check('dolly_factor_expands_registration_range_conservatively', base_outside
              and addon.within_camera(peripheral, scene) and not addon.within_camera(behind, scene))
        addon.dolly.restore(scene)
        settings.fov = saved_fov

        anchor = bpy.data.objects.new('ドリー検証・基準エンプティ', None)
        scene.collection.objects.link(anchor)
        anchor.location = (0., 5., 2.)
        control.target = anchor
        bpy.ops.gyogan.dolly_toggle()
        control.ratio = 2.
        camera_matches('object_target_uses_its_forward_depth', scene, camera, (0., -25., 2.), 56.)
        anchor.location = (7., 50., 2.)
        camera_matches('object_target_is_a_static_capture', scene, camera, (0., -25., 2.), 56.)
        bpy.data.objects.remove(anchor, do_unlink=True)
        camera_matches('deleted_target_keeps_captured_depth', scene, camera, (0., -25., 2.), 56.)
        addon.dolly.restore(scene)
        control.target = None
        scene.cursor.location = (0., 0., 2.)

        def rejected(name):
            before = (tuple(camera.location), camera.data.lens, driver_state(camera), driver_state(camera.data),
                      driver_state(scene), len(bpy.data.objects), len(bpy.data.cameras))
            message = ''
            try:
                addon.dolly.setup(scene)
            except ValueError as exc:
                message = str(exc)
            after = (tuple(camera.location), camera.data.lens, driver_state(camera), driver_state(camera.data),
                     driver_state(scene), len(bpy.data.objects), len(bpy.data.cameras))
            check(name, bool(message) and before == after and not control.active,
                  reason=message, unchanged=before == after)

        camera.data.type = 'ORTHO'
        rejected('orthographic_camera_is_rejected_atomically')
        camera.data.type = 'PERSP'
        parent = bpy.data.objects.new('ドリー検証・親', None)
        scene.collection.objects.link(parent)
        camera.parent = parent
        rejected('parented_camera_is_rejected_atomically')
        camera.parent = None
        constraint = camera.constraints.new('COPY_LOCATION')
        constraint.target = parent
        rejected('constrained_camera_is_rejected_atomically')
        camera.constraints.remove(constraint)
        camera.delta_location.x = .1
        rejected('delta_transform_is_rejected_atomically')
        camera.delta_location.x = 0.
        camera.keyframe_insert('location', frame=1)
        rejected('animated_camera_is_rejected_atomically')
        camera.animation_data_clear()
        camera.data.keyframe_insert('lens', frame=1)
        rejected('animated_lens_is_rejected_atomically')
        camera.data.animation_data_clear()
        driver = camera.driver_add('location', 0)
        driver.driver.expression = '0.0'
        rejected('user_transform_driver_is_rejected_atomically')
        camera.driver_remove('location', 0)
        shared = bpy.data.objects.new('ドリー検証・共有カメラ', camera.data)
        scene.collection.objects.link(shared)
        rejected('shared_camera_data_is_rejected_atomically')
        bpy.data.objects.remove(shared, do_unlink=True)
        other_scene = bpy.data.scenes.new('ドリー検証・別シーン')
        other_scene.collection.objects.link(camera)
        rejected('multi_scene_camera_is_rejected_atomically')
        bpy.data.scenes.remove(other_scene)
        scene.cursor.location = (0., -11., 2.)
        rejected('target_behind_camera_is_rejected_atomically')
        scene.cursor.location = (0., -10. + .1005, 2.)
        rejected('target_inside_near_clip_margin_is_rejected_atomically')
        camera_matches('near_margin_rejection_keeps_initial_camera', scene, camera, original_location, original_lens)
        scene.cursor.location = (0., 0., 2.)

        original_install = addon.dolly._install_driver
        calls = []

        def fail_after_first_driver(*args):
            original_install(*args)
            calls.append(True)
            raise RuntimeError('検証用のドライバー作成失敗')

        addon.dolly._install_driver = fail_after_first_driver
        failed = False
        try:
            addon.dolly.setup(scene)
        except RuntimeError:
            failed = True
        finally:
            addon.dolly._install_driver = original_install
        check('partial_driver_install_failure_rolls_back', failed and bool(calls) and not control.active
              and not driver_state(camera) and not driver_state(camera.data)
              and not any(item[0] == 'gyogan_dolly.factor' for item in driver_state(scene)))
        camera_matches('partial_setup_failure_restores_camera_values', scene, camera, original_location, original_lens)

        # Exercise dolly switching independently of the UI observer; its joint
        # node/camera transaction has a separate integration regression suite.
        addon.cameras._busy.add(scene.as_pointer())
        second_data = bpy.data.cameras.new('ドリー切替検証・カメラデータ')
        second = bpy.data.objects.new('ドリー切替検証・カメラ', second_data)
        scene.collection.objects.link(second)
        second.location = (2., -7., 2.)
        second.rotation_euler.x = math.pi / 2
        second_data.lens = 40.
        second_location = second.location.copy()

        def switch_state():
            return (addon.dolly._settings_snapshot(control),
                    addon.dolly._raw_pose(camera), tuple(camera.delta_location), camera.data.lens,
                    driver_state(camera), driver_state(camera.data),
                    addon.dolly._raw_pose(second), tuple(second.delta_location), second_data.lens,
                    driver_state(second), driver_state(second_data))

        try:
            addon.dolly.setup(scene, camera)
            control.ratio = 1.8
            control.compensate_fisheye = False
            refresh(scene)
            captured_position = tuple(control.target_position)
            captured_name = control.target_name
            scene.cursor.location = (70., 80., 90.)
            addon.dolly.switch_camera(scene, second)
            check('switch_captures_new_camera_and_keeps_saved_target',
                  control.active and control.camera == second and control.ratio == 1.
                  and control.enabled and not control.compensate_fisheye
                  and tuple(control.target_position) == captured_position
                  and control.target_name == captured_name)
            camera_matches('switch_restores_old_camera_before_release', scene, camera,
                           original_location, original_lens)
            camera_matches('switch_starts_from_new_camera_current_pose', scene, second,
                           second_location, 40.)
            check('switch_releases_old_drivers_and_installs_new_drivers',
                  not driver_state(camera) and not driver_state(camera.data)
                  and len(driver_state(second)) == 3 and len(driver_state(second_data)) == 1)
            width = projected_width(scene, second, plane)
            control.ratio = 2.
            near('switched_camera_keeps_captured_plane_size', projected_width(scene, second, plane), width)
            control.enabled = False
            refresh(scene)
            addon.dolly.switch_camera(scene, camera)
            check('switch_preserves_preview_off_and_compensation', control.active
                  and not control.enabled and not control.compensate_fisheye and control.ratio == 1.)
            camera_matches('switch_back_restores_second_camera', scene, second, second_location, 40.)
            control.enabled = True
            control.ratio = 1.6
            refresh(scene)

            second_data.type = 'ORTHO'
            before = switch_state()
            rejected_switch = False
            try:
                addon.dolly.switch_camera(scene, second)
            except ValueError:
                rejected_switch = True
            check('invalid_switch_leaves_both_cameras_and_dolly_unchanged',
                  rejected_switch and switch_state() == before)
            second_data.type = 'PERSP'

            control.keyframe_insert('ratio', frame=1)
            before = switch_state()
            action = scene.animation_data.action
            rejected_switch = False
            try:
                addon.dolly.switch_camera(scene, second)
            except ValueError:
                rejected_switch = True
            check('animated_ratio_switch_rejection_preserves_action_and_values',
                  rejected_switch and switch_state() == before and scene.animation_data.action == action)
            scene.animation_data_clear()

            for fail_at in (1, 4):
                # A failed preparation must preserve the existing FCurve IDs,
                # including user-visible editor settings on those owned curves.
                second.animation_data_clear()
                second_data.animation_data_clear()
                refresh(scene)
                before = switch_state()
                old_curves = [curve.as_pointer() for owner in (camera, camera.data)
                              for curve in owner.animation_data.drivers]
                calls = []

                def fail_switch_driver(*args):
                    original_install(*args)
                    calls.append(True)
                    if len(calls) == fail_at:
                        raise RuntimeError('検証用の切替ドライバー作成失敗')

                addon.dolly._install_driver = fail_switch_driver
                failed = False
                try:
                    addon.dolly.switch_camera(scene, second)
                except RuntimeError:
                    failed = True
                finally:
                    addon.dolly._install_driver = original_install
                check('switch_driver_failure_rolls_back_' + str(fail_at), failed
                      and switch_state() == before
                      and old_curves == [curve.as_pointer() for owner in (camera, camera.data)
                                         for curve in owner.animation_data.drivers]
                      and second.animation_data is None and second_data.animation_data is None)

            changed = camera.animation_data.drivers[0]
            expression = changed.driver.expression
            changed.driver.expression = '123.0'
            before = switch_state()
            rejected_switch = False
            try:
                addon.dolly.switch_camera(scene, second)
            except ValueError:
                rejected_switch = True
            check('switch_preserves_modified_user_driver_and_rejects',
                  rejected_switch and switch_state() == before and changed.driver.expression == '123.0')
            changed.driver.expression = expression
            addon.dolly.switch_camera(scene, None)
            check('clearing_camera_restores_and_stops_dolly', not control.active
                  and not driver_state(camera) and not driver_state(camera.data))
            camera_matches('clearing_camera_recovers_original_pose', scene, camera,
                           original_location, original_lens)

            scene.cursor.location = (0., 0., 2.)
            addon.dolly.setup(scene, second)
            control.ratio = 2.
            refresh(scene)
            bpy.data.objects.remove(second, do_unlink=True)
            addon.dolly.switch_camera(scene, camera)
            check('deleted_old_camera_can_switch_without_leaking_lens_driver',
                  control.active and control.camera == camera and not driver_state(second_data)
                  and abs(second_data.lens - 40.) < 1.e-6)
            addon.dolly.restore(scene)

            second = bpy.data.objects.new('ドリー切替検証・削除カメラ', second_data)
            scene.collection.objects.link(second)
            second.location = second_location
            second.rotation_euler.x = math.pi / 2
            addon.dolly.setup(scene, second)
            bpy.data.objects.remove(second, do_unlink=True)
            addon.dolly.switch_camera(scene, None)
            check('clearing_deleted_camera_releases_remaining_lens_driver',
                  not control.active and not driver_state(second_data) and second_data.lens == 40.)
        finally:
            if control.active:
                addon.dolly.restore(scene)
            control.compensate_fisheye = True
            scene.cursor.location = (0., 0., 2.)
            for candidate in list(bpy.data.objects):
                if candidate.type == 'CAMERA' and candidate.data == second_data:
                    bpy.data.objects.remove(candidate, do_unlink=True)
            if second_data.users == 0:
                bpy.data.cameras.remove(second_data)
            addon.cameras._busy.discard(scene.as_pointer())

        camera.data.lens = 2.
        addon.dolly.setup(scene)
        control.ratio = .1
        camera_matches('short_lens_clamps_ratio_consistently', scene, camera, (0., -5., 2.), 1.)
        near('short_lens_clamp_keeps_subject_size', projected_width(scene, camera, plane), ordinary_width * 2. / 28.)
        addon.dolly.restore(scene)
        maximum_lens = camera.data.bl_rna.properties['lens'].hard_max
        camera.data.lens = maximum_lens * .75
        addon.dolly.setup(scene)
        control.ratio = 5.
        camera_matches('maximum_lens_clamps_distance_consistently', scene, camera,
                       (0., -10. * maximum_lens / control.base_lens, 2.), maximum_lens)
        addon.dolly.restore(scene)
        camera.data.lens = original_lens
        scene.cursor.location = (0., -9.8, 2.)
        addon.dolly.setup(scene)
        control.ratio = .1
        effective = camera.data.clip_start * 1.01 / control.depth
        camera_matches('near_clip_clamps_ratio_and_lens_together', scene, camera,
                       original_location + Vector((0., -1., 0.)) * control.depth * (effective - 1.), original_lens * effective)
        addon.dolly.restore(scene)
        scene.cursor.location = (0., 0., 2.)

        addon.dolly.setup(scene)
        for frame, ratio in ((1, .5), (5, 1.), (9, 2.)):
            control.ratio = ratio
            control.keyframe_insert('ratio', frame=frame)
        snapshots = {}
        for frame in (9, 1, 7, 5):
            scene.frame_set(frame)
            ev = evaluated_camera(scene, camera)
            ratio = scene.evaluated_get(refresh(scene)).gyogan_dolly.ratio
            snapshots[frame] = (ev.matrix_world.translation.copy(), ev.data.lens, positions(scene, mesh))
            camera_matches('animated_ratio_evaluates_out_of_order_' + str(frame), scene, camera,
                           (0., -10. * ratio, 2.), 28. * ratio)
            if frame in (1, 5, 9):
                near('ratio_keyframe_value_' + str(frame), ratio, {1: .5, 5: 1., 9: 2.}[frame])
        check('ratio_animation_changes_camera_and_fisheye',
              (snapshots[1][0] - snapshots[9][0]).length > 10.
              and error(snapshots[1][2], snapshots[9][2]) > .001)
        camera_name, mesh_name = camera.name, mesh.name
        bpy.ops.wm.save_as_mainfile(filepath=str(FIXTURE), check_existing=False)
        bpy.ops.wm.open_mainfile(filepath=str(FIXTURE))
        scene = bpy.context.scene
        settings, control = scene.gyogan, scene.gyogan_dolly
        camera, mesh = bpy.data.objects[camera_name], bpy.data.objects[mesh_name]
        check('saved_dolly_retains_ownership_and_active_state', control.active and control.camera == camera and bool(control.token))
        for frame in (5, 9, 1, 7):
            scene.frame_set(frame)
            saved = snapshots[frame]
            ev = evaluated_camera(scene, camera)
            check('saved_animation_restores_exact_result_' + str(frame),
                  (ev.matrix_world.translation - saved[0]).length < 1.e-6
                  and abs(ev.data.lens - saved[1]) < 1.e-6 and error(positions(scene, mesh), saved[2]) < 1.e-6)
        bpy.ops.gyogan.dolly_toggle()
        camera_matches('saved_preview_off_recovers_camera', scene, camera, original_location, original_lens)
        bpy.ops.gyogan.dolly_toggle()
        addon.dolly.restore(scene)
        camera_matches('saved_restore_recovers_original_camera', scene, camera, original_location, original_lens)
        scene.animation_data_clear()
        check('restoration_preserves_camera_rotation', (Vector(camera.rotation_euler) - Vector(original_rotation)).length < 1.e-7)

        addon.dolly.setup(scene)
        control.ratio = 2.
        refresh(scene)
        changed = next(curve for curve in camera.animation_data.drivers if curve.data_path == 'delta_location' and curve.array_index == 0)
        changed.driver.expression = '7.0'
        warnings = addon.dolly.restore(scene)
        check('restoration_preserves_user_replacement_driver', bool(warnings)
              and any(curve.data_path == 'delta_location' and curve.array_index == 0 and curve.driver.expression == '7.0'
                      for curve in camera.animation_data.drivers))
        camera.driver_remove('delta_location', 0)
        camera.delta_location = (0., 0., 0.)
        camera.location = original_location
        camera.data.lens = original_lens
        for edit in ('keyframes', 'fallback'):
            addon.dolly.setup(scene)
            changed = next(curve for curve in camera.animation_data.drivers
                           if curve.data_path == 'delta_location' and curve.array_index == 0)
            curve_pointer = changed.as_pointer()
            if edit == 'keyframes':
                changed.keyframe_points.insert(0., 0.)
                changed.keyframe_points.insert(1., 3.)
            else:
                changed.driver.variables[0].targets[0].use_fallback_value = True
            warnings = addon.dolly.restore(scene)
            preserved = next((curve for curve in camera.animation_data.drivers
                              if curve.data_path == 'delta_location' and curve.array_index == 0), None)
            check('restoration_preserves_user_driver_' + edit, bool(warnings) and preserved is not None
                  and preserved.as_pointer() == curve_pointer
                  and (len(preserved.keyframe_points) == 2 if edit == 'keyframes'
                       else preserved.driver.variables[0].targets[0].use_fallback_value))
            camera.driver_remove('delta_location', 0)
            camera.delta_location = (0., 0., 0.)
            camera.location = original_location
            camera.data.lens = original_lens
        refresh(scene)
        addon.dolly.setup(scene)
        control.ratio = 2.
        refresh(scene)
        addon.unregister()
        camera_matches('addon_unregister_recovers_original_camera', scene, camera, original_location, original_lens)
        check('addon_unregister_preserves_original_geometry', [tuple(v.co) for v in mesh.data.vertices] == source_vertices
              and not driver_state(camera) and not driver_state(camera.data))
    except Exception:
        exception = traceback.format_exc()
        print(exception)
    finally:
        passed = bool(checks) and all(item['passed'] for item in checks) and exception is None
        report = dict(blender=bpy.app.version_string, passed=passed, checks=checks, exception=exception)
        REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        print('GYOGAN_DOLLY_RESULTS=' + json.dumps(report, ensure_ascii=False))
    if not passed:
        raise AssertionError('ドリーズームの検証に失敗しました: ' + str(REPORT))


if __name__ == '__main__':
    run()
