"""Conservative, pre-addon camera membership regression in a separate process."""

import itertools
import json
import math
import random
import sys
import traceback
from pathlib import Path

import bpy
from mathutils import Matrix, Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tests'))
sys.dont_write_bytecode = True
import gyogan_camera as addon
from gyogan_camera import framing
from test_paths import output_path

REPORT = output_path('framing_result.json')


def run():
    if not bpy.app.background:
        raise RuntimeError('カメラ範囲の検証は専用のバックグラウンドプロセスで実行してください')
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if not hasattr(bpy.types.Scene, 'gyogan'):
        addon.register()
    checks, exception = [], None

    def check(name, condition, **details):
        checks.append(dict(test=name, passed=bool(condition), **details))

    try:
        scene = bpy.context.scene
        scene.name = 'カメラ範囲・専用数値検証'
        settings = scene.gyogan
        settings.scope = 'SELECTED'
        if hasattr(settings, 'effect_scope'):
            settings.effect_scope = 'MANUAL'
        camera = bpy.data.objects.new('正面方向の検証カメラ', bpy.data.cameras.new('検証カメラ・データ'))
        scene.collection.objects.link(camera)
        camera.location = (0.0, -10.0, 2.0)
        camera.rotation_euler = (math.pi / 2.0, 0.0, 0.0)
        scene.camera = camera
        camera.data.lens = 50.0
        scene.render.resolution_x, scene.render.resolution_y = 1600, 900
        settings.strength = 0.0
        settings.near_distance = 0.4
        settings.zoom = 1.0
        settings.fov = math.radians(140.0)
        bpy.context.view_layer.update()

        def world(point):
            return camera.matrix_world.normalized() @ Vector(point)

        def bounds(center, half):
            return [world(tuple(center[axis] + signs[axis] * half[axis] for axis in range(3)))
                    for signs in itertools.product((-1.0, 1.0), repeat=3)]

        def visible(center, half=(0.0, 0.0, 0.0), margin=0.0):
            return framing.in_camera(scene, None, bounds=bounds(center, half), margin=margin)

        def point_oracle(point):
            frame = camera.data.view_frame(scene=scene)
            fx = min(v.x / -v.z for v in frame), max(v.x / -v.z for v in frame)
            fy = min(v.y / -v.z for v in frame), max(v.y / -v.z for v in frame)
            center = settings.center_object
            inverse = camera.matrix_world.normalized().inverted()
            center_point = inverse @ center.matrix_world.translation if center else None
            warped = addon.nodes.camera_space_reference(
                point, settings.strength, settings.fov, settings.zoom,
                settings.near_distance, (fx[1] - fx[0]) * 0.5,
                center_point=center_point, ellipse_x=settings.ellipse_x,
                ellipse_y=settings.ellipse_y, dolly_factor=scene.gyogan_dolly.factor)
            depth = -warped[2]
            return (camera.data.clip_start <= depth <= camera.data.clip_end
                    and fx[0] <= warped[0] / depth <= fx[1]
                    and fy[0] <= warped[1] / depth <= fy[1])

        check('plain_center_is_inside', visible((0.0, 0.0, -5.0), (0.2, 0.2, 0.2)))
        check('plain_far_side_is_outside', not visible((50.0, 0.0, -5.0), (0.2, 0.2, 0.2)))
        check('behind_camera_is_excluded', not visible((0.0, 0.0, 5.0), (1.0, 1.0, 1.0)))
        check('before_near_clip_is_excluded', not visible((0.0, 0.0, -0.01)))
        camera.data.clip_end = 20.0
        check('beyond_far_clip_is_excluded', not visible((0.0, 0.0, -25.0), (1.0, 1.0, 1.0)))
        check('far_clip_intersection_is_included', visible((0.0, 0.0, -20.0), (0.1, 0.1, 1.0)))
        check('volume_enclosing_entire_frame_is_included', visible((0.0, 0.0, -5.0), (100.0, 100.0, 1.0)))
        check('camera_plane_crossing_volume_is_included', visible((0.0, 0.0, -0.2), (1.0, 1.0, 1.0)))
        check('partial_box_intersection_is_included', visible((2.0, 0.0, -5.0), (0.5, 0.2, 0.1)))
        check('no_partial_intersection_stays_outside', not visible((2.5, 0.0, -5.0), (0.1, 0.1, 0.1)))
        edge_x = max(v.x / -v.z for v in camera.data.view_frame(scene=scene)) * 5.0
        check('exit_margin_keeps_boundary_neighbour', not visible((edge_x * 1.01, 0.0, -5.0))
              and visible((edge_x * 1.01, 0.0, -5.0), margin=0.02))
        settings.strength = 1.0
        check('fisheye_brings_perspective_outside_inside', visible((10.0, 0.0, -5.0)))
        settings.strength = -5.0
        settings.zoom = 3.0
        check('negative_strength_can_move_original_inside_outside', not visible((1.75, 0.0, -5.0)))
        settings.zoom = 1.0
        settings.strength = 1.0
        settings.ellipse_y = 1.0
        ordinary = visible((0.0, 5.0, -5.0))
        settings.ellipse_y = 0.1
        check('ellipse_changes_vertical_membership', not ordinary and visible((0.0, 5.0, -5.0)))
        settings.ellipse_y = 1.0

        # The supplied world bounds must be authoritative even if an object has
        # wildly different visible geometry. Its mesh and modifiers stay intact.
        mesh = bpy.data.meshes.new('境界読み取り専用・データ')
        mesh.from_pydata([(-0.1, -0.1, -0.1), (0.1, 0.1, 0.1)], [], [])
        mesh.update()
        obj = bpy.data.objects.new('境界読み取り専用', mesh)
        scene.collection.objects.link(obj)
        obj.matrix_world = camera.matrix_world @ Matrix.Translation((0.0, 0.0, -5.0))
        bpy.context.view_layer.update()
        settings.strength = 0.0
        original_data = [tuple(vertex.co) for vertex in mesh.vertices]
        original_matrix = obj.matrix_world.copy()
        check('default_original_bound_box_path', framing.in_camera(scene, obj, margin=0.0))
        check('provided_bounds_override_object_geometry', not framing.in_camera(
            scene, obj, bounds=bounds((50.0, 0.0, -5.0), (0.1, 0.1, 0.1)), margin=0.0))
        obj.hide_render = True
        check('hidden_proxy_bounds_can_still_be_tested', framing.in_camera(scene, obj, margin=0.0))
        check('framing_never_modifies_original', original_data == [tuple(vertex.co) for vertex in mesh.vertices]
              and original_matrix == obj.matrix_world and not obj.modifiers)

        center_obj = bpy.data.objects.new('中心の検証エンプティ', None)
        scene.collection.objects.link(center_obj)
        randomizer = random.Random(20260921)
        cases = 0
        visible_samples = 0
        false_negatives = []
        point_mismatches = []
        for strength in (-5.0, -1.0, -0.2, 0.0, 0.2, 1.0, 5.0):
            settings.strength = strength
            for configuration in range(9):
                camera.data.lens = randomizer.uniform(18.0, 120.0)
                camera.data.shift_x = randomizer.uniform(-0.5, 0.5)
                camera.data.shift_y = randomizer.uniform(-0.35, 0.35)
                scene.render.resolution_x, scene.render.resolution_y = randomizer.choice(
                    ((1600, 900), (900, 1600), (1000, 1000)))
                scene.render.pixel_aspect_x, scene.render.pixel_aspect_y = randomizer.choice(
                    ((1.0, 1.0), (2.0, 1.0), (1.0, 2.0)))
                settings.ellipse_x = randomizer.choice((0.1, 0.5, 1.0, 2.5))
                settings.ellipse_y = randomizer.choice((0.1, 0.5, 1.0, 2.5))
                settings.zoom = randomizer.uniform(0.3, 2.0)
                settings.fov = randomizer.uniform(math.radians(30.0), math.radians(175.0))
                center_obj.location = world((randomizer.uniform(-3.0, 3.0),
                                             randomizer.uniform(-3.0, 3.0),
                                             randomizer.choice((-0.6, -4.0, 2.0))))
                settings.center_object = center_obj if configuration % 3 else None
                bpy.context.view_layer.update()
                dolly = scene.gyogan_dolly
                dolly.active = configuration % 2 == 1
                dolly.enabled = True
                dolly.compensate_fisheye = True
                dolly.base_lens = 50.0
                dolly.depth = 10.0
                dolly.ratio = randomizer.choice((0.5, 1.0, 2.0))
                dolly.lens_max = 1000.0
                dolly.near_clip = 0.1
                for _ in range(7):
                    center = (randomizer.uniform(-10.0, 10.0), randomizer.uniform(-10.0, 10.0),
                              -randomizer.uniform(0.11, 12.0))
                    half = tuple(randomizer.uniform(0.01, 3.0) for _ in range(3))
                    expected_points = [tuple(center[axis] + signs[axis] * half[axis] for axis in range(3))
                                       for signs in itertools.product((-1.0, 0.0, 1.0), repeat=3)]
                    hits = sum(point_oracle(point) for point in expected_points)
                    visible_samples += hits
                    actual = visible(center, half)
                    cases += 1
                    if hits and not actual:
                        false_negatives.append(dict(strength=strength, case=cases, center=center, half=half))
                    for point in expected_points[::7]:
                        expected = point_oracle(point)
                        actual_point = visible(point)
                        if expected != actual_point:
                            point_mismatches.append(dict(strength=strength, point=point,
                                                         expected=expected, actual=actual_point))
                # Explicit samples exercise the fade band and clipping boundary.
                for depth in (0.12, 0.39, 0.4, 0.41, 0.6, 0.79, 0.8, 0.81):
                    point = (depth * 0.1, depth * -0.1, -depth)
                    if point_oracle(point) != visible(point):
                        point_mismatches.append(dict(strength=strength, point=point, fade=True))
        check('signed_elliptical_shifted_boxes_have_no_false_negatives', not false_negatives,
              cases=cases, visible_samples=visible_samples, failures=false_negatives[:5])
        check('point_bounds_match_shared_projection_oracle', not point_mismatches,
              failures=point_mismatches[:5], mismatch_count=len(point_mismatches))
        check('randomized_oracle_sample_set_contains_visible_geometry', visible_samples > 100)
        dolly.active = False
        settings.center_object = None
        scene.camera = None
        check('missing_active_camera_is_excluded', not framing.in_camera(scene, obj))
        scene.camera = camera
        camera.data.type = 'ORTHO'
        check('unsupported_camera_type_is_excluded', not framing.in_camera(scene, obj))
    except Exception:
        exception = traceback.format_exc()
        print(exception)
    finally:
        passed = bool(checks) and all(item['passed'] for item in checks) and exception is None
        report = dict(blender=bpy.app.version_string, passed=passed, checks=checks, exception=exception)
        REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        print('GYOGAN_FRAMING_RESULTS=' + json.dumps(report, ensure_ascii=False))
    if not passed:
        raise AssertionError('カメラ範囲の検証に失敗しました: ' + str(REPORT))


if __name__ == '__main__':
    run()
