"""Render the user's A_テスト用人物 in an isolated process; never save its file.

Run after copying the working .blend to tests/center_visual_fixture.blend.
Add -- --negative to include negative-strength comparisons.
Add -- --ellipse for standard, horizontal and vertical ellipse comparisons.
Add -- --cursor for default/object/cursor centers and a moved cursor comparison.
Use -- --fixture <path> and GYOGAN_TEST_OUTPUT_DIR for version-isolated runs.
The fallback is the repository's user-provided .blend. All edits are in memory.
"""
import json
import math
import sys
from pathlib import Path

import bpy
from mathutils import Vector

if not bpy.app.background:
    raise RuntimeError("人物プレビューは専用のバックグラウンドプロセスで実行してください")

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
from test_paths import output_path
sys.path.insert(0, str(ROOT))
import gyogan_camera as addon

addon.register()
fixture = ROOT / "tests" / "center_visual_fixture.blend"
if '--ellipse' in sys.argv and (ROOT / 'tests' / 'ellipse_live_fixture.blend').exists():
    fixture = ROOT / 'tests' / 'ellipse_live_fixture.blend'
if '--fixture' in sys.argv:
    fixture = Path(sys.argv[sys.argv.index('--fixture') + 1])
    if not fixture.is_file():
        raise RuntimeError('人物プレビューの入力ファイルが見つかりません: ' + str(fixture))
bpy.ops.wm.open_mainfile(filepath=str(fixture if fixture.exists() else ROOT / "魚眼テスト用.blend"),
                          load_ui=False)
scene = bpy.context.scene
rig = scene.objects["A_テスト用人物"]
body_names = {"Beta_Surface", "Beta_Joints"}
if scene.gyogan_dolly.active:
    addon.dolly.restore(scene)
while scene.gyogan.targets:
    addon.remove_target(scene, len(scene.gyogan.targets) - 1)
for obj in scene.objects:
    if obj.type == 'MESH':
        obj.hide_render = obj.name not in body_names
        obj.color = (0.20, 0.48, 0.68, 1.0) if obj.name == "Beta_Surface" else (0.1, 0.17, 0.24, 1.0)

scene.render.engine = 'BLENDER_WORKBENCH'
scene.render.resolution_x, scene.render.resolution_y = 960, 720
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
scene.display.shading.light = 'STUDIO'
scene.display.shading.color_type = 'OBJECT'
scene.display.shading.show_shadows = True
scene.display.shading.show_cavity = True
scene.display.shading.background_type = 'WORLD'
scene.world.color = (0.08, 0.08, 0.08)
scene.gyogan.subdivision = 'NONE'
scene.gyogan.enabled = True
# Frame the user's current pose from the agreed Numpad-1 front direction.
# Only this background verification camera changes; the source rig stays put.
bpy.context.view_layer.update()
depsgraph = bpy.context.evaluated_depsgraph_get()
points = []
for name in body_names:
    obj = scene.objects[name].evaluated_get(depsgraph)
    points.extend(obj.matrix_world @ Vector(point) for point in obj.bound_box)
low = Vector(tuple(min(p[i] for p in points) for i in range(3)))
high = Vector(tuple(max(p[i] for p in points) for i in range(3)))
camera = scene.gyogan.camera or scene.camera
camera.data.lens = 16.0
camera.data.shift_x = camera.data.shift_y = 0.0
camera.rotation_euler = (math.pi / 2, 0, 0)
half_width = camera.data.sensor_width / (2 * camera.data.lens)
distance = max((high.x-low.x)/(2*half_width*.82),
               (high.z-low.z)/(2*half_width*.75*.82), .5)
if '--negative' in sys.argv:
    distance *= 1.5
camera.location = ((low.x+high.x)/2, low.y-distance, (low.z+high.z)/2)
scene.camera = camera
scene.gyogan.fov = math.radians(110)
scene.gyogan.strength = 2.0
scene.gyogan.zoom = 1.0
scene.gyogan.near_distance = .1

anchor = bpy.data.objects.new("検証用・左足先の中心", None)
scene.collection.objects.link(anchor)
constraint = anchor.constraints.new('COPY_LOCATION')
constraint.target = rig
constraint.subtarget = 'mixamorig:LeftToe_End'
constraint.target_space = constraint.owner_space = 'WORLD'

rendered = []
snapshots = []
cases = [(None, 'default', 2.0), (anchor, 'foot', 2.0)]
if '--negative' in sys.argv:
    cases.extend([(None, 'negative_default', -1.0), (anchor, 'negative_foot', -1.0)])
cases = [(center, suffix, strength, 1.0, 1.0) for center, suffix, strength in cases]
if '--ellipse' in sys.argv:
    cases = [(None, 'ellipse_standard', 2.0, 1.0, 1.0),
             (None, 'ellipse_horizontal', 2.0, 2.0, 1.0),
             (None, 'ellipse_vertical', 2.0, 1.0, 2.0),
             (anchor, 'ellipse_foot', 2.0, 2.0, 1.0)]
if '--cursor' in sys.argv:
    cases = [(None, 'cursor_default', 2.0, 1.0, 1.0),
             (anchor, 'cursor_object', 2.0, 1.0, 1.0),
             (anchor, 'cursor_foot', 2.0, 1.0, 1.0),
             (anchor, 'cursor_moved', 2.0, 1.0, 1.0)]
for mode in ('MESH', 'ARMATURE'):
    while scene.gyogan.targets:
        addon.remove_target(scene, len(scene.gyogan.targets) - 1)
    if mode == 'MESH':
        for name in sorted(body_names):
            addon.setup_mesh(scene, scene.objects[name])
    else:
        addon.setup_armature(scene, rig)
    for center, suffix, strength, ellipse_x, ellipse_y in cases:
        scene.gyogan.center_mode = 'OBJECT'
        scene.gyogan.center_object = center
        if suffix in {'cursor_foot', 'cursor_moved'}:
            bpy.context.view_layer.update()
            graph = bpy.context.evaluated_depsgraph_get()
            scene.cursor.location = anchor.evaluated_get(graph).matrix_world.translation
            if suffix == 'cursor_moved':
                scene.cursor.location.x += (high.z - low.z) * .4
            scene.gyogan.center_mode = 'CURSOR'
        scene.gyogan.strength = strength
        scene.gyogan.ellipse_x, scene.gyogan.ellipse_y = ellipse_x, ellipse_y
        scene.update_tag()
        bpy.context.view_layer.update()
        graph = bpy.context.evaluated_depsgraph_get()
        sample = dict(mode=mode, case=suffix, center_mode=scene.gyogan.center_mode,
                      cursor=list(scene.cursor.location),
                      camera=[list(row) for row in camera.matrix_world],
                      meshes={}, bones={})
        if mode == 'MESH':
            sources = [(name, scene.objects[name]) for name in sorted(body_names)]
        else:
            record = next(item for item in scene.gyogan.targets if item.source == rig)
            sources = [(item.source.name, item.output) for item in record.outputs]
            evaluated_rig = record.output_rig.evaluated_get(graph)
            sample['bones'] = {
                bone.name: [list(row) for row in evaluated_rig.matrix_world @ bone.matrix]
                for bone in evaluated_rig.pose.bones}
        for name, obj in sources:
            evaluated = obj.evaluated_get(graph)
            mesh = evaluated.to_mesh()
            try:
                count = len(mesh.vertices)
                indices = sorted({int(index * (count - 1) / 127) for index in range(128)}) if count else []
                sample['meshes'][name] = dict(vertex_count=count,
                    positions=[list(evaluated.matrix_world @ mesh.vertices[index].co) for index in indices])
            finally:
                evaluated.to_mesh_clear()
        snapshots.append(sample)
        path = output_path(f'center_{mode.lower()}_{suffix}.png')
        scene.render.filepath = str(path)
        bpy.ops.render.render(write_still=True)
        rendered.append(str(path))
output_path('center_visual_result.json').write_text(json.dumps(dict(
    blender=bpy.app.version_string, fixture=str(fixture), images=rendered,
    cases=snapshots), ensure_ascii=False, indent=2), encoding='utf-8')
print('GYOGAN_CENTER_PREVIEWS=' + json.dumps(rendered, ensure_ascii=False))
