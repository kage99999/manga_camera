"""Preset persistence and reversible switching in an isolated Blender process.

Only small numeric fixtures are created here. Never run this script through MCP
or in an interactive user's scene: it loads and saves its own test blend file.
"""

import json
import math
import sys
import traceback
from pathlib import Path

import bpy

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
from test_paths import output_path
from blender_center import addon, make_rig, positions, error, refresh
from blender_subdivision import original_mesh
from blender_targets import square, settle, record, active, manual, identity, fish_modifiers, select_only

REPORT = output_path('presets_result.json')
FIXTURE = output_path('presets_fixture.blend')


def run():
    if not bpy.app.background:
        raise RuntimeError('プリセットの検証は専用のバックグラウンドプロセスで実行してください')
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if not hasattr(bpy.types.Scene, 'gyogan'):
        addon.register()
    checks, exception = [], None

    def check(name, condition, **details):
        checks.append(dict(test=name, passed=bool(condition), **details))

    def expect_error(name, function):
        message = None
        try:
            function()
        except ValueError as exc:
            message = str(exc)
        check(name, message is not None, message=message)
        return message

    def get_preset(scene, token):
        return next(item for item in scene.gyogan.presets if item.uuid == token)

    def entry_set(preset):
        return {(item.source.name, item.kind) for item in preset.entries if item.source}

    def switch(scene, token):
        addon.presets.activate(scene, token)
        settle(scene)

    try:
        scene = bpy.context.scene
        scene.name = 'プリセット・専用検証'
        settings = scene.gyogan
        camera = bpy.data.objects.new('プリセット・カメラ', bpy.data.cameras.new('プリセット・カメラ'))
        scene.collection.objects.link(camera)
        camera.location = (0., 0., 10.)
        scene.camera = settings.camera = camera
        scene.render.resolution_x = scene.render.resolution_y = 200
        settings.subdivision = 'NONE'
        settings.effect_scope = 'MANUAL'
        settings.mode = 'MESH'
        settings.strength = .8
        settings.fov = math.radians(90.)
        center = bpy.data.objects.new('プリセット・中心', None)
        scene.collection.objects.link(center)
        center.location = (.3, .2, 0.)
        collection = bpy.data.collections.new('プリセット・登録元')
        scene.collection.children.link(collection)
        first = square(scene, 'プリセット・板A', (.7, 0., 0.))
        second = square(scene, 'プリセット・板B', (1.7, 0., 0.))
        outside = square(scene, 'プリセット・画面外', (30., 0., 0.))
        first.shape_key_add(name='Basis')
        shape = first.shape_key_add(name='保持する形状キー')
        shape.data[0].co.z = .1
        shape.value = .4
        first_source, second_source = original_mesh(first), original_mesh(second)
        base_first, base_second = positions(scene, first), positions(scene, second)
        addon.setup_mesh(scene, first)
        settle(scene)
        # Empty preset storage emulates the pre-preset 0.1.17 saved schema.
        settings.presets.clear()
        first_preset = addon.presets.ensure(scene)
        first_id = first_preset.uuid
        check('old_working_registry_migrates_to_one_preset', len(settings.presets) == 1
              and entry_set(first_preset) == {(first.name, 'MESH')})
        check('old_settings_survive_migration', abs(settings.strength - .8) < 1.e-6
              and settings.effect_scope == 'MANUAL' and settings.subdivision == 'NONE')
        check('migration_names_first_preset', first_preset.name == 'プリセット1')
        first_target = identity(record(scene, first))
        old_warp = positions(scene, first)
        check('first_preset_deforms_its_mesh', error(old_warp, base_first) > .001)
        first_preset.name = '背景の曲がり'
        settings.center_object = center
        settings.target_collection = collection
        settings.scope = 'COLLECTION'
        settings.zoom, settings.ellipse_x, settings.ellipse_y = 1.2, 1.3, .9
        settings.near_distance, settings.thickness = .23, False
        addon.presets.save_active(scene)
        first_snapshot = addon.presets.snapshot(scene)

        second_id = addon.presets.create(scene).uuid
        settle(scene)
        check('new_preset_has_independent_uuid', second_id != first_id and len(settings.presets) == 2)
        check('new_preset_starts_with_empty_manual_registration', not settings.manual_targets)
        check('new_preset_inherits_current_adjustments', addon.presets.snapshot(scene)['values'] == first_snapshot['values'])
        check('new_empty_preset_restores_previous_mesh', error(positions(scene, first), base_first) < 1.e-6)
        settings.strength = -1.1
        settings.subdivision = 'SIMPLE'
        settings.viewport_levels, settings.render_levels = 2, 3
        settings.face_limit = 123456
        settings.center_object = None
        settings.scope = 'SELECTED'
        settings.target_collection = None
        settings.ellipse_x, settings.ellipse_y, settings.zoom = .7, 1.8, .85
        settings.near_distance, settings.thickness = .4, True
        addon.setup_mesh(scene, second)
        settle(scene)
        second_snapshot = addon.presets.snapshot(scene)
        second_target = identity(record(scene, second))
        second_warp = positions(scene, second)
        check('second_preset_only_activates_its_own_mesh', active(scene) == {(second.name, 'MESH')})

        # Camera, preview and dolly belong to the scene rather than a preset.
        scene.gyogan_dolly.ratio = 1.4
        scene.gyogan_dolly.compensate_fisheye = False
        camera.location.x = .1
        camera.data.lens = 44.
        common_camera = (camera.as_pointer(), tuple(camera.location), camera.data.lens)
        common_dolly = addon.dolly._settings_snapshot(scene.gyogan_dolly)
        settings.enabled = False
        switch(scene, first_id)
        check('switch_preserves_preview_off', not settings.enabled)
        check('switch_restores_all_fisheye_settings', addon.presets.snapshot(scene) == first_snapshot)
        check('switch_restores_center_and_collection_references', settings.center_object == center
              and settings.target_collection == collection)
        check('switch_preserves_camera_and_lens', common_camera == (
            scene.camera.as_pointer(), tuple(scene.camera.location), scene.camera.data.lens))
        check('switch_preserves_dolly_settings', addon.dolly._settings_snapshot(scene.gyogan_dolly) == common_dolly)
        check('off_switch_never_enables_owned_modifiers', all(not mod.show_viewport and not mod.show_render
              for target in settings.targets if target.kind == 'MESH'
              for mod in fish_modifiers(scene, target.source)))
        settings.enabled = True
        settle(scene)
        check('reenable_uses_selected_preset_only', active(scene) == {(first.name, 'MESH')})
        check('switch_reuses_prepared_target', identity(record(scene, first))[:4] == first_target[:4])
        check('inactive_preset_second_mesh_returns_to_original', error(positions(scene, second), base_second) < 1.e-6)
        switch(scene, second_id)
        check('returning_restores_second_preset_settings', addon.presets.snapshot(scene) == second_snapshot)
        check('returning_preserves_second_target_identity', identity(record(scene, second)) == second_target)
        check('returning_restores_saved_subdivision_levels', next(
            mod for mod in fish_modifiers(scene, second) if mod.type == 'SUBSURF').levels == 2)

        duplicate_id = addon.presets.create(scene, duplicate=True).uuid
        settle(scene)
        check('duplicate_copies_targets_and_settings', addon.presets.snapshot(scene) == second_snapshot)
        check('duplicate_has_new_identity', duplicate_id not in {first_id, second_id})
        check('shared_mesh_is_not_deformed_twice', identity(record(scene, second)) == second_target
              and sum(mod.type == 'NODES' for mod in fish_modifiers(scene, second)) == 1)
        get_preset(scene, first_id).name = '同じ表示名'
        get_preset(scene, second_id).name = '同じ表示名'
        switch(scene, first_id)
        check('same_name_presets_keep_independent_identity', settings.active_preset_id == first_id
              and manual(scene) == {(first.name, 'MESH')})
        settings.preset_index = next(index for index, item in enumerate(settings.presets) if item.uuid == second_id)
        settle(scene)
        check('panel_list_selection_switches_settings_and_targets', settings.active_preset_id == second_id
              and manual(scene) == {(second.name, 'MESH')} and active(scene) == {(second.name, 'MESH')})
        settings.preset_index = next(index for index, item in enumerate(settings.presets) if item.uuid == first_id)
        settle(scene)
        get_preset(scene, first_id).name = '  '
        check('empty_name_is_replaced_by_readable_default', bool(get_preset(scene, first_id).name.strip()))
        get_preset(scene, first_id).name = '保存した背景'

        # An animated setting cannot be silently overwritten by a switch.
        scene.keyframe_insert(data_path='gyogan.strength', frame=1)
        guarded_snapshot = addon.presets.snapshot(scene)
        guarded_active, guarded_cache = active(scene), identity(record(scene, first))
        expect_error('animated_value_refuses_different_preset', lambda: addon.presets.activate(scene, second_id))
        check('refused_switch_preserves_all_working_settings', addon.presets.snapshot(scene) == guarded_snapshot)
        check('refused_switch_keeps_preset_and_active_targets', settings.active_preset_id == first_id
              and active(scene) == guarded_active and identity(record(scene, first)) == guarded_cache)
        check('refused_switch_keeps_animation', bool(scene.animation_data and scene.animation_data.action))
        scene.animation_data_clear()
        curve = scene.driver_add('gyogan.zoom')
        curve.driver.expression = '1.2'
        refresh(scene)
        protected = addon.presets.snapshot(scene)
        old_index = settings.preset_index
        settings.preset_index = next(index for index, item in enumerate(settings.presets) if item.uuid == second_id)
        settle(scene)
        check('panel_selection_refuses_driver_overwrite', settings.active_preset_id == first_id
              and settings.preset_index == old_index and addon.presets.snapshot(scene) == protected)
        check('refused_panel_selection_reports_reason_and_preserves_driver', 'アニメーション' in settings.preset_status
              and scene.animation_data.drivers[0].driver.expression == '1.2')
        scene.animation_data_clear()
        switch(scene, second_id)

        # Camera/scene automatic scopes are saved separately from the manual
        # registry, and must not activate an inactive preset's offscreen mesh.
        auto_id = addon.presets.create(scene).uuid
        settings.subdivision = 'NONE'
        settings.strength = 0.
        settings.center_object = None
        settings.zoom = settings.ellipse_x = settings.ellipse_y = 1.
        settings.effect_scope = 'CAMERA'
        settle(scene)
        check('camera_preset_follows_visible_objects', (first.name, 'MESH') in active(scene)
              and (second.name, 'MESH') in active(scene) and (outside.name, 'MESH') not in active(scene))
        camera_members = active(scene)
        switch(scene, first_id)
        check('automatic_to_manual_excludes_other_cached_objects', active(scene) == {(first.name, 'MESH')})
        switch(scene, auto_id)
        check('automatic_preset_restores_scope_and_membership', settings.effect_scope == 'CAMERA'
              and active(scene) == camera_members)
        settings.effect_scope = 'SCENE'
        settle(scene)
        check('scene_scope_preset_includes_offscreen_mesh', (outside.name, 'MESH') in active(scene))
        switch(scene, second_id)
        check('scene_to_manual_excludes_scene_cache', active(scene) == {(second.name, 'MESH')})

        # Saving must capture adjustments made since the last switch without
        # requiring a separate Save Preset action.
        settings.strength = -2.25
        get_preset(scene, second_id).name = '保存した人物用設定'
        expected_snapshot = addon.presets.snapshot(scene)
        expected_ids = {preset.uuid for preset in settings.presets}
        expected_names = {preset.uuid: preset.name for preset in settings.presets}
        first_name, second_name, outside_name = first.name, second.name, outside.name
        bpy.ops.wm.save_as_mainfile(filepath=str(FIXTURE))
        bpy.ops.wm.open_mainfile(filepath=str(FIXTURE), load_ui=False)
        scene, settings = bpy.context.scene, bpy.context.scene.gyogan
        first, second, outside = [scene.objects[name] for name in (first_name, second_name, outside_name)]
        settle(scene)
        # Pointer values are different Python objects after loading; compare
        # the saved scalar snapshot and actual named registration instead.
        check('reload_keeps_all_preset_uuids', {item.uuid for item in settings.presets} == expected_ids)
        check('reload_keeps_preset_names', {item.uuid: item.name for item in settings.presets} == expected_names)
        check('reload_keeps_active_preset', settings.active_preset_id == second_id)
        check('save_pre_captures_latest_unswitched_settings', addon.presets.snapshot(scene)['values']
              == expected_snapshot['values'])
        switch(scene, first_id)
        switch(scene, second_id)
        check('reload_switch_restores_latest_saved_adjustment', abs(settings.strength + 2.25) < 1.e-6)
        check('reload_retains_original_meshes_and_shape_keys', original_mesh(first) == first_source
              and original_mesh(second) == second_source)

        select_only(second)
        bpy.ops.ed.undo_push(message='プリセット・切り替え前')
        switch(scene, first_id)
        bpy.ops.ed.undo_push(message='プリセット・切り替え後')
        undo_result = bpy.ops.ed.undo()
        scene, settings = bpy.context.scene, bpy.context.scene.gyogan
        first, second, outside = [scene.objects[name] for name in (first_name, second_name, outside_name)]
        settle(scene)
        check('native_undo_restores_active_preset', undo_result == {'FINISHED'} and settings.active_preset_id == second_id)
        check('native_undo_restores_settings_and_targets', abs(settings.strength + 2.25) < 1.e-6
              and manual(scene) == {(second.name, 'MESH')} and active(scene) == {(second.name, 'MESH')})
        switch(scene, first_id)
        check('preset_switch_remains_live_after_undo', active(scene) == {(first.name, 'MESH')})

        # A person's mesh and armature can be saved in different presets. Only
        # one mode may be active; source vertices, weights and rig remain intact.
        mesh_id = addon.presets.create(scene).uuid
        settings.center_object = None
        settings.subdivision = 'NONE'
        settings.scope = 'SELECTED'
        rig, body = make_rig(scene)
        rig.name, body.name = 'プリセット・元リグ', 'プリセット・ウェイトメッシュ'
        rig_data = rig.data.as_pointer()
        bone_state = [(bone.name, tuple(bone.head_local), tuple(bone.tail_local)) for bone in rig.data.bones]
        body_data = original_mesh(body)
        weights = [[(group.group, group.weight) for group in vertex.groups] for vertex in body.data.vertices]
        original_rig_mod = next(mod for mod in body.modifiers if mod.type == 'ARMATURE')
        original_rig_uid = original_rig_mod.persistent_uid
        addon.setup_mesh(scene, body)
        settle(scene)
        arm_id = addon.presets.create(scene).uuid
        settings.mode = 'ARMATURE'
        addon.setup_armature(scene, rig)
        settle(scene)
        check('armature_preset_can_use_mesh_from_inactive_preset', active(scene) == {(rig.name, 'ARMATURE')})
        check('armature_preset_hides_original_and_shows_output', body.hide_get()
              and all(not item.output.hide_get() for item in record(scene, rig, 'ARMATURE').outputs))
        arm_output = record(scene, rig, 'ARMATURE').output_rig
        expect_error('same_preset_rejects_mesh_rig_double_registration', lambda: addon.setup_mesh(scene, body))
        check('rejected_double_registration_keeps_rig_output', record(scene, rig, 'ARMATURE').output_rig == arm_output
              and manual(scene) == {(rig.name, 'ARMATURE')})
        switch(scene, mesh_id)
        check('switching_person_to_mesh_restores_original_visibility', not body.hide_get()
              and active(scene) == {(body.name, 'MESH')})
        check('person_mesh_has_single_fisheye_modifier', sum(mod.type == 'NODES' for mod in fish_modifiers(scene, body)) == 1)
        switch(scene, arm_id)
        check('switching_person_back_rebuilds_only_active_mode', active(scene) == {(rig.name, 'ARMATURE')})
        check('person_source_mesh_and_weights_unchanged', original_mesh(body) == body_data and weights == [
            [(group.group, group.weight) for group in vertex.groups] for vertex in body.data.vertices])
        check('person_source_rig_and_original_modifier_unchanged', rig.data.as_pointer() == rig_data
              and bone_state == [(bone.name, tuple(bone.head_local), tuple(bone.tail_local)) for bone in rig.data.bones]
              and next(mod for mod in body.modifiers if mod.type == 'ARMATURE').persistent_uid == original_rig_uid)

        # Removing generated output only clears the current preset. Other
        # presets still describe what should be rebuilt when selected later.
        inactive_entries = {preset.uuid: entry_set(preset) for preset in settings.presets if preset.uuid != arm_id}
        bpy.ops.gyogan.remove_all()
        settle(scene)
        addon.presets.save_active(scene)
        check('clear_all_clears_only_current_registration', not settings.targets and not settings.manual_targets
              and not entry_set(get_preset(scene, arm_id)))
        check('clear_all_retains_inactive_preset_registrations', all(entry_set(get_preset(scene, token)) == entries
              for token, entries in inactive_entries.items()))
        switch(scene, first_id)
        check('switch_after_clear_all_preserves_preview_off', not settings.enabled)
        settings.enabled = True
        settle(scene)
        check('inactive_preset_rebuilds_after_clear_all', active(scene) == {(first.name, 'MESH')})
        retained = set(preset.uuid for preset in settings.presets) - {first_id}
        addon.presets.delete(scene)
        settle(scene)
        check('delete_removes_only_selected_preset', set(preset.uuid for preset in settings.presets) == retained
              and settings.active_preset_id in retained)
        while len(settings.presets) > 1:
            addon.presets.delete(scene)
            settle(scene)
        last_id = settings.active_preset_id
        addon.presets.delete(scene)
        settle(scene)
        check('deleting_last_preset_leaves_one_readable_empty_preset', len(settings.presets) == 1
              and bool(settings.presets[0].name.strip()) and not settings.manual_targets
              and not settings.presets[0].entries)
        check('deleting_last_preset_replaces_identity', settings.active_preset_id != last_id)
        check('all_preset_operations_preserve_original_shape_keys', original_mesh(first) == first_source)
    except Exception:
        exception = traceback.format_exc()
        print(exception)
    finally:
        passed = bool(checks) and all(item['passed'] for item in checks) and exception is None
        report = dict(blender=bpy.app.version_string, passed=passed, checks=checks, exception=exception)
        REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        print('GYOGAN_PRESETS_RESULTS=' + json.dumps(report, ensure_ascii=False))
    if not passed:
        raise AssertionError('プリセットの検証に失敗しました: ' + str(REPORT))


if __name__ == '__main__':
    run()
