"""Install the release ZIP through Blender's real extension installer.

Run only in an isolated background process, for example::

    blender --background --factory-startup --python-exit-code 1 \
        --python tests/blender_extension_install.py -- \
        --zip dist/gyogan_camera-0.1.20.zip \
        --output-dir tests/.compat/install-5.2

Before starting Blender, set BLENDER_USER_RESOURCES and BLENDER_USER_CONFIG
to separate directories below --output-dir. No real user profile is modified,
no network repository is used, and no development copy of the add-on is imported.
"""

import argparse
import hashlib
import importlib
import json
import math
import os
import sys
import tempfile
import tomllib
import traceback
import uuid
from pathlib import Path
from zipfile import ZipFile

import addon_utils
import bpy


def within(path, parent):
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def isolation_check(output):
    """Reject a live Blender or accidentally inherited real user directories."""
    if not bpy.app.background or '--factory-startup' not in sys.argv:
        raise RuntimeError('インストール検証は --background --factory-startup で実行してください')
    fixture_root = Path(__file__).resolve().parent / '.compat'
    temporary_root = Path(tempfile.gettempdir()).resolve()
    if (output in (fixture_root, temporary_root)
            or not any(within(output, root) for root in (fixture_root, temporary_root))):
        raise RuntimeError('出力先は tests/.compat または一時ディレクトリ内の専用サブフォルダーにしてください')
    for name in ('BLENDER_USER_RESOURCES', 'BLENDER_USER_CONFIG'):
        value = os.environ.get(name)
        if not value or not within(Path(value), output) or Path(value).resolve() == output:
            raise RuntimeError(f'{name} を出力先内の専用サブフォルダーに設定してから Blender を起動してください')
    for name in ('BLENDER_USER_SCRIPTS', 'BLENDER_USER_EXTENSIONS',
                 'BLENDER_USER_DATAFILES'):
        value = os.environ.get(name)
        if value and not within(Path(value), output):
            raise RuntimeError(f'{name} が検証用ディレクトリの外を参照しています')
    for name, value in (('USER', bpy.utils.resource_path('USER')),
                        ('CONFIG', bpy.utils.user_resource('CONFIG')),
                        ('EXTENSIONS', bpy.utils.user_resource('EXTENSIONS'))):
        if not value or not within(Path(value), output):
            raise RuntimeError(f'Blender の {name} が隔離されていません: {value}')


def run(archive, output):
    isolation_check(output)
    output.mkdir(parents=True, exist_ok=True)
    checks = []
    report = {'blender_version': bpy.app.version_string,
              'archive': str(archive), 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
              'output_dir': str(output), 'checks': checks}
    module_name = None
    exception = None

    def check(name, condition, **details):
        checks.append({'test': name, 'passed': bool(condition), **details})
        if not condition:
            raise AssertionError(f'{name}: {details}')

    def refresh(scene):
        scene.update_tag()
        bpy.context.view_layer.update()
        return bpy.context.evaluated_depsgraph_get()

    def positions(scene, obj):
        evaluated = obj.evaluated_get(refresh(scene))
        data = evaluated.to_mesh()
        try:
            return [tuple(vertex.co) for vertex in data.vertices]
        finally:
            evaluated.to_mesh_clear()

    def distance(a, b):
        if len(a) != len(b):
            return float('inf')
        return max((math.dist(x, y) for x, y in zip(a, b)), default=0.)

    try:
        check('isolated_profile', True,
              resources=bpy.utils.resource_path('USER'),
              config=bpy.utils.user_resource('CONFIG'),
              extensions=bpy.utils.user_resource('EXTENSIONS'))
        check('no_development_addon_loaded', 'gyogan_camera' not in sys.modules
              and not hasattr(bpy.types.Scene, 'gyogan'))
        with ZipFile(archive) as bundle:
            names = bundle.namelist()
            files = [info.filename for info in bundle.infolist() if not info.is_dir()]
            check('single_addon_folder_layout',
                  'gyogan_camera/__init__.py' in files
                  and 'gyogan_camera/blender_manifest.toml' in files
                  and len(names) == len(set(names))
                  and all(name.startswith('gyogan_camera/')
                          and not name.startswith('gyogan_camera/gyogan_camera/')
                          and '\\' not in name
                          and '..' not in name.split('/')
                          for name in names),
                  archive_files=files)
            manifest = tomllib.loads(bundle.read('gyogan_camera/blender_manifest.toml').decode('utf-8'))
        check('expected_extension_manifest', manifest['id'] == 'gyogan_camera'
              and manifest['type'] == 'add-on' and manifest['name'] == '魚眼カメラ')
        report['package_version'] = manifest['version']
        report['minimum_blender_version'] = manifest['blender_version_min']

        # Use the same local-repository and package-install API as Blender's
        # "Install from Disk" command, including manifest compatibility checks.
        repos = bpy.context.preferences.extensions.repos
        for repo in tuple(repos):
            repos.remove(repo)  # Only the factory profile in this process.
        # Keep previous failed attempts for diagnosis without reinstalling over
        # them or deleting paths supplied by the caller.
        repo_path = output / ('repository-' + uuid.uuid4().hex[:12])
        repo_path.mkdir()
        check('fresh_repository', not (repo_path / manifest['id']).exists(),
              directory=str(repo_path))
        repo = repos.new(name='魚眼・隔離インストール検証',
                         module='gyogan_install_check',
                         custom_directory=str(repo_path), remote_url='', source='USER')
        check('offline_repository', not repo.use_remote_url
              and Path(repo.directory).resolve() == repo_path.resolve())
        module_name = f'bl_ext.{repo.module}.{manifest["id"]}'
        result = bpy.ops.extensions.package_install_files(
            'EXEC_DEFAULT', filepath=str(archive), repo=repo.module,
            enable_on_install=True)
        check('install_from_disk_finished', result == {'FINISHED'}, result=sorted(result))
        check('enabled_in_preferences', module_name in bpy.context.preferences.addons,
              module=module_name)
        addon = importlib.import_module(module_name)
        check('imported_installed_archive',
              within(Path(addon.__file__), repo_path / manifest['id']),
              module_file=addon.__file__)
        check('package_version_matches_manifest',
              '.'.join(map(str, addon_utils.module_bl_info(addon)['version'])) == manifest['version'])
        listed = {module.__name__: module for module in addon_utils.modules(refresh=True)}
        check('japanese_name_visible_in_preferences', module_name in listed
              and addon_utils.module_bl_info(listed[module_name])['name'] == '魚眼カメラ')
        check('extension_relative_imports', all(
            getattr(addon, name).__name__ == f'{module_name}.{name}'
            for name in ('nodes', 'armature', 'dolly', 'cameras', 'targets', 'framing', 'subdivision', 'presets')))
        check('scene_properties_registered', hasattr(bpy.types.Scene, 'gyogan')
              and hasattr(bpy.types.Scene, 'gyogan_dolly'))
        check('restricted_registration_defers_scene_access', addon._registration_pending
              and bpy.app.timers.is_registered(addon._finish_registration))
        # A background --python script does not pump the UI timer event loop.
        # Invoke its exact callback after addon_utils leaves RestrictBlend, then
        # reproduce the timer manager removing a callback that returned None.
        timer_result = addon._finish_registration()
        if timer_result is None and bpy.app.timers.is_registered(addon._finish_registration):
            bpy.app.timers.unregister(addon._finish_registration)
        check('deferred_initialization_completes', timer_result is None
              and not addon._registration_pending
              and bpy.context.scene.gyogan.camera == bpy.context.scene.camera)

        # A tiny numeric fixture exercises the installed module's node builder
        # and drivers, then verifies that Preferences -> disable is reversible.
        scene = bpy.context.scene
        camera = bpy.data.objects.new('インストール検証・カメラ',
                                      bpy.data.cameras.new('インストール検証・カメラ'))
        scene.collection.objects.link(camera)
        camera.location = (0., -10., 2.)
        camera.rotation_euler.x = math.pi / 2.
        camera.data.lens = 28.
        scene.camera = scene.gyogan.camera = camera
        scene.cursor.location = (0., 0., 2.)
        scene.gyogan.subdivision = 'NONE'
        scene.gyogan.strength = 1.
        data = bpy.data.meshes.new('インストール検証・メッシュ')
        data.from_pydata([(-4., 0., 0.), (4., 0., 0.), (4., 0., 4.), (-4., 0., 4.)],
                        [], [(0, 1, 2, 3)])
        data.update()
        obj = bpy.data.objects.new(data.name, data)
        scene.collection.objects.link(obj)
        original = positions(scene, obj)
        original_location, original_lens = tuple(camera.location), camera.data.lens
        addon.setup_mesh(scene, obj)
        check('installed_mesh_warp_runs', distance(positions(scene, obj), original) > .01)
        scene.gyogan.effect_scope = 'CAMERA'
        addon.targets.reconcile(scene)
        check('installed_camera_scope_preserves_manual', len(scene.gyogan.manual_targets) == 1
              and any(target.source == obj and target.active for target in scene.gyogan.targets))
        scene.gyogan.effect_scope = 'MANUAL'
        addon.targets.reconcile(scene)
        check('original_vertices_unchanged', [tuple(vertex.co) for vertex in data.vertices] == original)
        addon.dolly.setup(scene)
        scene.gyogan_dolly.ratio = 2.
        evaluated = camera.evaluated_get(refresh(scene))
        check('installed_dolly_runs', abs(evaluated.data.lens - original_lens * 2.) < 1.e-5
              and math.dist(tuple(evaluated.matrix_world.translation), original_location) > 1.)
        retained_tokens = {target.token for target in scene.gyogan.targets}
        retained_manual = [(item.source.name, item.kind) for item in scene.gyogan.manual_targets]
        result = bpy.ops.preferences.addon_disable(module=module_name)
        check('disable_through_preferences', result == {'FINISHED'}
              and module_name not in bpy.context.preferences.addons)
        check('scene_properties_unregistered', not hasattr(bpy.types.Scene, 'gyogan')
              and not hasattr(bpy.types.Scene, 'gyogan_dolly'))
        check('disable_restores_original_mesh', distance(positions(scene, obj), original) < 1.e-6
              and all(not modifier.show_viewport and not modifier.show_render
                      for modifier in obj.modifiers))
        evaluated = camera.evaluated_get(refresh(scene))
        check('disable_restores_camera', math.dist(
            tuple(evaluated.matrix_world.translation), original_location) < 1.e-5
            and abs(evaluated.data.lens - original_lens) < 1.e-5)
        check('disable_removes_owned_camera_drivers', all(
            not owner.animation_data or not owner.animation_data.drivers
            for owner in (camera, camera.data)))
        check('disable_removes_handlers', not any(
            getattr(handler, '__module__', '').startswith(module_name)
            for name in ('depsgraph_update_pre', 'depsgraph_update_post', 'load_pre',
                         'load_post', 'undo_pre', 'undo_post', 'redo_pre', 'redo_post')
            for handler in getattr(bpy.app.handlers, name)))
        check('disable_cancels_scope_timer', not bpy.app.timers.is_registered(addon.targets._tick))
        check('original_vertices_retained_after_disable',
              [tuple(vertex.co) for vertex in data.vertices] == original)
        result = bpy.ops.preferences.addon_enable(module=module_name)
        check('installed_addon_reenables', result == {'FINISHED'}
              and module_name in bpy.context.preferences.addons
              and hasattr(bpy.types.Scene, 'gyogan'))
        check('registration_retained_after_reenable',
              {target.token for target in scene.gyogan.targets} == retained_tokens
              and [(item.source.name, item.kind) for item in scene.gyogan.manual_targets] == retained_manual)
        check('reenable_keeps_restored_preview', distance(positions(scene, obj), original) < 1.e-6)
        check('reenable_has_owned_pending_timer', addon._registration_pending
              and bpy.app.timers.is_registered(addon._finish_registration))
        result = bpy.ops.preferences.addon_disable(module=module_name)
        check('immediate_disable_cancels_initialization', result == {'FINISHED'}
              and not addon._registration_pending
              and not bpy.app.timers.is_registered(addon._finish_registration))
        check('disabled_callback_cannot_recreate_state', addon._finish_registration() is None
              and not hasattr(bpy.types.Scene, 'gyogan'))
    except Exception:
        exception = traceback.format_exc()
    finally:
        if module_name and module_name in bpy.context.preferences.addons:
            try:
                bpy.ops.preferences.addon_disable(module=module_name)
            except Exception:
                exception = (exception or '') + '\nCleanup:\n' + traceback.format_exc()
        report.update(passed=exception is None and all(item['passed'] for item in checks),
                      exception=exception)
        report_path = output / 'extension_install_result.json'
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps({'report': str(report_path), 'passed': report['passed'],
                          'checks': len(checks)}, ensure_ascii=False))
    if exception:
        raise RuntimeError(exception)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--zip', required=True, type=Path)
    parser.add_argument('--output-dir', required=True, type=Path)
    options = parser.parse_args(sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else [])
    run(options.zip.resolve(), options.output_dir.resolve())
