"""Render A_テスト用人物 with reversible dolly zoom in an isolated process."""
import json
import math
import sys
from pathlib import Path

import bpy
from mathutils import Vector

if not bpy.app.background:
    raise RuntimeError('ドリーの人物確認は専用バックグラウンドプロセスで実行してください')
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import gyogan_camera as addon
addon.register()
fixture = ROOT / 'tests' / 'dolly_live_fixture.blend'
if '--navigation' in sys.argv and (ROOT / 'tests' / 'navigation_live_fixture.blend').exists():
    fixture = ROOT / 'tests' / 'navigation_live_fixture.blend'
bpy.ops.wm.open_mainfile(filepath=str(fixture if fixture.exists() else ROOT / '魚眼テスト用.blend'), load_ui=False)
scene = bpy.context.scene
if scene.gyogan_dolly.active:
    addon.dolly.restore(scene)
while scene.gyogan.targets:
    addon.remove_target(scene, len(scene.gyogan.targets) - 1)
body_names = ('Beta_Surface', 'Beta_Joints')
assert scene.objects.get('A_テスト用人物')
scene.render.engine = 'BLENDER_WORKBENCH'
scene.render.resolution_x, scene.render.resolution_y = 960, 720
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
scene.display.shading.light = 'STUDIO'
scene.display.shading.color_type = 'OBJECT'
scene.display.shading.show_shadows = True
scene.display.shading.show_cavity = True
scene.display.shading.background_type = 'WORLD'
scene.world.color = (.08, .08, .08)
for obj in scene.objects:
    if obj.type == 'MESH':
        obj.hide_render = False
        obj.color = (.2, .48, .68, 1) if obj.name in body_names else (.45, .48, .48, 1)
bpy.context.view_layer.update()
depsgraph = bpy.context.evaluated_depsgraph_get()
points = [obj.evaluated_get(depsgraph).matrix_world @ Vector(p)
          for obj in (scene.objects[name] for name in body_names)
          for p in obj.evaluated_get(depsgraph).bound_box]
low = Vector(tuple(min(p[i] for p in points) for i in range(3)))
high = Vector(tuple(max(p[i] for p in points) for i in range(3)))
cam = scene.gyogan.camera or scene.camera
scene.camera = scene.gyogan.camera = cam
cam.data.lens = 25
cam.data.shift_x = cam.data.shift_y = 0
cam.rotation_euler = (math.pi / 2, 0, 0)
half_width = cam.data.sensor_width / (2 * cam.data.lens)
distance = max((high.x-low.x)/(2*half_width*.65),
               (high.z-low.z)/(2*half_width*.75*.65), 1.)
center = (low + high) * .5
cam.location = (center.x, center.y - distance, center.z)
anchor = bpy.data.objects.new('ドリー検証・人物の中央', None)
scene.collection.objects.link(anchor)
anchor.location = center
scene.gyogan_dolly.target = anchor
scene.gyogan_dolly.compensate_fisheye = True
scene.gyogan.center_object = None
scene.gyogan.strength = 1
scene.gyogan.fov = math.radians(110)
scene.gyogan.zoom = 1.3
scene.gyogan.ellipse_x = scene.gyogan.ellipse_y = 1
scene.gyogan.near_distance = .01
scene.gyogan.subdivision = 'NONE'
for obj in list(scene.objects):
    if obj.type == 'MESH':
        addon.setup_mesh(scene, obj)
paths = []
for enabled, mode in ((False, 'normal'), (True, 'fisheye')):
    scene.gyogan.enabled = enabled
    bpy.context.view_layer.update()
    addon.dolly.setup(scene)
    try:
        for ratio in (.5, 1., 2.):
            scene.gyogan_dolly.ratio = ratio
            scene.update_tag()
            bpy.context.view_layer.update()
            path = ROOT / 'tests' / f'center_dolly_{mode}_{ratio}.png'
            scene.render.filepath = str(path)
            bpy.ops.render.render(write_still=True)
            paths.append(str(path))
        if '--navigation' in sys.argv:
            area = next(a for a in bpy.context.screen.areas if a.type == 'VIEW_3D')
            region = next(r for r in area.regions if r.type == 'WINDOW')
            space = area.spaces.active
            space.camera = cam
            space.lock_camera = True
            space.region_3d.view_perspective = 'CAMERA'
            space.region_3d.view_location = center
            space.region_3d.view_distance = distance
            scene.gyogan_dolly.ratio = 1.
            scene.update_tag()
            bpy.context.view_layer.update()
            space.region_3d.view_rotation = cam.matrix_world.to_quaternion()
            navigation_rotation = cam.matrix_world.to_quaternion()
            for step, delta in (('before', 0), ('forward', 2), ('back', -2)):
                if delta:
                    old_ratio = scene.gyogan_dolly.ratio
                    with bpy.context.temp_override(window=bpy.context.window, area=area, region=region):
                        bpy.ops.view3d.zoom(delta=delta)
                    scene.update_tag()
                    bpy.context.view_layer.update()
                    assert abs(scene.gyogan_dolly.ratio - old_ratio) > .001
                assert cam.matrix_world.to_quaternion().rotation_difference(navigation_rotation).angle < .0001
                assert abs(cam.data.lens - scene.gyogan_dolly.base_lens * scene.gyogan_dolly.ratio) < .001
                print('GYOGAN_CAMERA_NAVIGATION=' + json.dumps(dict(
                    mode=mode, step=step, ratio=scene.gyogan_dolly.ratio, lens=cam.data.lens)))
                path = ROOT / 'tests' / f'center_dolly_{mode}_auto_{step}.png'
                scene.render.filepath = str(path)
                bpy.ops.render.render(write_still=True)
                paths.append(str(path))
            before = cam.matrix_world.copy()
            with bpy.context.temp_override(window=bpy.context.window, area=area, region=region):
                bpy.ops.view3d.view_orbit(type='ORBITRIGHT', angle=math.radians(12))
                bpy.ops.view3d.zoom(delta=1)
            scene.update_tag()
            bpy.context.view_layer.update()
            assert max(abs(a-b) for ra, rb in zip(before, cam.matrix_world) for a,b in zip(ra,rb)) > .01
            for ratio in (2., 1.):
                scene.gyogan_dolly.ratio = ratio
                scene.update_tag()
                bpy.context.view_layer.update()
                path = ROOT / 'tests' / f'center_dolly_{mode}_navigation_{ratio}.png'
                scene.render.filepath = str(path)
                bpy.ops.render.render(write_still=True)
                paths.append(str(path))
    finally:
        addon.dolly.restore(scene)
print('GYOGAN_DOLLY_PREVIEWS=' + json.dumps(paths, ensure_ascii=False))
