"""Create the grid-only demo in a separate Blender process.

Use the user's A_テスト用人物 for visual character checks; never recreate the
retired procedural humanoid in this demo or in the user's working scene.
"""
from pathlib import Path
import math
import sys
import bpy
from mathutils import Matrix, Vector

if not bpy.app.background:
    raise RuntimeError('デモ生成は専用のバックグラウンドプロセスで実行してください')

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import gyogan_camera as addon
addon.register()

scene = bpy.context.scene
scene.name = 'Gyogan Demo'
for obj in list(scene.objects):
    bpy.data.objects.remove(obj, do_unlink=True)
scene.render.engine = 'CYCLES'
scene.cycles.samples = 12
scene.cycles.use_denoising = True
scene.render.resolution_x = 960
scene.render.resolution_y = 720
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
scene.world.color = (.2, .2, .2)
scene.view_settings.view_transform = 'Standard'


def material(name, color):
    mat = bpy.data.materials.new(name)
    mat.diffuse_color = (*color, 1)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get('Principled BSDF')
    bsdf.inputs['Base Color'].default_value = (*color, 1)
    bsdf.inputs['Roughness'].default_value = .6
    return mat


paper = material('Grid paper', (.74, .84, .86))
gridmat = material('Grid lines', (.10, .28, .36))

cam = bpy.data.objects.new('Demo Camera', bpy.data.cameras.new('Demo Camera'))
scene.collection.objects.link(cam)
cam.data.lens = 16
scene.camera = scene.gyogan.camera = cam
scene.gyogan.fov = math.radians(145)
scene.gyogan.subdivision = 'NONE'


def mesh(name, vertices, faces, mat):
    data = bpy.data.meshes.new(name)
    data.from_pydata(vertices, [], faces)
    data.update()
    obj = bpy.data.objects.new(name, data)
    scene.collection.objects.link(obj)
    data.materials.append(mat)
    return obj


# Thin strips with many segments show curved grid lines after deformation.
verts, faces = [], []
for vertical in (True, False):
    for value in range(-12, 13):
        for j in range(64):
            a, b = -12 + 24*j/64, -12 + 24*(j+1)/64
            i = len(verts)
            if vertical:
                verts.extend([(value-.016,a,-9), (value+.016,a,-9),
                              (value+.016,b,-9), (value-.016,b,-9)])
            else:
                verts.extend([(a,value-.016,-9), (b,value-.016,-9),
                              (b,value+.016,-9), (a,value+.016,-9)])
            faces.append((i,i+1,i+2,i+3))
grid = mesh('Background grid · mesh mode', verts, faces, gridmat)
addon.setup_mesh(scene, grid)
back = mesh('Backdrop', [(-30,-30,-9.05),(30,-30,-9.05),(30,30,-9.05),(-30,30,-9.05)],
            [(0,1,2,3)], paper)

scene.gyogan.mode = 'MESH'
scene.gyogan.status = '背景格子のデモです。人物の確認には A_テスト用人物 を使用します'

for name, loc, power, size in [('Key', (1,4,1),1500,7),('Fill',(-5,0,-1),700,5)]:
    light = bpy.data.objects.new(name,bpy.data.lights.new(name,'AREA'))
    scene.collection.objects.link(light)
    light.location = loc
    light.rotation_euler = (Vector((0,0,-6))-light.location).to_track_quat('-Z','Y').to_euler()
    light.data.energy, light.data.shape, light.data.size = power, 'DISK', size

# Present the demo from the standard front direction (Numpad 1): +Y forward,
# +Z up. This rotates only this script's generated environment, not user assets.
front_basis = Matrix.Rotation(math.pi / 2, 4, 'X')
bpy.context.view_layer.update()
for obj in scene.objects:
    obj.matrix_world = front_basis @ obj.matrix_world
bpy.context.view_layer.update()

dest = ROOT / 'demo'
dest.mkdir(exist_ok=True)
for enabled, strength, name in [(False,1.0,'original'),(True,1.0,'fisheye'),
                                (True,2.0,'fisheye_strong'),(True,-1.0,'fisheye_negative')]:
    scene.gyogan.enabled = enabled
    scene.gyogan.strength = strength
    scene.render.filepath = str(dest / (name+'.png'))
    bpy.ops.render.render(write_still=True)
scene.gyogan.strength = 1.0

# Store an easy-to-inspect workspace view in the demo file.
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type == 'VIEW_3D':
            area.spaces.active.camera = cam
            area.spaces.active.region_3d.view_rotation = cam.matrix_world.to_quaternion()
            area.spaces.active.region_3d.view_perspective = 'CAMERA'
            area.spaces.active.show_region_ui = True
            area.spaces.active.shading.type = 'MATERIAL'
assert not any(obj.type == 'ARMATURE' for obj in scene.objects)
bpy.ops.wm.save_as_mainfile(filepath=str(dest / 'Gyogan_Camera_Demo.blend'))
print('GYOGAN_DEMO_CREATED=' + str(dest))
