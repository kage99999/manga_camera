"""Build the development handoff archive; this is not an installable add-on.

Run: python build_handoff.py --date YYYY-MM-DD
The date is explicit so it follows the user's local date, not a remote host clock.
"""
import argparse
import ast
from datetime import date
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
from zipfile import ZipFile, ZIP_DEFLATED


ROOT = Path(__file__).resolve().parent
PREFIX = 'gyogan_camera_handoff/'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def build(created_date):
    date.fromisoformat(created_date)
    files = {}

    def add(path, destination):
        if not path.is_file():
            raise FileNotFoundError(path)
        files[destination] = path.read_bytes()

    for relative in ('AGENTS.md', 'README.md', 'DESIGN.md', '.gitignore',
                     'build.py', 'build_handoff.py'):
        add(ROOT / relative, 'source/' + relative)
    for path in sorted((ROOT / 'gyogan_camera').rglob('*')):
        if path.is_file() and path.suffix in {'.py', '.toml'} and '__pycache__' not in path.parts:
            add(path, 'source/' + path.relative_to(ROOT).as_posix())
    for path in sorted((ROOT / 'tests').rglob('*.py')):
        if not {'.compat', '__pycache__'}.intersection(path.relative_to(ROOT).parts):
            add(path, 'source/' + path.relative_to(ROOT).as_posix())

    docs = ROOT / 'handoff'
    if not docs.is_dir():
        docs = ROOT.parent  # Also rebuildable from an extracted source/ folder.
    for name in ('00_最初に読む.md', '01_統合手順と設計.md',
                 '02_検証と未解決事項.md', '統合先への依頼文.md'):
        add(docs / name, name)

    init = ast.parse((ROOT / 'gyogan_camera/__init__.py').read_text(encoding='utf-8'))
    info = next(ast.literal_eval(node.value) for node in init.body
                if isinstance(node, ast.Assign) and any(
                    isinstance(target, ast.Name) and target.id == 'bl_info' for target in node.targets))
    version = '.'.join(map(str, info['version']))
    manifest = (ROOT / 'gyogan_camera/blender_manifest.toml').read_text(encoding='utf-8')
    assert re.search(r'^version\s*=\s*"' + re.escape(version) + r'"', manifest, re.M)
    addon_zip = ROOT / 'dist' / ('gyogan_camera-' + version + '.zip')
    with ZipFile(addon_zip) as archive:
        assert archive.testzip() is None
        assert all(name.startswith('gyogan_camera/') for name in archive.namelist())
        package = {key.removeprefix('source/'): value for key, value in files.items()
                   if key.startswith('source/gyogan_camera/')}
        assert set(archive.namelist()) == set(package), '単体ZIPの収録ファイルが本体と一致しません'
        assert all(archive.read(name) == package[name] for name in package), '単体ZIPが現在のソースと一致しません'
    add(addon_zip, 'source/dist/' + addon_zip.name)

    reports = {}
    for name in ('compatibility_result.json', 'extension_install_result.json'):
        path = ROOT / 'tests' / name
        add(path, 'source/tests/' + name)
        reports[name] = json.loads(path.read_text(encoding='utf-8'))
        assert reports[name]['passed'], '成功していない集計があります'
    install = reports['extension_install_result.json']
    assert install['package_version'] == version
    assert install['archive_sha256'] == sha(addon_zip.read_bytes())
    referenced = set()
    for entry in reports['compatibility_result.json']['versions']:
        for suite in entry['suites']:
            assert suite['passed'] and not suite['errors']
            referenced.update((suite['report'], suite['log']))
    for entry in install['versions']:
        assert entry['passed'] and not entry['failed_checks'] and not entry['log_errors']
        referenced.update((entry['raw_report'], entry['validation_log']))
        log = PurePosixPath(entry['raw_report']).parent / 'install.log'
        if (ROOT / str(log)).is_file():
            referenced.add(str(log))
    for relative in sorted(referenced):
        rel = PurePosixPath(relative)
        assert not rel.is_absolute() and '..' not in rel.parts
        assert rel.parts[:2] == ('tests', '.compat') and rel.suffix in {'.json', '.log'}
        path = ROOT / relative
        add(path, 'source/' + relative)

    git = subprocess.run(['git', 'log', '-1', '--format=%h %s'], cwd=ROOT,
                         capture_output=True, text=True, encoding='utf-8', errors='replace')
    meta = dict(
        format='Gyogan Camera development handoff', addon_version=version,
        created_date_jst=created_date, installable=False,
        source='Current working files; includes uncommitted development since v0.1.17.',
        git_base=git.stdout.strip() if git.returncode == 0 else 'Not available in this extracted copy',
        standard_blender='5.2.0', minimum_blender='5.0.0',
        known_unresolved=['User-reported Blender 5.1.2 Undo crash; cause not established.'],
        regression_checks=sum(v['check_count'] for v in reports['compatibility_result.json']['versions']),
        install_checks=install['total_checks'],
        verification_note='Bundled past results are for the standalone add-on, not integration results.',
        addon_zip_sha256=sha(addon_zip.read_bytes()),
        excluded=['User work .blend files', 'assets/', '.git/', 'Blender user profiles',
                  'Generated scenes and previews', 'Old unreferenced test results'])
    files['package_info.json'] = (json.dumps(meta, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    # Parse without importing bpy or executing the bundled scripts.
    for name, data in files.items():
        if name.endswith('.py'):
            ast.parse(data.decode('utf-8-sig'), filename=name)
    for name, data in files.items():
        if '/' not in name and name.endswith('.md'):
            for link in re.findall(r'\]\(([^)]+)\)', data.decode('utf-8')):
                if not link.startswith(('https:', 'http:', '#')):
                    assert link in files, '引き継ぎ文書のリンク切れ: ' + link
    checksums = {name: sha(data) for name, data in sorted(files.items())}
    files['SHA256SUMS.json'] = (json.dumps(checksums, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    output = ROOT / 'dist' / '引継ぎ用.zip'
    output.parent.mkdir(exist_ok=True)
    with ZipFile(output, 'w', ZIP_DEFLATED) as archive:
        for name, data in sorted(files.items()):
            archive.writestr(PREFIX + name, data)
    with ZipFile(output) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(files)
        assert all(archive.read(PREFIX + name) == data for name, data in files.items())
        assert all(sha(archive.read(PREFIX + name)) == digest for name, digest in checksums.items())
    print(json.dumps(dict(output=str(output), version=version, files=len(files),
                          bytes=output.stat().st_size, sha256=sha(output.read_bytes()),
                          syntax_links_crc_hashes='passed'), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--date', required=True, help='ユーザーの現地日付 YYYY-MM-DD')
    build(parser.parse_args().date)
